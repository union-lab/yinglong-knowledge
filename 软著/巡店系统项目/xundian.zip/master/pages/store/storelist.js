import * as storeApi from '../../api/store.js';
import QQMapWX from '../../utils/qqmap-wx-jssdk.min.js';
import config from "../../utils/config";
var qqmapsdk;
var app = getApp();
Page({
    data: {
        search: {
            pageIndex: 1,
            pageSize: 10,
            keyword:""
        },
        list: [],
        actionTitle:"操作",
        showActionsheet: false,
        actionGroups: [{
                text: '在地图上显示',
                value: 1
            },
            {
                text: '修改门店位置',
                value: 2
            },
            {
                text: '修改门店资料',
                value: 3
            }
        ],
        region: null,
        customItem: '全部'
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        if(app.globalData.adInfo){
            this.setData({
                "search.districtId":app.globalData.adInfo.adcode,
                region:[app.globalData.adInfo.province, app.globalData.adInfo.city, app.globalData.adInfo.district]
            })
        }
        wx.startPullDownRefresh();
        this.setData({
            onSearch:this.onSearch
        })
    },

    bindRegionChange(e){
        this.setData({
            "search.provinceId":e.detail.code[0]?e.detail.code[0].substring(0,2):0,
            "search.cityId":e.detail.code[1]?e.detail.code[1].substring(0,4):0,
            "search.districtId":e.detail.code[2] || 0,
            region:e.detail.value
        })
        wx.startPullDownRefresh();
    },
    onShowSearch(){
        this.setData({
            showSearch:!this.data.showSearch
        })
    },
    onSearch(value){
        this.data.search.keyword = value;
        this.loadList();
        return new Promise((resolve,reject)=>{
            return resolve();
        })
    },
    loadList(page) {
        this.data.search.pageIndex = page || 1
        storeApi.getStoreList(this.data.search).then(res => {
            var list = page > 1 ? this.data.list.concat(res.data.data) : res.data.data;
            this.setData({
                list: list,         
                total: res.data.total
            })
        }).finally(() => {
            wx.stopPullDownRefresh();
        })
    },
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.loadList();
    },
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {
        if (this.data.total > this.data.search.pageIndex*this.data.search.pageSize) {
            this.loadList(this.data.search.pageIndex + 1);
        }
    },
    selectItem(e) {
        this.currentItem = e.currentTarget.dataset.item;
        this.setData({
            showActionsheet: true,
            actionTitle:this.currentItem.storeName
        })
    },
    openMap() {
        var item = this.currentItem
        //打开地图
        wx.openLocation({
            latitude: item.latitude,
            longitude: item.longitude,
            name: item.storeName, //定位名称
            address: item.districtName + item.townName + item.address, //具体地址
            scale: 15
        })
    },
    selectAction(e) {
        this.setData({
            showActionsheet: false
        })
        switch (e.detail.value) {
            case 1:
                return this.openMap();
            case 2:
                return this.updateStoreLocation();
            case 3:
                wx.navigateTo({
                  url: `/pages/store/storeedit?id=${this.currentItem.id}`,
                });
                //return this.updateStore();
        }
    },
    updateStoreLocation() {
        // 实例化API核心类
        qqmapsdk = qqmapsdk || new QQMapWX({
            key: config.qqMapKey
        });
        var item = this.currentItem
        wx.chooseLocation({
            latitude: item.latitude,
            longitude: item.longitude,
            success(res) {
                var location = res;
                qqmapsdk.reverseGeocoder({
                    location: {
                        latitude: res.latitude,
                        longitude: res.longitude
                    },
                    success(res) {
                        console.log(res)
                        var res = res.result;
                        wx.showModal({
                            content: "你重新设置了门店位置，确定要提交吗？",
                            success(data) {
                                if (data.confirm) {
                                    wx.showLoading({
                                        title: '提交中',
                                    })
                                    storeApi.updateStoreLocation({
                                        id: item.id,
                                        townId: res.address_reference.town.id,
                                        townName: res.address_reference.town.title,
                                        address: res.formatted_addresses.recommend.replace(res.ad_info.district, ""),
                                        latitude: location.latitude,
                                        longitude: location.longitude
                                    }).then(res => {
                                        wx.showToast({
                                            title: '提交成功',
                                        })
                                    }).finally(() => {
                                        wx.hideLoading();
                                    })
                                }
                            }
                        });

                    }
                })
            }
        })
    },
    updateStore() {
        var item = this.currentItem;
        wx.showModal({
            editable: true,
            title: "修改门店名称",
            content: item.storeName,
            success(res) {
                if (res.confirm) {
                    if (!res.content) {
                        wx.showToast({
                            title: '请输入名称',
                            icon: "error"
                        })
                        return false;
                    }
                    wx.showLoading({
                        title: '提交中',
                    })
                    storeApi.updateStore({
                        id: item.id,
                        storeName: res.content
                    }).then(res => {
                        wx.showToast({
                            title: '提交成功',
                        })
                    }).finally(() => {
                        wx.hideLoading()
                    })
                }
            }
        })
    }
})