import * as storeApi from '../../api/store.js'
Page({
    data: {
        model: {},
        rules: [{
                name: 'storeName',
                rules: {
                    required: true,
                    message: '请填写门店名称'
                },
            },
            {
                name: 'tel',
                rules: [{
                    required: true,
                    message: '请填写联系电话'
                }]
            },
            {
                name: 'address',
                rules: {
                    required: true,
                    message: '请填写详细地址'
                }
            },
        ],
    },

    onLoad(options) {
        console.log(options)
        if (!options || !options.id) {
            wx.showToast({
                title: '参数错误',
                icon: "error"
            })
            return;
        }
        storeApi.GetStoreInfo(options.id).then(res => {
            this.setData({
                model: res.data,
            })
            this.setData({
                "model.chainLev":  res.data.chainLevStr,
            })
        })
    },

    onReady() {

    },
    setStoreName(e) {
        this.setData({
            "model.storeName": e.detail.value
        })
    },
    setAddress(e) {
        this.setData({
            "model.address": e.detail.value
        })
    },
    setTel(e) {
        this.setData({
            "model.tel": e.detail.value
        })
    },
    setChainName(e){
        this.setData({
            "model.chainName": e.detail.value
        })
    },
    toChainLevPage()
    {
        wx.navigateTo({
            url: `/pages/xundian/selectchainlev`,
        })
    },
    // weui提交表单
    submit() {
        this.selectComponent('#form').validate((valid, errors) => {
            if (!valid) {
                wx.showToast({
                    title: errors[0].message,
                    icon:"error"
                })
                return;
            }
            wx.showLoading({
                title: '提交中',
            })
            storeApi.updateStore(this.data.model).then(res => {
                wx.showToast({
                    title: '提交成功',
                })
            }).finally(() => {
                wx.hideLoading()
            })
        });
    }
})