import { WXlogin } from '../../api/common.js';
import * as xundianApi from '../../api/xundian.js'
import { dateFormat } from '../../utils/util.js'
import * as config from '../../utils/config.js';
var app=getApp();
var that;
Page({
    data: {
        userInfo:null,
        showExport: false,
        buttons: [{
                type: 'default',
                className: '',
                text: '取消',
                value: 0
            },
            {
                type: 'primary',
                className: '',
                text: '确认',
                value: 1
            }
        ],
        exportmodel: {
            startTime: dateFormat(new Date(),"yyyy-MM-dd"),
            endTime: dateFormat(new Date(),"yyyy-MM-dd"),
        }
    },

    onLoad(options) {
        that=this;
        this.setData({
            userInfo:app.globalData.userInfo
        })
    },
    onReady() {

    },
    login(){
        WXlogin(()=>{
            this.setData({
                userInfo:app.globalData.userInfo
            })
        })
    },
    export (e) {
        this.setData({
            showExport: true
        })
    },
    selectStartDate(e) {
        this.setData({
            "exportmodel.startTime": e.detail.value
        })
    },
    selectEndDate(e) {
        this.setData({
            "exportmodel.endTime": e.detail.value
        })
    },
    exportButtonTap(e) {
        if(e.detail.index==0) {
            this.setData({
                showExport: false
            })
            return false;
        }
        if (!this.data.exportmodel.startTime) {
            wx.showToast({
                title: '请选择开始时间',
                icon: "error"
            })
            return
        }
        if (!this.data.exportmodel.endTime) {
            wx.showToast({
                title: '请选择结束时间',
                icon: "error"
            })
            return
        }
        if (this.data.exportmodel.startTime > this.data.exportmodel.endTime) {
            wx.showToast({
                title: '开始时间不能大于结束时间',
                icon: "none"
            })
            return
        }
        wx.showLoading({
            title: '正在导出...',
        })
        var that =this;
        this.data.exportmodel.pageSize=50000
        xundianApi.exportList(this.data.exportmodel).then(res => {
            var filePath = wx.env.USER_DATA_PATH+res.data.substring(res.data.lastIndexOf("/"));
            wx.downloadFile({
                url: res.data,
                filePath:filePath,
                success(res) {
                    if (res.statusCode === 200) {
                        that.setData({
                            showExport: false
                        })
                        wx.openDocument({
                            filePath: res.filePath,
                            showMenu: true,
                            success() { }
                        })
                    }
                },
                fail(err) {
                    const envVersion =  wx.getAccountInfoSync().miniProgram.envVersion;
                    const url=config.baseUrl[envVersion];
                    const lastFileurl=url.substring(0,url.indexOf("/api/app"))+'/DownFiles/ExcelFiles/'+filePath.substring(filePath.indexOf("/导"))
                    wx.showModal({
                      title:"提示",
                      content:"当前文件大于200M，是否复制链接到手机浏览器下载？",
                      success:function(conRes)
                      {
                          if(conRes.confirm)
                          {
                              wx.setClipboardData({
                                data:lastFileurl,
                                success:function(setRes)
                                {
                                    wx.getClipboardData({
                                      success:function (option){
                                        that.setData({
                                            showExport: false
                                        })
                                          console.log(option.data)
                                      },
                                    })
                                }
                              })
                          }
                      }
                    })
                    // wx.hideLoading()
                    // wx.showToast({
                    //     title: err.errMsg,
                    //     icon: "error",
                    //     duration: 100000
                    // })
                },
                complete() {
                    wx.hideLoading()
                }
            })
        }).catch(()=>{
            wx.hideLoading()
        })
    },
})