// pages/xundian/ranking.js
import {
    date,
    dateFormat,
    timeAgo
} from '../../utils/util.js';
import * as xundianApi from '../../api/xundian';
import config from '../../utils/config.js';
var that;
Page({

    /**
     * 页面的初始数据
     */
    data: {
        userInfo:null,
        search: {
            agentId:config.agentId,
            appId: __wxConfig.accountInfo.appId,
            startTime: dateFormat(new Date(), "yyyy-MM"),
            endTime: dateFormat(new Date(), "yyyy-MM"),
            deptId: 0
        },
        yearArry:[],
        year:dateFormat(new Date(), "yyyy"),
        monthArry:[],
        month:dateFormat(new Date(), "MM"),
        list:[]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        that=this; 
        this.setData({
            userInfo:getApp().globalData.userInfo
        })
        var forYear=that.data.year-2023;
        var setYearArry=[];
        for(var i=0;i<=forYear;i++)
        {
            var addYear=parseInt(that.data.year)+parseInt((i));
            setYearArry.push(addYear);
        }
        that.setData({
            yearArry:setYearArry
        })
        var setMonthArray=[];
        for(var i=0;i<=12;i++)
        {
            if(i<10)
            {
                setMonthArray.push('0'+i);
            }else
            {
                setMonthArray.push(i);
            }
        }
        that.setData({
            monthArry:setMonthArray
        })
          this.loadData();
    },

    
    selectYear(e) {
        this.setData({
            year:that.data.yearArry[ e.detail.value]
        })
        wx.startPullDownRefresh();
    },
    selectMonth(e) {
        this.setData({
            month:that.data.monthArry[ e.detail.value]
        })
        wx.startPullDownRefresh();
    },
 loadData()
    {
        that.data.search.startTime=that.data.year+"-"+that.data.month+ "-01";
        that.data.search.endTime=that.data.year+"-"+ that.data.month+"-01";
        xundianApi.getRankingData(that.data.search).then(res=>{
            if(res.ok)
            {
                that.setData({
                    list:res.data
                  })
            }
        }).finally(() => {
            wx.stopPullDownRefresh();
        });
        
    },
    onPullDownRefresh() {
        this.loadData();
    },
})