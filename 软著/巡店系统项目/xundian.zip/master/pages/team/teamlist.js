import * as teamApi from '../../api/team.js'
import { agentId as _agentId } from '../../utils/config.js'
Page({
    data: {
        teamList: [],
        teamIndex:0,
        search: {
            pageIndex: 1,
            pageSize: 10,
            deptId:0,
        },
        list:[]
    },

    onLoad(options) {
        this.loadData();
    },
    onReady() {
        
    },
    loadData(){
        teamApi.getTeamPage().then(res=>{
            this.setData({
                teamList:res.data.teamList
            });
            this.data.search.deptId=this.data.teamList[this.data.teamIndex].key;
            wx.startPullDownRefresh();
        })
    },
    selectTeam(e){
        var index = e.detail.value;
        if(index!=this.data.teamIndex){
            this.setData({
                teamIndex:index
            });
            this.data.search.deptId=this.data.teamList[index].key;
            wx.startPullDownRefresh();
        }
    },
    loadList(page){
        this.data.search.pageIndex = page || 1
        teamApi.getTeamUserList(this.data.search).then(res => {
            var list = page > 1 ? this.data.list.concat(res.data.data) : res.data.data;
            this.setData({
                list: list,
                total: res.data.total
            })
        }).finally(()=>{
            wx.stopPullDownRefresh();
        })
    },
    selectUser(e){
        var userId=e.currentTarget.dataset.item.userId;
        if(userId<=0) return false;
        wx.navigateTo({
          url: `/pages/xundian/record?userId=${userId}`,
        })
    },
    onPullDownRefresh() {
        this.loadList();
    },
    onReachBottom() {
        if (this.data.total > this.data.search.pageIndex*this.data.search.pageSize) {
            this.loadList(this.data.search.pageIndex + 1);
        }
    },
})