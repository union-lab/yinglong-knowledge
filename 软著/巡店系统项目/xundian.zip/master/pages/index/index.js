import {
    dateFormat
} from '../../utils/util'
import config from '../../utils/config'
import QQMapWX from '../../utils/qqmap-wx-jssdk.min'
import * as commonApi from '../../api/common'
import * as xundianApi from '../../api/xundian'
var qqmapsdk;
const app = getApp();
var that;
Page({
    data: {
        /*nvabarData: {
            showCapsule: 1, 
            title: '我的',
          },*/
        devicePosition:"back",
        windowWidth: wx.getSystemInfoSync().windowWidth,
        tabbarHeight: 0,
        userInfo: null,
        model: {
            time: "",
            latitude: "",
            longitude: "",
            altitude: "",
            townId: "",
            townName: "",
            address: "",
            storeName: "",
            storeId:"",
            chainLev:"",
            shopTourType:"",
            chainName:"",
            brandName:"",
            classificationStr:"驻店活动",
            brandImgs:[],
            competitorsImgs:[],//竞品图片
            excellentImgs:[],//优秀陈列/培训图片
            goodsDisplayImgs:[],//产品陈列图
            interviewDisplayImgs:[],//走访陈列图
            inShopImgs:[],//到店图
            shopNameImgs:[],//门店名称图
            leaveShopImgs:[],//离店图
            salesLogImgs:[],//销售记录图
            inShopServiceImgs:[],//上门服务图片
            otherImgs:[],//其它
            classification:""
        },
        src: null,
        isShowPoiPage: false,
        poiList: [],
        currentTabIndex: -1,
        tabItemList: [{
                "text": "工作圈",
                "iconPath": "/images/icon/pengyouquan.svg",
                "selectedIconPath": "/images/icon/pengyouquan.svg",
                "pagePath": "/pages/xundian/record"
            },
            /* {
                "text": "团队",
                "iconPath": "/images/icon/team.svg",
                "selectedIconPath": "/images/icon/team.svg",
                "pagePath":"/pages/team/teamlist"
            }, */
            {
                "text": "我的",
                "iconPath": "/images/icon/my.svg",
                "selectedIconPath": "/images/icon/my.svg",
                "pagePath": "/pages/user/usercenter"
            }
        ],
        brandArray: ['欧姆龙', '小林', '优益诺', 'BD','三诺','佛山','其他','无'],
        brandCheckArray: [{name:'欧姆龙',value:'欧姆龙'},{name:'小林',value:'小林'},{name:'优益诺',value:'优益诺'},{name:'BD',value:'BD'},{name:'三诺',value:'三诺'},{name:'佛山',value:'佛山'},{name:'其他',value:'其他'},{name:'无',value:'无'}],
        serviceTypeArray: ['驻店活动', '上门服务'],
        isShowOtherBrandNameInput:false,
        brandIndex: 0,
        serviceTypeIndex:0,
        brandImgs:[],//品牌合作图片
        competitorsAImgs:[],//竞品图片
        excellentImgs:[],//优秀陈列/培训图片
        goodsDisplayImgs:[],//产品陈列图
        competitorsBImgs:[],//竞品信息图2
        interviewDisplayImgs:[],//走访陈列图
        inShopImgs:[],//到店图
        shopNameImgs:[],//门店名称图
        leaveShopImgs:[],//离店图
        salesLogImgs:[],//销售记录图
        inShopServiceImgs:[],//上门服务图片
        otherImgs:[],
    },
    onReady() {
        var that = this
        setInterval(() => {
            that.setData({
                "model.time": dateFormat(new Date(), "yyyy/MM/dd HH:mm:ss")
            });
            if (app.globalData.userInfo && !that.data.userInfo) {
                that.setData({
                    userInfo: app.globalData.userInfo
                })
            }
        }, 1000);
        this.createSelectorQuery().select('.tabbar').boundingClientRect(res => {
            this.setData({
                tabbarHeight: res.height
            })
        }).exec()
    },
    onLoad() {
        that = this;
        // 实例化API核心类
        qqmapsdk = new QQMapWX({
            key: config.qqMapKey
        });
        this.ctx = wx.createCameraContext()
        setInterval(() => {
            if (this.isGetLocation) {
                this.getLocation()
            }
        }, 1000 * 60*2);
        this.loadData();
        this.getLocation()
    },
    async loadData() {
        var res = await xundianApi.getPageData();
        this.xundianId = 0;
        this.setXundian(res.data)
    },
    setXundian(data) {
        data = data || {}
        this.xundianId = data.id;
        this.setData({
            "model.storeName": data.storeName || "",
            "model.id": data.id || "",
            "model.status": data.status || 2,
            "model.chainName": data.chainName || "",
            "model.chainLev": data.chainLevStr || "",
            "model.shopTourType": data.shopTourTypeStr || "",
            "model.classificationStr": data.classificationStr || "",
            "model.brandName": data.brandName || "",
            "model.otherBrandName":data.otherBrandName||"",
            "model.note": data.note || "",
            "model.storeId":data.storeId||"",
            "model.brandImgs":data.brandImgs||[],
            "model.competitorsAImgs":data.competitorsAImgs||[],
            "model.excellentImgs":data.excellentImgs||[],
            "model.goodsDisplayImgs":data.goodsDisplayImgs||[],
            "model.competitorsBImgs":data.competitorsBImgs||[],
            "model.interviewDisplayImgs":data.interviewDisplayImgs||[],
            "model.inShopImgs":data.inShopImgs||[],
            "model.shopNameImgs":data.shopNameImgs||[],
            "model.leaveShopImgs":data.leaveShopImgs||[],
            "model.salesLogImgs":data.salesLogImgs||[],
            "model.inShopServiceImgs":data.inShopServiceImgs||[],
            "model.otherImgs":data.otherImgs||[],
           
        })
        if(that.data.model.otherBrandName)
        {
            this.setData({
                isShowOtherBrandNameInput:true
            })
        }
        if(that.data.model.brandName)
        {
            const brandNames=that.data.model.brandName;
            var brandNamesArray=brandNames.split(',');
            const orginBrandNamesArray=that.data.brandCheckArray;
                if(brandNamesArray.length>0)
                {
                    for (let i = 0, lenI = orginBrandNamesArray.length; i < lenI; ++i) 
                    {
                        for (let j = 0, lenJ = brandNamesArray.length; j < lenJ; ++j) {
                            if (orginBrandNamesArray[i].value === brandNamesArray[j]) {
                                orginBrandNamesArray[i].checked = true;
                              break
                            }
                          }
                    }
                    this.setData({
                        brandCheckArray:orginBrandNamesArray
                    });
                }
        }
    },
    getLocation(callback) {
        that.setData({
            getLocationing: true
        })
        wx.getLocation({
            type: "gcj02",
            isHighAccuracy: true,
            altitude: true,
            success(res) {
                //res.latitude=26.271680000
                //res.longitude=117.645790000

                that.data.model.latitude = res.latitude;
                that.data.model.longitude = res.longitude;
                that.data.model.altitude = res.altitude;
                qqmapsdk.reverseGeocoder({
                    location: {
                        latitude: res.latitude,
                        longitude: res.longitude
                    },
                    get_poi: 1,
                    poi_options: "radius=500",
                    success(res) {
                        var res = res.result;
                        app.globalData.adInfo = res.ad_info;
                        that.data.model.cityId = res.ad_info.adcode.substr(0,4);
                        that.data.model.cityName = res.ad_info.city;
                        that.data.model.districtId = res.ad_info.adcode;
                        that.data.model.districtName = res.ad_info.district;
                        that.data.model.townId = res.address_reference.town.id;
                        that.data.model.townName = res.address_reference.town.title;
                        that.data.model.street = res.address_component.street;
                        that.data.model.street_number = res.address_component.street_number;

                        const item = res.pois[0]
                        //that.data.model.latitude = item.location && item.location.lat;
                        //that.data.model.longitude = item.location && item.location.lng;
                        that.data.model.address = item.address.replace(item.ad_info.province + item.ad_info.city + item.ad_info.district, "");
                        that.data.model.addressWaterMark = that.data.model.cityName + "·" + item.title
                        that.setData({
                            model: that.data.model,
                            poiList: res.pois
                        })
                        if (typeof callback === "function") {
                            callback()
                        }
                    }
                })
            },
            fail() {
                wx.showToast({
                    title: '获取位置失败,可稍后再试',
                    icon: "none"
                })
            },
            complete() {
                that.setData({
                    getLocationing: false
                })
            }
        });
    },
    login() {
        if (!app.globalData.userInfo) {
            commonApi.WXlogin();
        } else if (!app.globalData.isWxWork && !app.globalData.userInfo.nickName) {
            wx.getUserProfile({
                desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
                success: (res) => {
                    commonApi.updateBaseInfo(res.userInfo);
                    app.globalData.userInfo.nickName = res.userInfo.nickName;
                    app.globalData.userInfo.avatar = res.userInfo.avatarUrl;
                    that.setData({
                        userInfo: app.globalData.userInfo
                    })
                },
                fail: (err) => {
                    console.log(err)
                }
            })
        }
    },
    showPoiPage() {
        that.setData({
            isShowPoiPage: true
        });
    },
    selectPoi(e) {
        const item = e.currentTarget.dataset.item;
        //that.data.model.latitude = item.location && item.location.lat;
        //that.data.model.longitude = item.location && item.location.lng;
        that.data.model.address = item.address.replace(item.ad_info.province + item.ad_info.city + item.ad_info.district, "");
        that.data.model.addressWaterMark = that.data.model.cityName + "·" + item.title
        that.setData({
            model: that.data.model,
            isShowPoiPage: false
        })
    },
    showEditStorePage() {
        if(that.data.model.status==1)
        {
            wx.showToast({
                title: '请先结束本店巡店任务',
                icon: "error"
            })
            return false;
        }
        wx.navigateTo({
            url: `/pages/xundian/selectstore?townId=${that.data.model.townId}&latitude=${that.data.model.latitude}&longitude=${that.data.model.longitude}&storeName=${that.data.model.storeName}`,
        })
    },
    showEditShopTourTypePage()
    {
        if(that.data.model.status==1)
        {
            wx.showToast({
                title: '请先结束本店巡店任务',
                icon: "error"
            })
            return false;
        }
        wx.navigateTo({
            url: `/pages/xundian/selectshoptourtype`,
        })
    },
    showEditChainLevPage()
    {
        if((that.data.model.chainLev||that.data.model.chainLev=='0')&&that.data.model.storeId)
        {
            wx.showToast({
                title: '当前店铺已经设置了级别，不能重新选择',
                icon: "error"
            })
            return false;
        }
        wx.navigateTo({
            url: `/pages/xundian/selectchainlev`,
        })
    },
    setNote(e) {
        that.setData({
            "model.note": e.detail.value
        })
    },
    setChainName(e){
        that.setData({
            "model.chainName": e.detail.value
        })
    },
    setOtherBrandName(e)
    {
        that.setData({
            "model.otherBrandName": e.detail.value
        })
    },
    takePhoto() {
        if (!that.data.model.storeName) {
            wx.showToast({
                title: '请确认巡店店名',
                icon: "error"
            })
            return false;
        }
        if(!that.data.model.chainName)
        {
            wx.showToast({
                title: '请填写连锁名称',
                icon: "error"
            })
            return false;
        }
        if(!that.data.model.shopTourType)
        {
            wx.showToast({
                title: '请选择巡店方式',
                icon: "error"
            })
            return false;
        }
        if (!that.data.model.latitude || !that.data.model.longitude || !that.data.model.address) {
            this.getLocation()
            wx.showToast({
                title: '位置获取失败，请稍后再试',
                icon: "none"
            })
            return false;
        }
        if (!that.data.model.townId) {
            wx.showToast({
                title: '获取详细位置失败，请稍后再试',
                icon: "none"
            })
            return false;
        }
        this.setData({
            loading: true
        });
        // xundianApi.test(that.data.model).then(res=>{

        // })
        this.ctx.takePhoto({
            quality: 'high',
            success(res) {
                wx.showLoading({
                    title: '打卡中...',
                })
                xundianApi.clockin(that.data.model, res.tempImagePath).then(res => {
                    that.setXundian(res.data)
                    wx.showToast({
                        title: '打卡成功',
                    })
                }).finally(() => {
                    wx.hideLoading()
                    that.setData({
                        loading: false
                    });
                });
            },
            complete() {
                that.setData({
                    loading: false
                });
            }
        })
        return false;
    },
    onEndTask() {
        wx.showModal({
            title: "提示",
            content: "确定要结束本店任务吗？",
            success(e) {
                if (e.confirm) {
                    if(that.data.model.shopNameImgs.length==0&&that.data.model.shopTourType!='其它')
                        {
                                wx.showToast({
                                    title: '请上传门店名称图',
                                    icon: "none"
                                })
                                return false;
                        }
                    if(that.data.model.shopTourType=='日常拜访'&&that.data.model.chainLev=='A')
                        {
                            if(that.data.isShowOtherBrandNameInput&&!that.data.model.otherBrandName)
                            {
                                wx.showToast({
                                    title: '请填写其他品牌名称',
                                    icon: "none"
                                })
                                return false;
                            }
                            if(that.data.model.brandImgs.length==0&&that.data.model.brandName!='无')
                            {
                                wx.showToast({
                                    title: '请上传合作品牌图片信息',
                                    icon: "none"
                                })
                                return false;
                            }
                            if(that.data.model.brandImgs.length<3&&that.data.model.brandName!='无')
                            {
                                wx.showToast({
                                    title: '合作品牌图片不少于3张',
                                    icon: "none"
                                })
                                return false;
                            }
                            if(that.data.model.competitorsAImgs.length==0)
                            {
                                wx.showToast({
                                    title: '请上传竞品图片信息',
                                    icon: "none"
                                })
                                return false;
                            }
                            if(that.data.model.excellentImgs.length==0)
                            {
                                wx.showToast({
                                    title: '请上传优秀陈列/培训图片信息',
                                    icon: "none"
                                })
                                return false;
                            }
                            if(!that.data.model.note)
                            {
                                wx.showToast({
                                    title: '请填写走访总结',
                                    icon: "none"
                                })
                                return false;
                            }
                            that.data.model.competitorsImgs=that.data.model.competitorsAImgs;
                            //that.data.model.brandName=that.data.model.brandNameStr
                            that.data.model.classification= that.data.model.chainLev;
                        }
                        if(that.data.model.shopTourType=='日常拜访'&&that.data.model.chainLev=='B')
                        {
                            if(that.data.model.goodsDisplayImgs.length==0)
                            {
                                wx.showToast({
                                    title: '请上传产品陈列图片信息',
                                    icon: "none"
                                })
                                return false;
                            }
                            if(that.data.model.goodsDisplayImgs.length<2)
                            {
                                wx.showToast({
                                    title: '产品陈列图片不少于2张',
                                    icon: "none"
                                })
                                return false;
                            }
                            if(that.data.model.competitorsBImgs.length==0)
                            {
                                wx.showToast({
                                    title: '请上传竞品图片信息',
                                    icon: "none"
                                })
                                return false;
                            }
                            if(!that.data.model.note)
                            {
                                wx.showToast({
                                    title: '请填写走访总结',
                                    icon: "none"
                                })
                                return false;
                            }
                            that.data.model.competitorsImgs=that.data.model.competitorsBImgs;
                            that.data.model.classification= that.data.model.chainLev;
                        }
                        if(that.data.model.shopTourType=='日常拜访'&&that.data.model.chainLev=='C')
                        {
                            if(that.data.model.interviewDisplayImgs.length==0)
                            {
                                wx.showToast({
                                    title: '请上传走访陈列图片信息',
                                    icon: "none"
                                })
                                return false;
                            }
                            if(!that.data.model.note)
                            {
                                wx.showToast({
                                    title: '请填写走访总结',
                                    icon: "none"
                                })
                                return false;
                            }
                            that.data.model.classification= that.data.model.chainLev;
                        }
                        if(that.data.model.shopTourType=='增值服务'&&that.data.model.classificationStr=='驻店活动')
                        {
                            if(that.data.model.inShopImgs.length==0)
                            {
                                wx.showToast({
                                    title: '请上传到店图片信息',
                                    icon: "none"
                                })
                                return false;
                            }
                            
                            if(that.data.model.salesLogImgs.length==0)
                            {
                                wx.showToast({
                                    title: '请上传销售记录图片信息',
                                    icon: "none"
                                })
                                return false;
                            }
                            if(that.data.model.leaveShopImgs.length==0)
                            {
                                wx.showToast({
                                    title: '请上传离店图片信息',
                                    icon: "none"
                                })
                                return false;
                            }
                            
                            that.data.model.classification=that.data.model.classificationStr
                        }
                        if(that.data.model.shopTourType=='增值服务'&&that.data.model.classificationStr=='上门服务')
                        {
                            if(that.data.model.inShopServiceImgs.length==0)
                            {
                                wx.showToast({
                                    title: '请上传上门服务图片信息',
                                    icon: "none"
                                })
                                return false;
                            }
                            that.data.model.classification=that.data.model.classificationStr
                        }
                        if(that.data.model.shopTourType=='其它')
                        {
                            if(that.data.model.otherImgs.length==0)
                            {
                                wx.showToast({
                                  title: '请至少上传一张图片',
                                  icon:"none"
                                })
                                return false;
                            }
                            that.data.model.classification= that.data.model.chainLev;
                        }
                        that.data.model.id= that.xundianId;
                    xundianApi.newEndTask(that.data.model).then(res => {
                        wx.showToast({
                            title: '操作成功',
                            icon: "success"
                        })
                        if (res.data) {
                            that.onLoad()
                            that.setXundian({});
                            that.setData({
                                "model.note": "",
                                "model.chainName": "",
                                "model.shopTourType": "",
                                "model.chainLev":"",
                                "model.brandImgs":[],
                                "model.competitorsImgs":[],
                                "model.competitorsAImgs":[],
                                "model.competitorsBImgs":[],
                                "model.excellentImgs":[],
                                "model.goodsDisplayImgs":[],
                                "model.interviewDisplayImgs":[],
                                "model.inShopImgs":[],
                                "model.shopNameImgs":[],
                                "model.leaveShopImgs":[],
                                "model.salesLogImgs":[],
                                "model.inShopServiceImgs":[],
                                "model.otherImgs":[],
                                "model.classification":""
                            })
                            
                        }
                    })
                }
            }
        })
    },
    reverse(){
        this.devicePosition=this.devicePosition=="front"?"back":"front";
        this.setData({"devicePosition": this.devicePosition});
    },
    error(e) {
        this.setData({
            loading: false
        });
    },
    tabChange(e) {
        this.setData({
            currentTabIndex: -1
        })
        if (e.detail.item.pagePath) {
            wx.navigateTo({
                url: e.detail.item.pagePath,
            })
        }
    },
    onShow() {
        this.isGetLocation = true
        // 0为竖屏，1为横屏
        wx.startDeviceMotionListening({
            success:function(e){
              wx.onDeviceMotionChange(function(res){
                //console.log(res)
                var isHorizontal=0;
                //手机横屏使用
                if(res.gamma > 40){
                    isHorizontal=1;
                }
                if (res.gamma < -40){
                    isHorizontal=2;
                }
                that.data.model.isHorizontal=isHorizontal
                that.data.model.alpha=res.alpha
                that.data.model.beta=res.beta
                that.data.model.gamma=res.gamma
                //console.log(isHorizontal)
              })
            },
            fail:function(e){
              //关闭面板
            }
          })
    },
    onHide() {
        this.isGetLocation = false
        wx.stopDeviceMotionListening()
    },
    //下拉选中赋值
    bindPickerBrandChange: function(e) {
        var brandName= that.data.brandArray[e.detail.value]
        this.setData({
          "model.brandName": brandName
        })
      },
      bindPickerServiceTypeChange: function(e) {
        var classificationStr= that.data.serviceTypeArray[e.detail.value]
        this.setData({
          "model.classificationStr": classificationStr
        })
      },
       getBrandUploaderList(e) {
        var brandImgs = this.data.brandImgs;
        var _this = this;
        _this.setData({
            "model.brandImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.classification= _this.data.model.chainLev;
            _this.updataImgList();
        }
      },
      getCompetitorsUploaderList(e) {
        var competitorsAImgs = this.data.competitorsAImgs;
        var _this = this;
        _this.setData({
            "model.competitorsAImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.competitorsImgs=_this.data.model.competitorsAImgs;
            _this.data.model.classification= _this.data.model.chainLev;
            _this.updataImgList();
        }
      },
      getExcellentUploaderList(e) {
        var excellentImgs = this.data.excellentImgs;
        var _this = this;
        _this.setData({
            "model.excellentImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.classification= _this.data.model.chainLev;
            _this.updataImgList();
        }
      },
      getGoodsDisplayUploaderList(e) {
        var goodsDisplayImgs = this.data.goodsDisplayImgs;
        var _this = this;
        _this.setData({
            "model.goodsDisplayImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.classification= _this.data.model.chainLev;
            _this.updataImgList();
        }
      },
      getCompetitorsBUploaderList(e) {
        var competitorsBImgs = this.data.competitorsBImgs;
        var _this = this;
        _this.setData({
            "model.competitorsBImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.competitorsImgs=_this.data.model.competitorsBImgs;
            _this.data.model.classification= _this.data.model.chainLev;
            _this.updataImgList();
        }
      },
      getInterviewDisplayUploaderList(e) {
        var interviewDisplayImgs = this.data.interviewDisplayImgs;
        var _this = this;
        _this.setData({
            "model.interviewDisplayImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.classification= _this.data.model.chainLev;
            _this.updataImgList();
        }
      },
      getInShopUploaderList(e) {
        var inShopImgs = this.data.inShopImgs;
        var _this = this;
        _this.setData({
            "model.inShopImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.classification= _this.data.model.classificationStr;
            _this.updataImgList();
        }
      },
      getshopNameImgList(e) {
        var shopNameImgs = this.data.shopNameImgs;
        var _this = this;
        _this.setData({
            "model.shopNameImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.classification= _this.data.model.classificationStr;
            _this.updataImgList();
        }
      },
      getLeaveShopUploaderList(e) {
        var leaveShopImgs = this.data.leaveShopImgs;
        var _this = this;
        _this.setData({
            "model.leaveShopImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.classification= _this.data.model.classificationStr;
            _this.updataImgList();
        }
      },
      getSalesLogUploaderList(e) {
        var salesLogImgs = this.data.salesLogImgs;
        var _this = this;
        _this.setData({
            "model.salesLogImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.classification= _this.data.model.classificationStr;
            _this.updataImgList();
        }
      },
      getInShopServiceUploaderList(e)
      {
        var inShopServiceImgs = this.data.inShopServiceImgs;
        var _this = this;
        _this.setData({
            "model.inShopServiceImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.classification= _this.data.model.classificationStr;
            _this.updataImgList();
        }
      },
      getOtherUploaderList(e)
      {
        var otherImgs = this.data.otherImgs;
        var _this = this;
        _this.setData({
            "model.otherImgs": e.detail.uploaderList
        })
        if(_this.data.model.id>0)
        {
            _this.data.model.classification= _this.data.model.classificationStr;
            _this.updataImgList();
        }
      },
      saveClockIn(){
          if (this.data.model.status == 1) {
            wx.showToast({
                title: '请先结束本次巡店任务',
                icon: "none"
            });
            return false;
        }
        if (!that.data.model.storeName) {
            wx.showToast({
                title: '请确认巡店店名',
                icon: "error"
            })
            return false;
        }
        if(!that.data.model.chainName)
        {
            wx.showToast({
                title: '请填写连锁名称',
                icon: "error"
            })
            return false;
        }
        if(!that.data.model.chainLev||that.data.model.chainLev=='0')
        {
            wx.showToast({
                title: '请选择门店级别',
                icon: "error"
            })
            return false;
        }
        if(!that.data.model.shopTourType)
        {
            wx.showToast({
                title: '请填选择巡店方式',
                icon: "error"
            })
            return false;
        }
        if (!that.data.model.latitude || !that.data.model.longitude || !that.data.model.address) {
            this.getLocation()
            wx.showToast({
                title: '位置获取失败，请稍后再试,地址：['+latitude+';'+that.data.model.longitude+';'+that.data.model.address+']',
                icon: "none"
            })
            return false;
        }
        if (!that.data.model.townId) {
            wx.showToast({
                title: '获取详细位置失败，请稍后再试',
                icon: "none"
            })
            return false;
        }
        if(that.data.model.shopTourType=='日常拜访'&&that.data.model.chainLev=='A')
        {
            if(!that.data.model.brandName)
            {
                wx.showToast({
                    title: '请选择合作品牌',
                    icon: "none"
                })
                return false;
            }
            if(that.data.isShowOtherBrandNameInput&&!that.data.model.otherBrandName)
            {
                wx.showToast({
                    title: '请填写其他品牌名称',
                    icon: "none"
                })
                return false;
            }
            that.data.model.competitorsImgs=that.data.model.competitorsAImgs;
            that.data.model.classification= that.data.model.chainLev;
        }
        if(that.data.model.shopTourType=='日常拜访'&&that.data.model.chainLev=='B')
        {
            that.data.model.competitorsImgs=that.data.model.competitorsBImgs;
            that.data.model.classification= that.data.model.chainLev;
        }
        if(that.data.model.shopTourType=='日常拜访'&&that.data.model.chainLev=='C')
        {
            that.data.model.classification= that.data.model.chainLev;
        }
        if(that.data.model.shopTourType=='增值服务'&&(!that.data.model.classificationStr))
        {
            
            wx.showToast({
                title: '请选择方式',
                icon: "none"
            })
            return false; 
        }
        if(that.data.model.shopTourType=='增值服务'&&that.data.model.classificationStr=='驻店活动')
        {
            if(!that.data.model.classificationStr)
            {
                wx.showToast({
                    title: '请选择方式',
                    icon: "none"
                })
                return false; 
            }
            that.data.model.classification=that.data.model.classificationStr
        }
        if(that.data.model.shopTourType=='增值服务'&&that.data.model.classificationStr=='上门服务')
        {
            that.data.model.classification=that.data.model.classificationStr
        }
        this.setData({
            loading: true
        });
        xundianApi.saveServiceClockIn(that.data.model).then(res=>{
            that.setXundian(res.data)
            wx.showToast({
                title: '打卡成功',
            })
        }).finally(()=>{
            wx.hideLoading()
            that.setData({
                loading: false
            });
        })
      },
      updataImgList()
      {
        if(that.data.model.chainLev=='A'&&that.data.model.shopTourType=='日常拜访')
        {
            that.data.model.competitorsImgs=that.data.model.competitorsAImgs
        }
        if(that.data.model.chainLev=='B'&&that.data.model.shopTourType=='日常拜访')
        {
            that.data.model.competitorsImgs=that.data.model.competitorsBImgs
        }

        xundianApi.updataImgList(that.data.model).then(res=>{
            if(that.data.model.chainLev=='A'&&that.data.model.shopTourType=='日常拜访')
            {
                res.data.otherBrandName=that.data.model.otherBrandName;
                res.data.brandName=that.data.model.brandName;
            }
           that.setXundian(res.data)
        }).finally(()=>{
            wx.hideLoading()
            that.setData({
                loading: false
            });
        })
      },
      checkBrand(e)
      {
        var brandNames="";
        const items = this.data.brandCheckArray
        const values = e.detail.value
        for (let i = 0, lenI = items.length; i < lenI; ++i) {
            items[i].checked = false
            for (let j = 0, lenJ = values.length; j < lenJ; ++j) {
              if (items[i].value === values[j]) {
                items[i].checked = true;
                brandNames+=items[i].value+',';
                break
              }
            }
            if(items[i].value=='其他')
            {
                if(items[i].checked)
                {
                    this.setData({
                        isShowOtherBrandNameInput:true
                      })
                }else
                {
                    this.setData({
                        isShowOtherBrandNameInput:false,
                       
                      })
                }
            }
          }
          this.setData({
            brandCheckArray:items
          })
          this.setData({
              "model.brandName":brandNames.substring(0, brandNames.lastIndexOf(','))
          })
      }
})