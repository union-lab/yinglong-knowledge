import * as config from './config.js';
const envVersion =  wx.getAccountInfoSync().miniProgram.envVersion;
const service = {}
service.get = (url, data) => {
    if (data && typeof data === "object") {
        for (var item in data) {
            if (data[item] == null || data[item] == undefined) {
                delete data[item]
            }
        }
    }
    return service.request(url, data, "get");
}
service.post = (url, data) => {
    return service.request(url, data, "post");
}
service.put = (url, data) => {
    return service.request(url, data, "put");
}
service.delete = (url, data) => {
    return service.request(url, data, "delete");
}

service.request = (url, data, method) => {
    var token = wx.getStorageSync(config.tokenKey);
    return new Promise((resolve, reject) => {
        wx.request({
            url: config.baseUrl[envVersion] + url,
            header: {
                Authorization: `Bearer ${token}`
            },
            method: method,
            data: data,
            success(res) {
                return success(res, resolve, reject)
            },
            fail(err) {
                return fail(err, resolve, reject)
            }
        })
    });
}
service.uploadFile = (url, filePath, data) => {
    return new Promise((resolve, reject) => {
        wx.uploadFile({
            filePath: filePath,
            name: 'imageFile',
            //url: config.baseUrl + url+(url.indexOf("?")>-1?":":"?")+jsonToParam(data),
            url: config.baseUrl[envVersion] + url,
            formData: data,
            header: {
                Authorization: `Bearer ${wx.getStorageSync(config.tokenKey)}`
            },
            dataType: "json",
            success(res) {
                if (res.statusCode === 200) {
                    res.data = JSON.parse(res.data);
                }
                return success(res, resolve, reject)
            },
            fail(err) {
                return fail(err, resolve, reject)
            }
        })
    });
}
service.uploadImgFile = (url, filePath,data) => {
    return new Promise((resolve, reject) => {
        wx.uploadFile({
            filePath: filePath,
            name: 'imageFile',
            formData: data,
            //url: config.baseUrl + url+(url.indexOf("?")>-1?":":"?")+jsonToParam(data),
            url: config.baseUrl[envVersion] + url,
            header: {
                Authorization: `Bearer ${wx.getStorageSync(config.tokenKey)}`
            },
            dataType: "json",
            success(res) {
                if (res.statusCode === 200) {
                    res.data = JSON.parse(res.data);
                }
                return success(res, resolve, reject)
            },
            fail(err) {
                return fail(err, resolve, reject)
            }
        })
    });
}
const success = (response, resolve, reject) => {
    var res = response.data;
    if (response.statusCode == 200) {
        if (res.code == 200) {
            return resolve(res);
        } else if (res.code == 401) {
            wx.setStorage(config.tokenKey, "");
            var app = getApp();
            app.globalData.userInfo = null
        }
    }

    const msg = res.msg || `StatusCode:${response.statusCode}`;
    if (res && res.code == 401) {
        wx.showToast({
            title: '登录信息已失效',
            icon: "error",
            duration: 3000
        })
    } else {
        wx.showModal({
            title: "错误",
            content: msg,
            showCancel: false
        })
    }
    return reject(new Error(msg));
}
const fail = (error, resolve, reject) => {
    wx.showModal({
        title: "错误",
        content: error.errMsg,
        showCancel: false
    })
    return reject(error);
}
export default service;