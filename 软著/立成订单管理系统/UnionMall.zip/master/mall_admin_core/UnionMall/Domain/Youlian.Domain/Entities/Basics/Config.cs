using Youlian.Domain.Enums;
using SqlSugar;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 
    /// </summary>
    [SugarTable("t_basics_config")]
    public class Config : ModifyEntity
    {
        /// <summary>
        /// 配置类型(0总控端,1商家端,2试客端,3分站端)
        /// </summary>
        public ConfigTypeEnum ConfigType { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// 配置的KEY
        /// </summary>
        public string ConfigKey { get; set; }

        /// <summary>
        /// 配置的值
        /// </summary>
        public string ConfigValue { get; set; }
    }
}