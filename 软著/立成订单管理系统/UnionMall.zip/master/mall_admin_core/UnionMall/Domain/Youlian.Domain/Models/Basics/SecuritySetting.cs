﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Models.Basics
{
    /// <summary>
    /// 安全设置
    /// </summary>
    public class SecuritySetting : IBasicsConfig
    {
        /// <summary>
        /// 资金密码
        /// </summary>
        public string BalancePassword { get; set; }
    }
}
