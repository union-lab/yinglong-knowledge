﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response.MallSetting
{
    public class BannerPageResponse
    {
        public int Id { get; set; }
        public string ImgUrl { get; set; }
        public string PageUrl { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public int? Sort { get; set; }
        /// <summary>
        /// 是否展示
        /// </summary>
        public bool IsShow { get; set; }
        public DateTime? AddTime { get; set; }
        /// <summary>
        /// 所属商品分类id
        /// </summary>
        public int GoodsCategoryId { get; set; }
        public string GoodsCategoryName { get; set; }
    }
}
