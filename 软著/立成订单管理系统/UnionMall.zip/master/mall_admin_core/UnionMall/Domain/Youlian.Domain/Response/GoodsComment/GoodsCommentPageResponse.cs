﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    public class GoodsCommentPageResponse
    {
        public int Id { get; set; }
        /// <summary>
        /// 评价图片集
        /// </summary>
        public string[] ImagesArr { get; set; }
        /// <summary>
        /// 用户Id
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 商品Id
        /// </summary>
        public int GoodsId { get; set; }
        /// <summary>
        /// 订单号
        /// </summary>
        public string OrderId { get; set; }
        /// <summary>
        /// 用户头像
        /// </summary>
        public string UserImage { get; set; }
        /// <summary>
        /// 用户昵称
        /// </summary>
        public string UserNick { get; set; }
        /// <summary>
        /// 用户手机号码
        /// </summary>
        public string UserPhone { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        public string GoodsName { get; set; }
        /// <summary>
        /// 评价等级
        /// </summary>
        public int Score { get; set; }
        /// <summary>
        /// 评价内容
        /// </summary>
        public string ContentBody { get; set; }
        /// <summary>
        /// 商家回复内容
        /// </summary>
        public string SellerContent { get; set; }
        /// <summary>
        /// 是否展示客户端
        /// </summary>
        public bool? IsDisplay { get; set; }
        /// <summary>
        /// 添加时间
        /// </summary>
        public DateTime AddTime { get; set; }
    }
}
