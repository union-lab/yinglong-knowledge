﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 企业微信登录
    /// </summary>
    public class WorkWeixinLoginResponse
    {
        /// <summary>
        /// 是否已登录
        /// </summary>
        public bool IsAuthenticated { get; set; }
        /// <summary>
        /// 授权登录地址
        /// </summary>
        public string AuthorizeUrl { get; set; }
    }
}
