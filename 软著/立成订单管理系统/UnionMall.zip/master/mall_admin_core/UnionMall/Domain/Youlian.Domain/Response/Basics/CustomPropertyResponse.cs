﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Request;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomPropertyResponse
    {
        /// <summary>
        /// 记录ID
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 属性名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 属性值类型
        /// </summary>
        public string ValueType { get; set; }
        /// <summary>
        /// 实体类型
        /// </summary>
        public CustomPropertyEntityTypeEnum EntityType { get; set; }
    }

    /// <summary>
    /// 自定义属性值
    /// </summary>
    public class EntityCustomPropertyResponse
    {
        /// <summary>
        /// 记录ID
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 属性名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 属性值类型
        /// </summary>
        public string ValueType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Value { get; set; }
    }
}