using Youlian.Domain.Enums;
using SqlSugar;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 自定义属性
    /// </summary>
    [SugarTable("t_custom_property")]
    public class CustomProperty : ModifyDeleteEntity
    {
        /// <summary>
        /// 属性名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 属性值类型
        /// </summary>
        public string ValueType { get; set; }
        /// <summary>
        /// 实体类型
        /// </summary>
        public CustomPropertyEntityTypeEnum EntityType { get; set; }
    }
}