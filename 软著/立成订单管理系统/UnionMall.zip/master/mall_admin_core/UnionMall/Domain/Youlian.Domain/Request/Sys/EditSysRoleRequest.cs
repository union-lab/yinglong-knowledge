﻿using Microsoft.AspNetCore.Mvc;
using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request.Sys
{
    /// <summary>
    /// 编辑角色参数
    /// </summary>
    public class EditSysRoleRequest
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string RoleName { get; set; }

        /// <summary>
        /// 备注说明
        /// </summary>
        public string Description { get; set; }
    }
}
