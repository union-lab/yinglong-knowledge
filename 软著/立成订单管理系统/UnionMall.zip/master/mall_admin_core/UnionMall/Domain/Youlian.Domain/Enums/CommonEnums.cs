﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Enums
{
    /// <summary>
    /// 短信类型
    /// </summary>
    public enum SmsTypeEnum
    {
        /// <summary>
        /// 
        /// </summary>
        注册验证码 = 1,
        /// <summary>
        /// 
        /// </summary>
        登录验证码 = 2,

        /// <summary>
        /// 
        /// </summary>
        重置密码 = 3,
    }

    /// <summary>
    /// 验证码状态
    /// </summary>
    public enum SmsLogStatusEnum
    {
        /// <summary>
        /// 
        /// </summary>
        未使用 = 0,
        /// <summary>
        /// 
        /// </summary>
        已使用 = 1
    }
    /// <summary>
    /// 启用状态
    /// </summary>
    public enum EnabledEnum
    {
        /// <summary>
        /// 
        /// </summary>
        禁用=0,
        /// <summary>
        /// 
        /// </summary>
        启用=1
    }
}
