﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomPropertyPageRequest : PageRequest
    {
        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public CustomPropertyEntityTypeEnum EntityType { get; set; }
    }
}
