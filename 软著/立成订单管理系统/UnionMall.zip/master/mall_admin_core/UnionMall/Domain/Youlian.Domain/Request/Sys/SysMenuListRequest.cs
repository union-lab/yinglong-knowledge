﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request.Sys
{
    /// <summary>
    /// 请求菜单列表参数
    /// </summary>
    public class SysMenuListRequest
    {
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }
    }
}
