﻿using Microsoft.AspNetCore.Mvc;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 分页参数
    /// </summary>
    public class PageRequest
    {
        /// <summary>
        /// 当前页
        /// </summary>
        public int PageIndex { get; set; } = 1;

        /// <summary>
        /// 每页总条数
        /// </summary>
        public int PageSize { get; set; } = 20;

        /// <summary>
        /// 排序方式
        /// </summary>
        public string OrderBy { get; set; } = "desc";

        /// <summary>
        /// 排序字段
        /// </summary>
        public string Sort { get; set; } = "id";

    }
}
