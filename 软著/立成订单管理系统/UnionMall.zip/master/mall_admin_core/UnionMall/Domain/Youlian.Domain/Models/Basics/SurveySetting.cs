﻿using Youlian.Domain.Enums;
using System.Collections.Generic;
using System.ComponentModel;

namespace Youlian.Domain.Models.Basics
{
    /// <summary>
    /// 问卷投票配置
    /// </summary>
    public class SurveySetting : IBasicsConfig
    {
        /// <summary>
        /// 允许发布用户
        /// </summary>
        public IList<int> AllowReleaseUserIds { get; set; } = new List<int>();
        /// <summary>
        /// 是否开启问卷
        /// </summary>
        public bool IsOpenQuestions { get; set; } = false;
        /// <summary>
        /// 是否开启抽奖
        /// </summary>
        public bool IsOpenWinning { get; set; } = false;
        /// <summary>
        /// 抽奖次数
        /// </summary>
        public int WinningCount { get; set; } = 1;
    }
}
