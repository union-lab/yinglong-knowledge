﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 微信登录参数
    /// </summary>
    public class WeixinLoginRequest
    {
        [Required]
        public string Code { get; set; }
        /// <summary>
        /// 自定义参数值返回
        /// </summary>
        public string State { get; set; }
    }
}
