﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    public class BannerPageRequest : PageRequest
    {
        /// <summary>
        /// 是否展示
        /// </summary>
        public bool? IsShow { get; set; }
    }
}
