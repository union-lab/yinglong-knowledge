﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 微信js sdk 配置
    /// </summary>
    public class WxJsSdkConfigReponse
    {
        /// <summary>
        /// 必须这么写，否则wx.invoke调用形式的jsapi会有问题
        /// </summary>
        public bool Bate { get; set; }
        /// <summary>
        /// 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        /// </summary>
        public bool Debug { get; set; }
        /// <summary>
        /// 必填，企业微信的corpID
        /// </summary>
        public string AppId { get; set; }
        /// <summary>
        /// 必填，生成签名的时间戳
        /// </summary>
        public int Timestamp { get; set; }
        /// <summary>
        /// 必填，生成签名的随机串
        /// </summary>
        public string NonceStr { get; set; }
        /// <summary>
        /// 必填，签名，见 附录-JS-SDK使用权限签名算法
        /// </summary>
        public string Signature { get; set; }

    }
}
