using Youlian.Domain.Enums;
using SqlSugar;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 
    /// </summary>
    [SugarTable("t_sys_role")]
    public class SysRole : BaseEntity, IHasCreatorId
    {
        /// <summary>
        /// ����
        /// </summary>
        public string RoleName { get; set; }

        /// <summary>
        /// �Ƿ�ϵͳ1:�ǣ�0����
        /// </summary>
        public int IsSys { get; set; } = 0;

        /// <summary>
        /// ��ע˵��
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// ������Id
        /// </summary>
        public int CreatorId { get; set; }
    }
}