﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response.Sys
{
    /// <summary>
    /// 
    /// </summary>
    public class SysRoleResponse
    {
        /// <summary>
        /// 
        /// </summary>
        public int RoleId { get; set; }
        /// <summary>
        /// 名称
        /// </summary>
        public string RoleName { get; set; }

        /// <summary>
        /// 是否系统1:是，0：否
        /// </summary>
        public int IsSys { get; set; } = 0;

        /// <summary>
        /// 备注说明
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// 创建者Id
        /// </summary>
        public int CreatorId { get; set; }
    }
}
