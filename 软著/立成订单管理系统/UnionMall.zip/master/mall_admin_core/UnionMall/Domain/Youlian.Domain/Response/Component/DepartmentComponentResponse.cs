﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;
using Newtonsoft.Json;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 部门信息
    /// </summary>
    public class DepartmentComponentResponse
    {
        /// <summary>
        /// ID
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 部门名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 部门负责人的EmployeeId
        /// </summary>
        public int LeaderEmployeeId { get; set; }

        /// <summary>
        /// 部门负责人姓名
        /// </summary>
        public string LeaderRealName { get; set; }
    }
}
