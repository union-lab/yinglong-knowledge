﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 商品货品表
    /// </summary>
    [SugarTable("t_goodsproducts")]
    public class GoodsProducts:ModifyEntity
    {
        /// <summary>
        /// 关联商品表id t_goods.id
        /// </summary>
        public int GoodsId { get; set; }
        /// <summary>
        /// 商品条码
        /// </summary>
        public string BarCode { get; set; }
        /// <summary>
        /// 货品编码
        /// </summary>
        public string Sn { get; set; }
        /// <summary>
        /// 货品价格
        /// </summary>
        public decimal Price { get; set; }
        /// <summary>
        /// 货品成本价
        /// </summary>
        public decimal CostPrice { get; set; }
        /// <summary>
        /// 货品市场价
        /// </summary>
        public decimal MktPrice { get; set; }
        /// <summary>
        /// 是否上架
        /// </summary>
        public bool IsMarketable { get; set; }
        /// <summary>
        /// 重量（千克）
        /// </summary>
        public decimal Weight { get; set; }
        /// <summary>
        /// 库存
        /// </summary>
        public int Stock { get; set; }
        /// <summary>
        /// 冻结库存
        /// </summary>
        public int FreezeStock { get; set; }
        /// <summary>
        /// sku模型值
        /// </summary>
        public string SkuModelValue { get; set; }
        /// <summary>
        /// 是否默认
        /// </summary>
        public bool IsDefalut { get; set; }
        /// <summary>
        /// 货品图片
        /// </summary>
        public string Image { get; set; }
        /// <summary>
        /// 是否删除
        /// </summary>
        public bool Deleted { get; set; }
    }
}
