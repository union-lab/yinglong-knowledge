﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Models.Basics
{
    /// <summary>
    /// 系统设置
    /// </summary>
    public class SystemSetting : IBasicsConfig
    {
        /// <summary>
        /// 管理者
        /// </summary>
        public string Manager { get; set; }
    }
}
