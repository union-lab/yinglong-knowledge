﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request.Basics
{
    /// <summary>
    /// 保存设置参数
    /// </summary>
    public class EditSecuritySettingsRequest
    {
        /// <summary>
        /// 旧密码
        /// </summary>
        public string OldBalancePassword { get; set; }
        /// <summary>
        /// 新密码
        /// </summary>
        public string BalancePassword { get; set; }
    }
}
