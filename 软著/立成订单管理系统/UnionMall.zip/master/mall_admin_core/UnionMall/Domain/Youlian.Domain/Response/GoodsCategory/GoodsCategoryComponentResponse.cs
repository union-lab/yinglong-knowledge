﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    public class GoodsCategoryComponentResponse
    {
        public object value { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string label { get; set; }
        public List<GoodsCategoryComponentResponse> Children { get; set; }
    }
}
