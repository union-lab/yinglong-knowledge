﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 
    /// </summary>
    public class WeixinOauth2AuthorizeResponse
    {
        /// <summary>
        /// 授权登录地址
        /// </summary>
        public string AuthorizeUrl { get; set; }
    }
}
