﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 审核参数
    /// </summary>
    public class AuditRequest
    {

        /// <summary>
        /// 记录ID
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 是否通过
        /// </summary>
        public bool IsAdopt { get; set; }

        /// <summary>
        /// 是否自动审核
        /// </summary>
        public bool IsAutomatic { get; set; }

        /// <summary>
        /// 审核用户ID
        /// </summary>
        public int CheckUserId { get; set; }

        /// <summary>
        /// 审核用户名
        /// </summary>
        public string CheckUserName { get; set; }

        /// <summary>
        /// 审核备注
        /// </summary>
        public string CheckNote { get; set; }

        /// <summary>
        /// IP地址
        /// </summary>
        public string IPAddress { get; set; }

    }
}
