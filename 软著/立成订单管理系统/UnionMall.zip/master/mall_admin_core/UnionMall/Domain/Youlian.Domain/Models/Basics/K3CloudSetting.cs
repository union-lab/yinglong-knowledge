﻿using Youlian.Domain.Enums;
using System.Collections.Generic;
using System.ComponentModel;
using System;
using Youlian.Common.Extention;
using System.Linq;

namespace Youlian.Domain.Models.Basics
{
    /// <summary>
    /// 金蝶云星空对接设置
    /// </summary>
    public class K3CloudSetting : IBasicsConfig
    {
        /// <summary>
        /// 开启应收单部门产品成本管理
        /// </summary>
        public bool OpenDeptCostTask { get; set; }

        /// <summary>
        /// 当前已处理订单明细ID
        /// </summary>
        public int CurOrderDetailId { get; set; }

        /// <summary>
        /// 当前已处理应收单明细ID
        /// </summary>
        public int CurReceivableDetailId { get; set; }

        /// <summary>
        /// 最后执行时间
        /// </summary>
        public DateTime? LastExecTime { get; set; }
    }
}
