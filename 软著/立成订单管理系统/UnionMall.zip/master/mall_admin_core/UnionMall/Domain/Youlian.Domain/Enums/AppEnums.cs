﻿using System.ComponentModel;

namespace Youlian.Domain.Enums
{
    /// <summary>
    /// 更新APP类型
    /// </summary>
    public enum AppUpdateTypeEnum
    {
        /// <summary>
        /// 
        /// </summary>
        [Description("版本更新")]
        版本更新 = 0,
        /// <summary>
        /// 
        /// </summary>
        [Description("三方推广")]
        三方推广 = 1,
    }

    /// <summary>
    /// App更新方式
    /// </summary>
    public enum AppUpdatePatternEnum
    {
        /// <summary>
        /// 正常更新
        /// </summary>
        [Description("正常更新")]
        正常更新 = 0,
        /// <summary>
        /// 静默更新
        /// </summary>
        [Description("静默更新")]
        静默更新 = 1,
        /// <summary>
        /// 强制更新
        /// </summary>
        [Description("强制更新")]
        强制更新 = 2
    }

    /// <summary>
    /// 安装包类型
    /// </summary>
    public enum ApkTypeEnum
    {
        /// <summary>
        /// 
        /// </summary>
        [Description("WGT")]
        WGT = 1,
        /// <summary>
        /// 
        /// </summary>
        [Description("APP")]
        APP = 2,
    }
}
