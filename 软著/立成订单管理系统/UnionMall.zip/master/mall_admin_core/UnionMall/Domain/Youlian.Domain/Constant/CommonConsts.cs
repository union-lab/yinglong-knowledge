﻿namespace Youlian.Domain.Constant
{
    /// <summary>
    /// 公共常量
    /// </summary>
    public class CommonConsts
    {
        /// <summary>
        /// 分组
        /// </summary>
        public static class Grouping
        {
            /// <summary>
            /// 总控端
            /// </summary>
            public const string GroupName_v1 = "v1";

            /// <summary>
            /// 商家端
            /// </summary>
            public const string GroupName_v2 = "v2";

            /// <summary>
            /// APP端口
            /// </summary>
            public const string GroupName_v3 = "v3";

            /// <summary>
            /// 分站端
            /// </summary>
            public const string GroupName_v4 = "v4";

            /// <summary>
            /// 业务员端
            /// </summary>
            public const string GroupName_v5 = "v5";
        }

    }
}
