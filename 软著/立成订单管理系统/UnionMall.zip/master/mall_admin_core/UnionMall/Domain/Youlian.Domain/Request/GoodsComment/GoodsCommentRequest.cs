﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request.GoodsComment
{
    public class GoodsCommentRequest
    {
        public int Id { get; set; }
        public string ContentBody { get; set; }
        public string SellerContent { get; set; }
        public int Score { get; set; }
        public int UserId { get; set; }
        public int GoodsId { get; set; }
        public string OrderId { get; set; }
        public string Addon { get; set; }
        public string Imgs { get; set; }
    }
    public class UpdataGoodsCommentStatusRequest
    { 
        public int Id { get; set; }
        public bool? IsDisplay { get; set; }
    }
    public class UpdataGoodsCommentSellerContentRequest
    { 
        public int Id { get; set; }
        public string SellerContent { get; set; }
    }
}
