﻿using Youlian.Domain.Enums;
using System.Collections.Generic;
using System.ComponentModel;

namespace Youlian.Domain.Models.Basics
{
    /// <summary>
    /// 聊天群消息设置
    /// </summary>
    public class ChatGroupBotSetting : IBasicsConfig
    {
        /// <summary>
        /// 男生入群欢迎语，变量 姓名：{realName},部门：{deptName},职位：{position}
        /// </summary>
        public string JoinWelComeMessage1 { get; set; }
        /// <summary>
        /// 女生入群欢迎语，变量 姓名：{realName},部门：{deptName},职位：{position}
        /// </summary>
        public string JoinWelComeMessage2 { get; set; }

        /// <summary>
        /// 其他周年庆祝语，变量 姓名：{realName}
        /// </summary>
        public string AnniversaryMessage { get; set; }
        /// <summary>
        /// 1周年庆祝语，变量 姓名：{realName}
        /// </summary>
        public string AnniversaryMessage1 { get; set; }
        /// <summary>
        /// 2周年庆祝语，变量 姓名：{realName}
        /// </summary>
        public string AnniversaryMessage2 { get; set; }
        /// <summary>
        /// 3周年庆祝语，变量 姓名：{realName}
        /// </summary>
        public string AnniversaryMessage3 { get; set; }
        /// <summary>
        /// 4周年庆祝语，变量 姓名：{realName}
        /// </summary>
        public string AnniversaryMessage4 { get; set; }
        /// <summary>
        /// 生日祝福语
        /// </summary>
        public string BirthdayMessage { get; set; }

    }
}
