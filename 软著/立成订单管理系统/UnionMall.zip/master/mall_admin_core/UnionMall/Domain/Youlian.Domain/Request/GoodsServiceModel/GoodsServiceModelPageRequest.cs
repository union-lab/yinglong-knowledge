﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    public class GoodsServiceModelPageRequest : PageRequest
    {
        public string Name { get; set; }
    }
}
