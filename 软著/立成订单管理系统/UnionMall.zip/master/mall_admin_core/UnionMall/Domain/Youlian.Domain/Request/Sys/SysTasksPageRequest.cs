﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request.Sys
{
    /// <summary>
    /// 计划任务请求参数
    /// </summary>
    public class SysTasksPageRequest : PageRequest
    {
        /// <summary>
        /// 关键字
        /// </summary>
        public string KeyWord { get; set; }
    }
}
