using Youlian.Domain.Enums;
using SqlSugar;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 
    /// </summary>
    [SugarTable("t_sys_rolepermission")]
    public class SysRolePermission : BaseEntity
    {
        /// <summary>
        /// ��ɫID
        /// </summary>
        public int RoleId { get; set; }

        /// <summary>
        /// �˵�ID
        /// </summary>
        public int MenuId { get; set; }

        /// <summary>
        /// �˵�����
        /// </summary>
        public int MenuType { get; set; }

        /// <summary>
        /// ����Ȩ��
        /// </summary>
        public string Actions { get; set; }
    }
}