using Youlian.Domain.Enums;
using SqlSugar;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 回调通知记录
    /// </summary>
    [SugarTable("t_callback_log")]
    public class CallbackLog : ModifyEntity
    {
        /// <summary>
        /// 自定义通知ID
        /// </summary>
        public string NotifyId { get; set; }
        /// <summary>
        /// 通知回调类型
        /// </summary>
        public CallbackNotifyTypeEnum NotifyType { get; set; }

        /// <summary>
        /// 通知地址
        /// </summary>
        public string RequestUrl { get; set; }

        /// <summary>
        /// 接收参数
        /// </summary>
        public string Param { get; set; }

        /// <summary>
        /// 回调通知处理状态
        /// </summary>
        public CallbackNotifyStatusEnum Status { get; set; }
    }
}