﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 企业微信登录授权回调
    /// </summary>
    public class WorkWeixinSsoCallbackRequest : WeixinAuthorizeCallbackRequest
    {
        /// <summary>
        /// 企业微信应用ID
        /// </summary>
        public int AgentId { get; set; }

        /// <summary>
        /// 是小程序登录还是授权链接登录
        /// </summary>
        public bool IsMiniProgram { get; set; }
    }
}
