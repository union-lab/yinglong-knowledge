﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    public class SelectComponentResponse
    {
        public object value { get; set; }
        public string label { get; set; }
    }
}
