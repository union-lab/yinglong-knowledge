﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request.Sys
{
    /// <summary>
    /// 
    /// </summary>
    public class RolePermissionEditRequest
    {
        /// <summary>
        /// 角色ID
        /// </summary>
        public int RoleId { get; set; }
        /// <summary>
        /// 权限列表
        /// </summary>
        public List<RolePermissionItem> List { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class RolePermissionItem
    {
        /// <summary>
        /// 菜单ID
        /// </summary>
        public int MenuId { get; set; }

        /// <summary>
        /// 权限
        /// </summary>
        public List<int> Actions { get; set; }
    }
}
