﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Enums
{

    /// <summary>
    /// 审批类型
    /// </summary>
    public enum SysApprovalTypeEnum
    {
        请假 = 1,
        补卡 = 2,
        出差 = 3,
        外出 = 4,
        加班 = 5
    }

    /// <summary>
    /// 假期状态
    /// </summary>
    public enum VacationStatusEnum
    {
        待添加 = 0,
        待使用 = 1,
        已使用 = 2,
        已过期 = 3,
        已作废 = 4
    }
}
