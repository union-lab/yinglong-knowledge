﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    public class ShopRequest
    {
        /// <summary>
        /// 
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 店铺名称
        /// </summary>
        public string ShopName { get; set; }

        /// <summary>
        /// 省份ID
        /// </summary>
        public int ProvinceId { get; set; }

        /// <summary>
        /// 省份
        /// </summary>
        public string ProvinceName { get; set; }

        /// <summary>
        /// 城市ID
        /// </summary>
        public int CityId { get; set; }

        /// <summary>
        /// 城市
        /// </summary>
        public string CityName { get; set; }

        /// <summary>
        /// 区县
        /// </summary>
        public int DistrictId { get; set; }

        /// <summary>
        /// 区县
        /// </summary>
        public string DistrictName { get; set; }

        /// <summary>
        /// 镇/街道Id
        /// </summary>
        public int TownId { get; set; }
        /// <summary>
        /// 镇/街道
        /// </summary>
        public string TownName { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// 营业时间
        /// </summary>
        public string ProfessionTime { get; set; }

        /// <summary>
        /// 营业证件照
        /// </summary>
        public string ProfessionImgUrl { get; set; }

        /// <summary>
        /// 联系电话
        /// </summary>
        public string ShopTel { get; set; }
    }
}
