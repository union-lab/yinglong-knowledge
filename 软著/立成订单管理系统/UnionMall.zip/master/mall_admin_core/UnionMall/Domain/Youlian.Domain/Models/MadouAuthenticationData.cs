﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Models
{
    /// <summary>
    /// 试客登录认证信息
    /// </summary>
    public class MadouAuthenticationData: BaseAuthenticationData
    {

    }
}
