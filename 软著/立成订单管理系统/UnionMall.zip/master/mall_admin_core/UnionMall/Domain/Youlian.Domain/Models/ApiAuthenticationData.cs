﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Models
{
    /// <summary>
    /// 接口登录认证信息
    /// </summary>
    public class ApiAuthenticationData: BaseAuthenticationData
    {

    }
}
