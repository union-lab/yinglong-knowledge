﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 用户查询参数
    /// </summary>
    public class MemberUserPageRequest : PageRequest
    {
        /// <summary>
        /// 用户名（手机号码）
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 昵称
        /// </summary>
        public string NickName { get; set; }
        /// <summary>
        /// 用户类型
        /// </summary>
        public UserTypeEnum? UserType { get; set; } = UserTypeEnum.用户;


    }
}
