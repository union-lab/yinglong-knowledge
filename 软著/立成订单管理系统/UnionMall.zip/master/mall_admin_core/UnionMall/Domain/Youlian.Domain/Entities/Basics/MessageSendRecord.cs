using SqlSugar;
using System;
using Youlian.Domain.Enums;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 消息发送记录
    /// </summary>
    [SugarTable("t_message_send_record")]
    public class MessageSendRecord : BaseEntity
    {
        /// <summary>
        /// 消息类型
        /// </summary>
        public MessageTypeEnum Type { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string MessageId { get; set; }

        /// <summary>
        /// 接收用户
        /// </summary>
        public string ToUser { get; set; }

        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 内容
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// 发送时间
        /// </summary>
        public DateTime? SendTime { get; set; }
    }
}