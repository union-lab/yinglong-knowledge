﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    public class BannerRequest
    {
        public int Id { get; set; } = 0;
        /// <summary>
        /// 
        /// </summary>
        public string ImgUrl { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string PageUrl { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Sort { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool? IsShow { get; set; }
        /// <summary>
        /// 所属分类Id
        /// </summary>
        public int GoodsCategoryId { get; set; }
    }
}
