﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Models
{
    /// <summary>
    /// Jwt Token配置项
    /// </summary>
    public class JwtOptions
    {
        /// <summary>
        /// 秘钥
        /// </summary>
        public string SecurityKey { get; set; }

        public string Issuer { get; set; }

        public string Audience { get; set; }

        /// <summary>
        /// 过期时间
        /// </summary>
        public int AccessExpiration { get; set; }

        public int RefreshExpiration { get; set; }
    }
}
