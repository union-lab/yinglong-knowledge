using Youlian.Domain.Enums;
using SqlSugar;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 
    /// </summary>
    [SugarTable("t_sys_menu")]
    public class SysMenu : BaseEntity
    {
        /// <summary>
        /// 类型：0菜单，1接口
        /// </summary>
        public SysMenuTypeEnum MenuType { get; set; }
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 上一级
        /// </summary>
        public long ParentId { get; set; }

        /// <summary>
        /// 路由
        /// </summary>
        public string Path { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 组件
        /// </summary>
        public string Component { get; set; }

        /// <summary>
        /// 权限标识
        /// </summary>
        public string Permission { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int SortId { get; set; }
        /// <summary>
        /// 图标
        /// </summary>
        public string Icon { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public SysMenuStatusEnum Status { get; set; } = 0;
    }
}