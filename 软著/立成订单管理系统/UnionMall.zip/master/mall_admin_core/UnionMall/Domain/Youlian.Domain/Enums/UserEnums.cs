﻿using System.ComponentModel;

namespace Youlian.Domain.Enums
{
    /// <summary>
    /// 用户类型
    /// </summary>
    public enum UserTypeEnum
    {
        /// <summary>
        /// 管理员
        /// </summary>
        管理员 = 1,
        /// <summary>
        /// 员工
        /// </summary>
        员工 = 2,

        /// <summary>
        /// 
        /// </summary>
        用户 = 3
    }

    /// <summary>
    /// 增减类型
    /// </summary>
    public enum InAndOutTypeEnum
    {
        /// <summary>
        ///  增加
        /// </summary>
        [Description("增加")]
        增加 = 0,
        /// <summary>
        ///  减少
        /// </summary>
        [Description("减少")]
        减少 = 1
    }

    /// <summary>
    /// 操作类型
    /// </summary>
    public enum UserAccountOperationTypeEnum
    {
        /// <summary>
        ///  账户充值
        /// </summary>
        [Description("账户充值")]
        账户充值 = 0,
        /// <summary>
        ///  账户提现
        /// </summary>
        [Description("账户提现")]
        账户提现 = 1,

        /// <summary>
        ///  调整增加
        /// </summary>
        [Description("调整增加")]
        调整增加 = 5,
        /// <summary>
        ///  调整减少
        /// </summary>
        [Description("调整减少")]
        调整减少 = 6,

    }
}
