﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 总控用户登录
    /// </summary>
    public class SysUserLoginRequest
    {
        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// 图片验证码KEY
        /// </summary>
        public string CaptchaKey { get; set; }
        /// <summary>
        /// 图片验证码
        /// </summary>
        public string Captcha { get; set; }
        /// <summary>
        /// 短信验证码
        /// </summary>
        public string SmsCode { get; set; }
    }
}
