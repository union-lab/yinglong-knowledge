﻿using Youlian.Common.Extention;
using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 系统菜单列表
    /// </summary>
    public class SysMenuListResponse
    {
        /// <summary>
        /// 
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 类型：0菜单，1接口
        /// </summary>
        public SysMenuTypeEnum MenuType { get; set; }
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 上一级
        /// </summary>
        public long ParentId { get; set; }

        /// <summary>
        /// 路由
        /// </summary>
        public string Path { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 组件
        /// </summary>
        public string Component { get; set; }

        /// <summary>
        /// 权限标识
        /// </summary>
        public string Permission { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int SortId { get; set; }
        /// <summary>
        /// 图标
        /// </summary>
        public string Icon { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public SysMenuStatusEnum Status { get; set; }

        /// <summary>
        /// 菜单权限
        /// </summary>
        public int[] Actions { get; set; }
    }
}