using Youlian.Domain.Enums;
using SqlSugar;
using System;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 
    /// </summary>
    [SugarTable("t_userinfo")]
    public class User : ModifyEntity
    {

        /// <summary>
        /// 用户名（手机号）
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 用户类型
        /// </summary>
        public UserTypeEnum UserType { get; set; }

        /// <summary>
        /// PasswordSalt
        /// </summary>
        public string PasswordSalt { get; set; }

        /// <summary>
        /// 登录密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 支付密码
        /// </summary>
        public string PayPassword { get; set; }

        /// <summary>
        /// 上级ID
        /// </summary>
        public int ParentUserId { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        /// 昵称
        /// </summary>
        public string NickName { get; set; }

        /// <summary>
        /// 性别
        /// </summary>
        public int Sex { get; set; }

        /// <summary>
        /// 头像
        /// </summary>
        public string Avatar { get; set; }

        /// <summary>
        /// 账号状态
        /// </summary>
        public ActiveEnum Active { get; set; } = ActiveEnum.启用;

        /// <summary>
        /// 是否删除
        /// </summary>
        public int Deleted { get; set; }

        /// <summary>
        /// 上次登录时间
        /// </summary>
        public DateTime? LastLoginTime { get; set; }

        /// <summary>
        /// 上次登录IP
        /// </summary>
        public string LastIpAddress { get; set; }

        /// <summary>
        /// WxOpenId
        /// </summary>
        public string WxOpenId { get; set; }

        /// <summary>
        /// WxUnionId
        /// </summary>
        public string WxUnionId { get; set; }

        /// <summary>
        /// 公众号小程序等APPID
        /// </summary>
        public string AppId { get; set; }
        /// <summary>
        /// 缓存key
        /// </summary>
        public string SessionKey { get; set; }

    }
}