﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    ///商品服务模型
    /// </summary>
    [SugarTable("t_goodsservicemodel")]
    public class GoodsServiceModel : ModifyEntity
    {
        public string Name { get; set; }
        public int Sort { get; set; }
        public int ShopId { get; set; }
    }
}
