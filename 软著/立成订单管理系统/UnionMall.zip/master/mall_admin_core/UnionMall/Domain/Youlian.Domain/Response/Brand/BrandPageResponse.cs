﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response.Brand
{
    public class BrandPageResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string LogoImageUrl { get; set; }
        public bool IsShow { get; set; }
        public DateTime? AddTime { get; set; }
    }
}
