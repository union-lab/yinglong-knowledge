﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    public class GoodsRequest
    {
        public int Id { get; set; } = 0;
        /// <summary>
        /// 商品名称
        /// </summary>
        public string GoodsName { get; set; }
        /// <summary>
        /// 商品条码
        /// </summary>
        public string BarCode { get; set; }
        /// <summary>
        /// 关联品牌id
        /// </summary>
        public int? BrandId { get; set; }
        /// <summary>
        /// 商品简介
        /// </summary>
        public string GoodsBrief { get; set; }
        /// <summary>
        /// 关联分类id
        /// </summary>
        public int GoodsCategoryId { get; set; }
        /// <summary>
        /// 关联skumodel.ID
        /// </summary>
        public int GoodsSkuId { get; set; }
        /// <summary>
        /// 封面图
        /// </summary>
        public string Image { get; set; }
        /// <summary>
        /// 商品详情
        /// </summary>
        public string Intro { get; set; }
        /// <summary>
        /// 是否热门
        /// </summary>
        public bool IsHot { get; set; }
        /// <summary>
        /// 是否上架
        /// </summary>
        public bool IsMarketable { get; set; }
        /// <summary>
        /// 是否虚拟商品
        /// </summary>
        public bool IsNomalVirtual { get; set; }
        /// <summary>
        /// 是否推荐
        /// </summary>
        public bool IsRecommend { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public int Sort { get; set; }
        /// <summary>
        /// 单位
        /// </summary>
        public string Unit { get; set; }
        /// <summary>
        /// 关联sku货品列表数据
        /// </summary>
        public List<GoodsProductList> GoodsProductList { get; set; }
        /// <summary>
        /// 图集
        /// </summary>
        public List<ImageList> ImgeArr { get; set; }
        /// <summary>
        /// 商品图集
        /// </summary>
        public string Images { get; set; }
    }
    public class GoodsProductList {
        public int Id { get; set; } = 0;
        /// <summary>
        /// 成本价
        /// </summary>
        public decimal CostPrice { get; set; }
        /// <summary>
        /// 市场价
        /// </summary>
        public decimal MktPrice { get; set; }
        /// <summary>
        /// 销售价
        /// </summary>
        public decimal Price { get; set; }
        /// <summary>
        /// sku模型值
        /// </summary>
        public string SkuModelValue { get; set; }
        /// <summary>
        /// 货品编码
        /// </summary>
        public string Sn { get; set; }
        /// <summary>
        /// 库存
        /// </summary>
        public int Stock { get; set; }
        /// <summary>
        /// 重量
        /// </summary>
        public decimal Weight { get; set; }
        /// <summary>
        /// 货品图片
        /// </summary>
        public string Image { get; set; }
        /// <summary>
        /// 是否默认
        /// </summary>
        public bool IsDefalut { get; set; }
    }
    public class ImageList
    { 
        /// <summary>
        /// 图片地址
        /// </summary>
        public string Url { get; set; }
    }
}
