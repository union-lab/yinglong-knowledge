using SqlSugar;
using System;
using Youlian.Domain.Enums;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// api调用记录
    /// </summary>
    [SugarTable("t_api_log")]
    public class ApiLog : BaseEntity
    {
        /// <summary>
        /// 接口ID
        /// </summary>
        public ApiEnum ApiType { get; set; }
        /// <summary>
        /// API地址
        /// </summary>
        public string Api { get; set; }
        /// <summary>
        /// 参数
        /// </summary>
        public string Param { get; set; }
        /// <summary>
        /// 返回结果
        /// </summary>
        public string Result { get; set; }
        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? StartTime { get; set; }
        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? EndTime { get; set; }
        /// <summary>
        /// 0请求失败，1请求成功
        /// </summary>
        public ApiLogStatusEnum Status { get; set; }

        /// <summary>
        /// 关联ID
        /// </summary>
        public int RelateId { get; set; }

        /// <summary>
        /// 关联类型
        /// </summary>
        public ApiLogRelateTypeEnum RelateType { get; set; }

        /// <summary>
        /// 任务处理Id
        /// </summary>
        public string TaskId { get; set; }
    }
}