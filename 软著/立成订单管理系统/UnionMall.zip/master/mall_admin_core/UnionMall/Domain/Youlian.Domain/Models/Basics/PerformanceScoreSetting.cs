﻿using Youlian.Domain.Enums;
using System.Collections.Generic;
using System.ComponentModel;
using System;
using Youlian.Common.Extention;
using System.Linq;

namespace Youlian.Domain.Models.Basics
{
    /// <summary>
    /// 绩效评分设置
    /// </summary>
    public class PerformanceScoreSetting : IBasicsConfig
    {
        /// <summary>
        /// 是否启用
        /// </summary>
        public bool Enabled { get; set; }
        /// <summary>
        /// 截止日
        /// </summary>
        public int EndDay { get; set; }
        /// <summary>
        /// 截止时间
        /// </summary>
        public TimeSpan EndTime { get; set; }

        /// <summary>
        /// 每月第几天提醒部门经理,逗号分隔
        /// </summary>
        public string RemindLeaderDate { get; set; }

        /// <summary>
        /// 抄送用户
        /// </summary>
        public string CCWxUserIds { get; set; }

        /// <summary>
        /// 考核部门Ids
        /// </summary>
        public string DepartmentIds { get; set; }

        /// <summary>
        /// 开启考核部门负责人
        /// </summary>
        public bool OpenAppraisalLeader { get; set; }

        /// <summary>
        /// 考核部门负责人的微信用户Id
        /// </summary>
        public string AppraisalWxUserId { get; set; }

        /// <summary>
        /// S等级评定设置
        /// </summary>
        public List<PerformanceScoreLevelSetting> LevelList { get; set; } = new List<PerformanceScoreLevelSetting>();

        /// <summary>
        /// 规则描述
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// 获取结束时间
        /// </summary>
        /// <returns></returns>
        public DateTime GetEndTime()
        {
            var endTime = new DateTime(DateTime.Today.Year, DateTime.Today.Month, EndDay);
            endTime = endTime.AddSeconds(EndTime.TotalSeconds);
            return endTime;
        }
    }

    /// <summary>
    /// 绩效评分等级设置
    /// </summary>
    public class PerformanceScoreLevelSetting
    {
       

        /// <summary>
        /// 绩效比例
        /// </summary>
        public decimal Rate { get; set; } = 1;

        /// <summary>
        /// 级别设置详情
        /// </summary>
        public List<PerformanceScoreLevelDetailModel> Details { get; set; }= new List<PerformanceScoreLevelDetailModel>();
    }
    /// <summary>
    /// 
    /// </summary>
    public class PerformanceScoreLevelDetailModel
    {
        /// <summary>
        /// 至少需要部门人数
        /// </summary>
        public int NeedUserNum { get; set; }
        /// <summary>
        /// 限制最多可评定人数
        /// </summary>
        public int LimitMaxNum { get; set; }
    }
}
