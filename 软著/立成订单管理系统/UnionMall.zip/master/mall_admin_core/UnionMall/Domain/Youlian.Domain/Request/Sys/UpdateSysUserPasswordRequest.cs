﻿using Microsoft.AspNetCore.Mvc;
using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request.Sys
{
    /// <summary>
    /// 系统用户修改密码参数
    /// </summary>
    public class UpdateSysUserPasswordRequest
    {
        /// <summary>
        /// 旧登录密码
        /// </summary>
        public string OldPassword { get; set; }

        /// <summary>
        /// 登录密码
        /// </summary>
        public string Password { get; set; }
    }
}
