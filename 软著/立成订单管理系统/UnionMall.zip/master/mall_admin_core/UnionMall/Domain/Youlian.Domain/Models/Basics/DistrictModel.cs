﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Models.Basics
{
    /// <summary>
    /// 城市信息
    /// </summary>
    public class CityModel
    {
        /// <summary>
        /// 省份ID
        /// </summary>
        public int ProvinceId { get; set; }

        /// <summary>
        /// 省份
        /// </summary>
        public string ProvinceName { get; set; }

        /// <summary>
        /// 城市ID
        /// </summary>
        public int CityId { get; set; }

        /// <summary>
        /// 城市
        /// </summary>
        public string CityName { get; set; }
    }
    /// <summary>
    /// 区县信息
    /// </summary>
    public class DistrictModel : CityModel
    {
        /// <summary>
        /// 区县ID
        /// </summary>
        public int DistrictId { get; set; }

        /// <summary>
        /// 区县
        /// </summary>
        public string DistrictName { get; set; }
    }

    /// <summary>
    /// 区县信息
    /// </summary>
    public class TownModel : DistrictModel
    {
        /// <summary>
        /// 镇街道ID
        /// </summary>
        public int TownId { get; set; }

        /// <summary>
        /// 镇街道
        /// </summary>
        public string TownName { get; set; }
    }
}
