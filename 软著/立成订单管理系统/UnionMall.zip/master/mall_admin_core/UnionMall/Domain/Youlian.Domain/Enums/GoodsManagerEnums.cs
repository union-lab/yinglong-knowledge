﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Enums
{
    public enum UpdataGoodsCategoryStatusTypeEnum
    {
        是否展示=1,
        是否首页展示=2
    }
    public enum GoodsRequestDataTypeEnum
    { 
        全部商品=1,
        上架商品=2,
        下架商品=3,
        库存警告=4
    }
}
