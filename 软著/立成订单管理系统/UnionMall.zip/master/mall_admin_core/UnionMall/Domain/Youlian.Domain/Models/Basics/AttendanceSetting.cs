﻿using Youlian.Domain.Enums;
using System.Collections.Generic;
using System.ComponentModel;

namespace Youlian.Domain.Models.Basics
{
    /// <summary>
    /// 考勤设置
    /// </summary>
    public class AttendanceSetting : IBasicsConfig
    {
        /// <summary>
        /// 打卡1次微信用户ID,逗号分隔
        /// </summary>
        public List<string> CheckIn1WxUserIds { get; set; }

        /// <summary>
        /// 打卡2次微信用户ID,逗号分隔
        /// </summary>
        public List<string> CheckIn2WxUserIds { get; set; }

        /// <summary>
        /// 外勤打卡人员,逗号分隔
        /// </summary>
        public List<string> FieldWxUserIds { get; set; }

        /// <summary>
        /// 仓储部门
        /// </summary>
        public List<int> WareHouseDeptIds { get; set; }
        /// <summary>
        /// 仓储部门用户
        /// </summary>
        public List<string> WareHouseUserIds { get; set; }

    }
}
