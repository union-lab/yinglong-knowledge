﻿using Youlian.Common.Extention;
using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 公告列表
    /// </summary>
    public class NoticePageResponse
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 修改时间
        /// </summary>
        public DateTime ModifyTime { get; set; }

        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 分类ID
        /// </summary>
        public int CategoryID { get; set; }

        /// <summary>
        /// 分类名称
        /// </summary>
        public string CategoryName { get; set; }

        /// <summary>
        /// 内容
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// 是否置顶
        /// </summary>
        public int IsTop { get; set; }
        /// <summary>
        /// 是否New
        /// </summary>
        public int IsNew { get; set; }
        /// <summary>
        /// 是否必看
        /// </summary>
        public int IsMustSee { get; set; }

        /// <summary>
        /// 是否弹窗显示
        /// </summary>
        public int IsTopShow { get; set; }

        /// <summary>
        /// 分站ID
        /// </summary>
        public int SubSiteId { get; set; }

        /// <summary>
        /// 发布用户ID
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// 展示平台
        /// </summary>
        public SystemClientEnum Client { get; set; }
        /// <summary>
        /// 展示平台
        /// </summary>
        public string ClientName => Client.ToString();
    }
}