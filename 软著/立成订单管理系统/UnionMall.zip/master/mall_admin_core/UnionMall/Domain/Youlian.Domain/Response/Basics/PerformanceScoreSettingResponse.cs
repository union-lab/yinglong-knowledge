﻿using Youlian.Domain.Enums;
using System.Collections.Generic;
using System.ComponentModel;
using System;
using Youlian.Common.Extention;
using System.Linq;
using Youlian.Domain.Models.Basics;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 绩效评分设置
    /// </summary>
    public class PerformanceScoreSettingResponse
    {
        /// <summary>
        /// 截止日
        /// </summary>
        public int EndDay { get; set; }
        /// <summary>
        /// 截止时间
        /// </summary>
        public TimeSpan EndTime { get; set; }

        /// <summary>
        /// 每月第几天提醒部门经理,逗号分隔
        /// </summary>
        public string RemindLeaderDate { get; set; }

        /// <summary>
        /// 抄送用户
        /// </summary>
        public string CCWxUserIds { get; set; }

        /// <summary>
        /// S等级评定设置
        /// </summary>
        public List<PerformanceScoreLevelSetting> LevelList { get; set; } = new List<PerformanceScoreLevelSetting>();

        /// <summary>
        /// 规则描述
        /// </summary>
        public string Description { get; set; }


        /// <summary>
        /// 获取结束时间
        /// </summary>
        /// <returns></returns>
        public DateTime RealEndTime
        {
            get
            {
                var endTime = new DateTime(DateTime.Today.Year, DateTime.Today.Month, EndDay);
                endTime = endTime.AddSeconds(EndTime.TotalSeconds);
                return endTime;
            }
        }
    }
}
