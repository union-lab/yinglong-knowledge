﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;
using Youlian.SDK.Weixin.MP.Models;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 用户基本登录信息
    /// </summary>
    public class BaseLoginInfoResponse
    {
        /// <summary>
        /// 用户id
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// 商家账户
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 用户类型
        /// </summary>
        public UserTypeEnum UserType { get; set; }

        /// <summary>
        /// 头像
        /// </summary>
        public string Avatar { get; set; }
    }
    /// <summary>
    /// 微信小程序code解析返回
    /// </summary>
    public class WxAppletsLCodeResponse
    { 
        public string Token { get; set; }
        public string WxOpenId { get; set; }
        public UserResponse User { get; set; }
    }
    public class UserResponse
    { 
        public int Id { get; set; }
        public string NickName { get; set; }
        public string UserName { get; set; }
        public string Avatar { get; set; }
        public string WxOpenId { get; set; }



    }
}
