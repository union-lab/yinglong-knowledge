﻿using Youlian.Common.Extention;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 角色菜单
    /// </summary>
    public class SysRoleMenuResponse
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 类型：0菜单，1接口
        /// </summary>
        public SysMenuTypeEnum MenuType { get; set; }
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 上一级
        /// </summary>
        public long ParentId { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int SortId { get; set; }
        /// <summary>
        /// 权限
        /// </summary>
        public List<int> Actions { get; set; }
    }
}