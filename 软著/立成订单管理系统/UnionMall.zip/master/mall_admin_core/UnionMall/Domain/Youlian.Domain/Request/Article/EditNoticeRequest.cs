﻿using Microsoft.AspNetCore.Mvc;
using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 添加修改公告参数
    /// </summary>
    public class EditNoticeRequest
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 分类ID
        /// </summary>
        public int CategoryID { get; set; }

        /// <summary>
        /// 内容
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// 是否置顶
        /// </summary>
        public int IsTop { get; set; }
        /// <summary>
        /// 是否New
        /// </summary>
        public int IsNew { get; set; }
        /// <summary>
        /// 是否必看
        /// </summary>
        public int IsMustSee { get; set; }

        /// <summary>
        /// 是否弹窗显示
        /// </summary>
        public int IsTopShow { get; set; }

        /// <summary>
        /// 展示平台
        /// </summary>
        public SystemClientEnum? Client { get; set; }
    }
}
