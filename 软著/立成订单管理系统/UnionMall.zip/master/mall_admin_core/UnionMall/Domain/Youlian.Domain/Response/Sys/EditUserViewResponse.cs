﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response.Sys
{

    /// <summary>
    /// 
    /// </summary>
    public class EditUserViewResponse
    {
        /// <summary>
        /// 
        /// </summary>
        public SysUserResponse User { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public SysRoleResponse Role { get; set; }
    }
}
