using Youlian.Domain.Enums;
using SqlSugar;
using System;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 
    /// </summary>
    [SugarTable("t_queuedsms")]
    public class QueuedSms : ModifyEntity
    {
        /// <summary>
        /// 发送手机
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 发送参数内容
        /// </summary>
        public string Body { get; set; }

        /// <summary>
        /// 验证码
        /// </summary>
        public string CheckCode { get; set; }

        /// <summary>
        /// 短信类型
        /// </summary>
        public SmsTypeEnum Type { get; set; }

        /// <summary>
        /// 当前次数
        /// </summary>
        public int Times { get; set; }

        /// <summary>
        /// 验证码状态
        /// </summary>
        public SmsLogStatusEnum Status { get; set; }
    }
}