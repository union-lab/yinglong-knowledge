﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    public class GoodsSkuModelPageRequest : PageRequest
    {
        public string SkuName { get; set; }
    }
}
