using Youlian.Domain.Enums;
using SqlSugar;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 系统日志
    /// </summary>
    [SugarTable("t_sys_log")]
    public class SysLog : BaseEntity
    {
        /// <summary>
        /// 用户类型
        /// </summary>
        public UserTypeEnum UserType { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 日志类型
        /// </summary>
        public SysLogTypeEnum LogType { get; set; }


        /// <summary>
        /// 日志内容
        /// </summary>
        public string Content { get; set; }


        /// <summary>
        /// ip地址
        /// </summary>
        public string IpAddress { get; set; }
    }
}