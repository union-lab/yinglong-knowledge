﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 商品列表
    /// </summary>
    [SugarTable("t_goods")]
    public class Goods : ModifyEntity
    {
        /// <summary>
        /// 商品条码
        /// </summary>
        public string BarCode { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        public string GoodsName { get; set; }
        /// <summary>
        /// 商品简介
        /// </summary>
        public string GoodsBrief { get; set; }
        /// <summary>
        /// 商品缩略图
        /// </summary>
        public string Image { get; set; }
        /// <summary>
        /// 商品图集，多个","隔开
        /// </summary>
        public string Images { get; set; }
        /// <summary>
        /// 商品视频
        /// </summary>
        public string Video { get; set; }
        /// <summary>
        /// 佣金分配方式
        /// </summary>
        public int? ProductsDistributionType { get; set; }
        /// <summary>
        /// 关联分类Id
        /// </summary>
        public int GoodsCategoryId { get; set; }
        /// <summary>
        /// 关联店铺Id
        /// </summary>
        public int? ShopId { get; set; }
        /// <summary>
        /// 关联sku模型Id
        /// </summary>
        public int GoodsSkuId { get; set; }
        /// <summary>
        /// 关联品牌Id
        /// </summary>
        public int? BrandId { get; set; }
        /// <summary>
        /// 关联规格服务id【预留】
        /// </summary>
        public int? SpecFWId { get; set; }
        /// <summary>
        /// 是否上架
        /// </summary>
        public bool IsMarketable { get; set; }
        /// <summary>
        /// 是否虚拟商品
        /// </summary>
        public bool IsNomalVirtual { get; set; }
        /// <summary>
        /// 商品单位
        /// </summary>
        public string Unit { get; set; }
        /// <summary>
        /// 商品详情
        /// </summary>
        public string Intro { get; set; }
        /// <summary>
        /// 评论次数
        /// </summary>
        public int CommentsCount { get; set; }
        /// <summary>
        /// 浏览次数
        /// </summary>
        public int ViewCount { get; set; }
        /// <summary>
        /// 购买次数
        /// </summary>
        public int BuyCount { get; set; }
        /// <summary>
        /// 上架时间
        /// </summary>
        public DateTime? UpTime { get; set; }
        /// <summary>
        /// 下架时间
        /// </summary>
        public DateTime? DownTime { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public int Sort { get; set; }
        /// <summary>
        /// 是否推荐
        /// </summary>
        public bool IsRecommend { get; set; }
        /// <summary>
        /// 是否热门
        /// </summary>
        public bool IsHot { get; set; }
        /// <summary>
        /// 是否删除
        /// </summary>
        public bool Deleted { get; set; }

    }
}
