﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 小程序授权参数
    /// </summary>
    public class WeixinCode2SessionRequest
    {
        /// <summary>
        /// 
        /// </summary>
        public string AppId { get; set; }
        /// <summary>
        /// 登录时获取的 code
        /// </summary>
        public string Code { get; set; }
    }
    /// <summary>
    /// 微信小程序拉去手机号码权限参数
    /// </summary>
    public class WeixinCodeByPhoneRequest
    {
        public string encryptedData { get; set; }

        public string iv { get; set; }

        public string sessionAuthId { get; set; }

        public int invitecode { get; set; } = 0;
    }
    public class WxAuthLoginRequest
    {
        /// <summary>
        /// 小程序Appid
        /// </summary>
        public string AppId { get; set; }
        /// <summary>
        /// 登录时获取的 code
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string EncryptedData { get; set; }

        public string Iv { get; set; }

        public string SessionAuthId { get; set; }
        /// <summary>
        /// 邀请码
        /// </summary>

        public int Invitecode { get; set; } = 0;
        /// <summary>
        /// 用户昵称
        /// </summary>
        public string NickName { get; set; }
        /// <summary>
        /// 性别
        /// </summary>
        public string Gender { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
        public string AvatarUrl { get; set; }

    }
}
