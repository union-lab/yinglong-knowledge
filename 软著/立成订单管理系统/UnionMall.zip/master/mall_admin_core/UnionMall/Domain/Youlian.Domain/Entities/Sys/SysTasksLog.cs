using Youlian.Domain.Enums;
using SqlSugar;
using System;

namespace Youlian.Domain.Entities
{
    ///<summary>
    ///计划任务
    ///</summary>
    [SugarTable("t_sys_tasks_log")]
    public class SysTasksLog : BaseEntity
    {
        /// <summary>
        /// 任务Id
        /// </summary>
        public int JobId { get; set; }

        /// <summary>
        /// 任务名称
        /// </summary>
        public string JobName { get; set; }

        /// <summary>
        /// 任务分组
        /// </summary>
        public string JobGroup { get; set; }
        /// <summary>
        /// 执行状态（0正常 1失败）
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// 异常
        /// </summary>
        public string Exception { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string JobMessage { get; set; }

        /// <summary>
        /// 调用目标字符串
        /// </summary>
        public string InvokeTarget { get; set; }

        /// <summary>
        /// 执行用时，毫秒
        /// </summary>
        public double Elapsed { get; set; }
    }
}