﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    public class GoodsServiceModelRequest
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; }
        public int Sort { get; set; }
        public List<GoodsServiceModelValueRequest> GoodsServiceModelValues { get; set; }
    }
    public class GoodsServiceModelValueRequest
    {
        public int Id { get; set; }
        public string ServiceModelValue { get; set; }
    }
}
