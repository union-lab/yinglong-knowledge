﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 请求公告列表参数
    /// </summary>
    public class NoticePageRequest:PageRequest
    {
        /// <summary>
        /// 
        /// </summary>
        public SystemClientEnum? Client { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 是否弹窗显示
        /// </summary>
        public bool? IsTopShow { get; set; }
    }
}
