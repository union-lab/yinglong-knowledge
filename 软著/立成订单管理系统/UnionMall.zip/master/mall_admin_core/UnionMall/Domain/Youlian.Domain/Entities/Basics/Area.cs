using SqlSugar;
using System;
using Youlian.Domain.Enums;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 行政区划
    /// </summary>
    [SugarTable("t_area")]
    public class Area : BaseEntity
    {
        /// <summary>
        /// 上级ID
        /// </summary>
        public int ParentId { get; set; }

        /// <summary>
        /// 深度
        /// </summary>
        public int Deep { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 拼音首字母
        /// </summary>
        public string PinyinPrefix { get; set; }

        /// <summary>
        /// 拼音
        /// </summary>
        public string Pinyin { get; set; }

        /// <summary>
        /// 拓展ID
        /// </summary>
        public string ExtId { get; set; }

        /// <summary>
        /// 拓展名称
        /// </summary>
        public string ExtName { get; set; }
    }
}