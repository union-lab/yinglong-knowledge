﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    public class GoodsSkuModelValueResponse
    {
        public int Id { get; set; }
        /// <summary>
        /// 关联goodsskumodel.id
        /// </summary>
        public int SpecId { get; set; }
        /// <summary>
        /// skuModel值
        /// </summary>
        public string SpecValue { get; set; }
    }
}
