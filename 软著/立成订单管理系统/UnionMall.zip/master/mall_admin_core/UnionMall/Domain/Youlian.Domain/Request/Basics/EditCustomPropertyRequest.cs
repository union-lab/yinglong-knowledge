﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 编辑自定义属性请求参数
    /// </summary>
    public class EditCustomPropertyRequest
    {
        /// <summary>
        /// 记录ID
        /// </summary>
        public int? Id { get; set; }

        /// <summary>
        /// 属性名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 属性值类型
        /// </summary>
        public string ValueType { get; set; }
        /// <summary>
        /// 实体类型
        /// </summary>
        public CustomPropertyEntityTypeEnum? EntityType { get; set; }
    }
}
