﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Request;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 
    /// </summary>
    public class AreaPageResponse
    {
        /// <summary>
        /// 
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 上级ID
        /// </summary>
        public int ParentId { get; set; }

        /// <summary>
        /// 深度
        /// </summary>
        public int Deep { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 拼音首字母
        /// </summary>
        public string PinyinPrefix { get; set; }

        /// <summary>
        /// 拼音
        /// </summary>
        public string Pinyin { get; set; }

        /// <summary>
        /// 拓展ID
        /// </summary>
        public string ExtId { get; set; }

        /// <summary>
        /// 拓展名称
        /// </summary>
        public string ExtName { get; set; }
    }
}