﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request.Brand
{
    public class BrandPageRuquest : PageRequest
    {
        /// <summary>
        /// 品牌名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 是否展示
        /// </summary>
        public bool? IsShow { get; set; }
    }
}
