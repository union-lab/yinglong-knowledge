﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;

namespace Youlian.Domain.Request.GoodsCategory
{
    public class GoodsCategoryRequest
    {
        public int Id { get; set; } = 0;
        public int ParentId { get; set; }
        public string CategoryName { get; set; }
        public string CategoryIco { get; set; }
        public int Sort { get; set; }
        public bool IsShowHomePage { get; set; }
        public bool IsShow { get; set; }

    }
    public class UpdataCategoryStatusRequest
    {
        public int Id { get; set; }
        public bool Status { get; set; }
        public UpdataGoodsCategoryStatusTypeEnum? Type { get; set; }
    }
}
