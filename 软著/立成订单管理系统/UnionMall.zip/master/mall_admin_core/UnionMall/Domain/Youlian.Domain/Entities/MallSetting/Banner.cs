﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 商城首页图片轮播表
    /// </summary>
    [SugarTable("t_mall_banner")]
    public class Banner : ModifyEntity
    {
        /// <summary>
        /// 图片地址
        /// </summary>
        public string ImgUrl { get; set; }
        /// <summary>
        /// 跳转地址
        /// </summary>
        public string PageUrl { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public int? Sort { get; set; }
        /// <summary>
        /// 是否展示
        /// </summary>
        public bool IsShow { get; set; }
        /// <summary>
        /// 所属商品分类id
        /// </summary>
        public int GoodsCategoryId { get; set; }
    }
}
