﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Models.User
{
    /// <summary>
    /// 重置密码token
    /// </summary>
    public class ResetPasswordTokenModel
    {
        /// <summary>
        /// 
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime ExpireTime { get; set; }

    }
}
