﻿using Youlian.Domain.Enums;
using System.Collections.Generic;
using System.ComponentModel;

namespace Youlian.Domain.Models.Basics
{
    /// <summary>
    /// 短信配置
    /// </summary>
    public class SmsSetting:IBasicsConfig
    {
        /// <summary>
        /// AccessKey
        /// </summary>
        public string ZDAccessKey { get; set; }

        /// <summary>
        /// AccessSecret
        /// </summary>
        public string ZDAccessSecret { get; set; }
        /// <summary>
        /// ZDApiUrl
        /// </summary>
        public string ZDApiUrl { get; set; }

        /// <summary>
        /// Sign
        /// </summary>
        public string Sign { get; set; }
        /// <summary>
        /// TemplateNo
        /// </summary>
        public string TemplateNo { get; set; }

        /// <summary>
        /// 是否开启
        /// </summary>
        public int IsOpen { get; set; }

        /// <summary>
        /// 发送短信间隔秒
        /// </summary>
        public int TimelimitSeconds { get; set; } = 0;

        /// <summary>
        /// 一天最多发送短信次数
        /// </summary>
        public int NumberslimitDay { get; set; } = 5;


        /// <summary>
        /// 商家审核推广申请通知模板
        /// </summary>
       
        public string AuditOrderRequest_TemplateNo { get; set; }


        /// <summary>
        /// 商家确认订单号通知模板
        /// </summary>
       
        public string AuditOrderNo_TemplateNo { get; set; }


        /// <summary>
        /// 商家确认订单留评通知模板
        /// </summary>
       
        public string AuditOrderReview_TemplateNo { get; set; }
    }
}
