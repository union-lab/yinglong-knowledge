﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Models
{
    /// <summary>
    /// 管理员登录认证信息
    /// </summary>
    public class AdminAuthenticationData: BaseAuthenticationData
    {

    }
}
