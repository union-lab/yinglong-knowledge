﻿using System.Collections.Generic;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 分页相应
    /// </summary>
    /// <typeparam name="T">泛型实体</typeparam>
    public class PageResponse<T>
    {
        /// <summary>
        /// 数据总数
        /// </summary>
        public int Total { get; set; } = 0;
        /// <summary>
        /// 数据内容
        /// </summary>
        public List<T> Data { get; set; } = new List<T>();
    }
}