﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 商城首页图片轮播表
    /// </summary>
    [SugarTable("t_mall_ship")]
    public class Ship : ModifyEntity
    {
        /// <summary>
        /// 配送方式名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 运费
        /// </summary>
        public decimal ShipPrice { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public int? Sort { get; set; }
        /// <summary>
        /// 是否展示
        /// </summary>
        public bool IsShow { get; set; }
        /// <summary>
        /// 是否默认
        /// </summary>
        public bool IsDefault { get; set; }
        /// <summary>
        /// 说明
        /// </summary>
        public string Explain { get; set; }
    }
}
