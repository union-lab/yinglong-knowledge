﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    public class ShipRequest
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; }
        public decimal ShipPrice { get; set; }
        public int Sort { get; set; }
        public bool? IsShow { get; set; }
        public bool? IsDefault { get; set; }
        public string Explain { get; set; }
    }
    public class UpdataShipRequest
    { 
        public int Id { get; set; }
        /// <summary>
        /// 0：修改是否默认；1：修改是否展示
        /// </summary>
        public int Type { get; set; }
        /// <summary>
        /// 值
        /// </summary>
        public bool? BoolValue { get; set; }
    }
}
