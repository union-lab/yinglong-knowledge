﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;

namespace Youlian.Domain.Request
{
    public class GoodsPageRequest : PageRequest
    {
        public string GoodsName { get; set; }
        public GoodsRequestDataTypeEnum? DataType { get; set; }
    }
}
