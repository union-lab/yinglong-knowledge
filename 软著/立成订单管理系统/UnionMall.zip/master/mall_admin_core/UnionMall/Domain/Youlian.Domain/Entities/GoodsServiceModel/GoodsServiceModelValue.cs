﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    ///商品服务模型值
    /// </summary>
    [SugarTable("t_goodsservicemodelvalue")]
    public class GoodsServiceModelValue : ModifyEntity
    {
        public int GoodsServiceId { get; set; }
        public string ServiceModelValue { get; set; }
    }
}
