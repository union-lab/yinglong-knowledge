﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Models
{
    /// <summary>
    /// 基础配置
    /// </summary>
    public interface IBasicsConfig
    {

    }
}
