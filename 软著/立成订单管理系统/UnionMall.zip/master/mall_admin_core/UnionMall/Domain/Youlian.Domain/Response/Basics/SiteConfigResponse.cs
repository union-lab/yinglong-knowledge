﻿using Youlian.Domain.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response.Basics
{
    /// <summary>
    /// 
    /// </summary>
    public class SiteConfigResponse : IBasicsConfig
    {


    }
}
