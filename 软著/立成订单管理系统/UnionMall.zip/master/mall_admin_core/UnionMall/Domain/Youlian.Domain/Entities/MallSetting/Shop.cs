﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 店铺列表
    /// </summary>
    [SugarTable("t_shop")]
    public class Shop : ModifyEntity
    {
        public string ShopName { get; set; }
        public string ProfessionTime { get; set; }
        public string ShopTel { get; set; }
        public string ProfessionImgUrl { get; set; }
        public int ProvinceId { get; set; }
        public string ProvinceName { get; set; }
        public int CityId { get; set; }
        public string CityName { get; set; }
        public int DistrictId { get; set; }
        public string DistrictName { get; set; }
        public int TownId { get; set; }
        public string TownName { get; set; }
        public string Address { get; set; } 

    }
}
