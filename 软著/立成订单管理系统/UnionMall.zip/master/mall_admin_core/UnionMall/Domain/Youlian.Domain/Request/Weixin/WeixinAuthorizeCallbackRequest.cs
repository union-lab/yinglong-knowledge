﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 微信授权回调请求
    /// </summary>
    public class WeixinAuthorizeCallbackRequest
    {
        /// <summary>
        /// 通过成员授权获取到的code，最大为512字节。每次成员授权带上的code将不一样，code只能使用一次，5分钟未被使用自动过期
        /// </summary>
        [Required]
        public string Code { get; set; }
        /// <summary>
        /// 自定义参数值返回
        /// </summary>
        public string State { get; set; }
    }
}
