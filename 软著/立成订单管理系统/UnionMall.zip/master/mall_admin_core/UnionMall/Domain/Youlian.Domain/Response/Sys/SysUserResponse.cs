﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;

namespace Youlian.Domain.Response.Sys
{
    /// <summary>
    /// 
    /// </summary>
    public class SysUserResponse
    {
        /// <summary>
        /// 
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 名称
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// PasswordSalt
        /// </summary>
        public string PasswordSalt { get; set; }

        /// <summary>
        /// 登录密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        /// 部门
        /// </summary>
        public string Department { get; set; }

        /// <summary>
        /// 职位
        /// </summary>
        public string Position { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string Tel { get; set; }

        /// <summary>
        /// 角色Ids
        /// </summary>
        public string RoleIds { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public ActiveEnum Active { get; set; } = ActiveEnum.启用;

        /// <summary>
        /// 是否删除
        /// </summary>
        public bool Deleted { get; set; }

        /// <summary>
        /// 创建者id
        /// </summary>
        public int CreatorId { get; set; }
        /// <summary>
        /// 修改时间
        /// </summary>
        public DateTime ModifyTime { get; set; }
    }
}
