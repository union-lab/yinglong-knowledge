﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    ///商品评价 
    /// </summary>
    [SugarTable("t_goodscomment")]
    public class GoodsComment : ModifyEntity
    {
        /// <summary>
        /// 评价父级id 预留
        /// </summary>
        public int CommentId { get; set; }
        /// <summary>
        /// 评价等级 1-5
        /// </summary>
        public int Score { get; set; }
        /// <summary>
        /// 评价用户ID
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 商品Id
        /// </summary>
        public int GoodsId { get; set; }
        /// <summary>
        /// 评价订单id
        /// </summary>
        public string OrderId { get; set; }
        /// <summary>
        /// 货品规格序列号
        /// </summary>
        public string Addon { get; set; }
        /// <summary>
        /// 评价图片【多张,隔开】
        /// </summary>
        public string Imgs { get; set; }
        /// <summary>
        /// 评价内容
        /// </summary>
        public string ContentBody { get; set; }
        /// <summary>
        /// 商家回复
        /// </summary>
        public string SellerContent { get; set; }
        /// <summary>
        /// 前端是否展示
        /// </summary>
        public bool IsDisplay { get; set; }
    }
}
