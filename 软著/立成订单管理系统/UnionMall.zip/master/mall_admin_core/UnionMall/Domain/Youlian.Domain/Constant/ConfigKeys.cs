﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Constant
{
    /// <summary>
    /// 配置项参数名
    /// </summary>
    public static class ConfigKeys
    {
        /// <summary>
        /// 网站配置
        /// </summary>
        public const string SiteConfig = "SiteConfig";
        /// <summary>
        /// 短信配置
        /// </summary>
        public const string SmsSettings = "SmsSettings";

    }
}
