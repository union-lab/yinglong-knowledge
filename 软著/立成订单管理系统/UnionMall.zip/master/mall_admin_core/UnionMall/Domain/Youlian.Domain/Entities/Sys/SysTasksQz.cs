using Youlian.Domain.Enums;
using SqlSugar;
using System;

namespace Youlian.Domain.Entities
{
    ///<summary>
    ///计划任务
    ///</summary>
    [SugarTable("t_sys_tasks")]
    public class SysTasksQz : ModifyEntity
    {
        /// <summary>
        /// 任务名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 任务分组
        /// </summary>
        public string JobGroup { get; set; }

        /// <summary>
        /// 运行时间表达式
        /// </summary>
        public string Cron { get; set; }

        /// <summary>
        /// 程序集名称
        /// </summary>
        public string AssemblyName { get; set; }

        /// <summary>
        /// 任务所在类
        /// </summary>
        public string ClassName { get; set; }

        /// <summary>
        /// 任务描述
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 执行次数
        /// </summary>
        public int RunTimes { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? BeginTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// 触发器类型（0、simple 1、cron） 
        /// </summary>
        public int TriggerType { get; set; }

        /// <summary>
        /// 执行间隔时间(单位:秒) 
        /// </summary>
        public int IntervalSecond { get; set; }

        /// <summary>
        /// 是否启动
        /// </summary>
        public bool IsStart { get; set; }

        /// <summary>
        /// 传入参数
        /// </summary>
        public string JobParams { get; set; }

        /// <summary>
        /// 最后运行时间
        /// </summary>
        public DateTime? LastRunTime { get; set; }

        /// <summary>
        /// api执行地址
        /// </summary>
        public string ApiUrl { get; set; }

        /// <summary>
        /// 任务类型 1程序集2网络请求
        /// </summary>
        public int TaskType { get; set; }
    }
}