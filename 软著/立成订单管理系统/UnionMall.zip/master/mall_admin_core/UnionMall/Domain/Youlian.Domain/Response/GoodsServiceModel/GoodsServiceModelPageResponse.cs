﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    public class GoodsServiceModelPageResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Sort { get; set; }
        public DateTime AddTime { get; set; }
        public DateTime ModifyTime { get; set; }
        public List<GoodsServiceModelValueResponse> GoodsServiceModelValues { get; set; }
    }
    public class GoodsServiceModelValueResponse
    {
        public int Id { get; set; }
        public string ServiceModelValue { get; set; }
    }
}
