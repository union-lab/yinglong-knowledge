﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 品牌表
    /// </summary>
    [SugarTable("t_brand")]
    public class  Brand : ModifyEntity
    {
        /// <summary>
        /// 品牌名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 品牌log
        /// </summary>
        public string LogoImageUrl { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public int? Sort { get; set; }
        /// <summary>
        /// 是否展示
        /// </summary>
        public bool IsShow { get; set; }
    }
}
