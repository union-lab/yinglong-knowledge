﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    ///商品分类 
    /// </summary>
    [SugarTable("t_goodscategory")]
    public class GoodsCategory:ModifyEntity
    {
        public int ParentId { get; set; }
        public string CategoryName { get; set; }
        public int Sort { get; set; }
        public string CategoryIco { get; set; }
        public bool IsShowHomePage { get; set; }
        public bool IsShow { get; set; }
    }
}
