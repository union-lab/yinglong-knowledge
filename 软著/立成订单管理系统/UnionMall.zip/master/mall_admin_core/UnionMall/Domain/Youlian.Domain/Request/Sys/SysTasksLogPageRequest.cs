﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request.Sys
{
    /// <summary>
    /// 计划任务执行记录请求参数
    /// </summary>
    public class SysTasksLogPageRequest : PageRequest
    {
        /// <summary>
        /// 
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string JobName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? JobId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string JobGroup { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? EndTime { get; set; }
    }
}
