﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    ///商品Sku 
    /// </summary>
    [SugarTable("t_goodsskumodel")]
    public class GoodsSkuModel : ModifyEntity
    {
        public string SkuName { get; set; }
        public int Sort { get; set; }
        public int ShopId { get; set; }
    }
}
