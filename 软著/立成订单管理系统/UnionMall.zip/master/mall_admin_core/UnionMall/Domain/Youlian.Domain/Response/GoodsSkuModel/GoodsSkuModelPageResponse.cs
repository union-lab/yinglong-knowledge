﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    public class GoodsSkuModelPageResponse
    {

        public int Id { get; set; }
        public string SkuName { get; set; }
        public int Sort { get; set; }
        public DateTime AddTime { get; set; }
        public DateTime ModifyTime { get; set; }
        public List<GoodsSkuModelValueResponse> GoodsSkuModelValues { get; set; }
    }
    //public class GoodsSkuModelValueResponse
    //{
    //    public int Id { get; set; }
    //    /// <summary>
    //    /// 关联goodsskumodel.id
    //    /// </summary>
    //    public int SpecId { get; set; }
    //    public string SpecValue { get; set; }
    //}
}
