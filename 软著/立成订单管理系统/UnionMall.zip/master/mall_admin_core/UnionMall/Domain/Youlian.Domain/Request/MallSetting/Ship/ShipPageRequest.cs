﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    public class ShipPageRequest : PageRequest
    {
        public string Name { get; set; }
        public bool? IsShow { get; set; }
        public bool? IsDefault { get; set; }
    }
}
