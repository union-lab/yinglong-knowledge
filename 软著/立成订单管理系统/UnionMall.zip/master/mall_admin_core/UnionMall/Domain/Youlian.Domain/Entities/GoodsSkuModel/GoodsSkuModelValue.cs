﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Entities
{
    /// <summary>
    ///商品SKU模型值
    /// </summary>
    [SugarTable("t_goodsskumodelvalue")]
    public class GoodsSkuModelValue : ModifyEntity
    {
        public int SpecId { get; set; }
        public string SpecValue { get; set; }
        public int Sort { get; set; }
    }
}
