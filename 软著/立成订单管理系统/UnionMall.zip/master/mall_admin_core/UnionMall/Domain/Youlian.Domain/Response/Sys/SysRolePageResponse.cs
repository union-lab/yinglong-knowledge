﻿using Youlian.Common.Extention;
using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 系统角色列表
    /// </summary>
    public class SysRolePageResponse
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime AddTime { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string RoleName { get; set; }

        /// <summary>
        /// 备注说明
        /// </summary>
        public string Description { get; set; }
    }
}