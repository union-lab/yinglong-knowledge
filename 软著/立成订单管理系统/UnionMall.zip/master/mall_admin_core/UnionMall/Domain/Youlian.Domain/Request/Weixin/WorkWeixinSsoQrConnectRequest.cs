﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 微信授权参数
    /// </summary>
    public class WeixinAuthorizeRequest
    {
        /// <summary>
        /// 跳转链接
        /// </summary>
        public string RedirectUri { get; set; }

        /// <summary>
        /// 站点类型
        /// </summary>
        public SystemClientEnum ClientType { get; set; }

        /// <summary>
        /// 回调地址
        /// </summary>
        public string CallbackUrl { get; set; }
    }

    /// <summary>
    /// 微信授权参数
    /// </summary>
    public class WeixinOauth2AuthorizeRequest : WeixinAuthorizeRequest
    {
        /// <summary>
        /// 是否需要用户手动确认
        /// </summary>
        public bool NeedConfirm { get; set; }
    }

    /// <summary>
    /// 企业微信登录参数
    /// </summary>
    public class WorkWeixinSsoQrConnectRequest: WeixinAuthorizeRequest
    {
        /// <summary>
        /// 企业应用ID
        /// </summary>
        public int AgentId { get; set; }
    }
}
