﻿
using SqlSugar;
using System;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 
    /// </summary>
    public interface IHasCreatorId
    {
        /// <summary>
        /// 
        /// </summary>
        int CreatorId { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public interface IHasModifyTime
    {
        /// <summary>
        /// 
        /// </summary>
        DateTime? ModifyTime { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public interface IHasDeleted
    {
        /// <summary>
        /// 
        /// </summary>
        bool Deleted { get; set; }
    }

    /// <summary>
    /// 实体基类
    /// </summary>
    public class BaseEntity
    {
        /// <summary>
        /// 主键Id
        /// </summary>
        [SugarColumn(IsPrimaryKey = true, IsIdentity = true)]
        public int Id { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime AddTime { get; set; } = DateTime.Now;
    }

    /// <summary>
    /// 实体基类（有修改时间）
    /// </summary>
    public class ModifyEntity: BaseEntity
    {
        /// <summary>
        /// 修改时间
        /// </summary>
        public DateTime? ModifyTime { get; set; } = DateTime.Now;
    }

    /// <summary>
    /// 实体基类（有删除标识、修改时间）
    /// </summary>
    public class ModifyDeleteEntity : ModifyEntity, IHasDeleted
    {
        /// <summary>
        /// 是否删除
        /// </summary>
        public bool Deleted { get; set; }
    } 
}
