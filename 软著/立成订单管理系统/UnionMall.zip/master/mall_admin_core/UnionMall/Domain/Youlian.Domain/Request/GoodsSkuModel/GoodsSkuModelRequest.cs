﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    public class GoodsSkuModelRequest
    {
        public int Id { get; set; } = 0;
        public string SkuName { get; set; }
        public int Sort { get; set; }
        public List<GoodsSkuModelValueRequest> GoodsSkuModelValues { get; set; }
    }
    public class GoodsSkuModelValueRequest {
        public int Id { get; set; }
        public string SpecValue { get; set; }
    }
}
