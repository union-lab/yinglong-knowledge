﻿using System.ComponentModel;

namespace Youlian.Domain.Enums
{
    /// <summary>
    /// 系统端枚举
    /// </summary>
    public enum SystemClientEnum
    {
        /// <summary>
        /// Admin
        /// </summary>
        [Description("Admin")]
        Admin = 0,

        /// <summary>
        /// 员工端
        /// </summary>
        [Description("员工端")]
        员工端 = 1,
        /// <summary>
        /// 业务员
        /// </summary>
        [Description("业务员")]
        业务员 = 2,

        /// <summary>
        /// 用户
        /// </summary>
        [Description("用户")]
        用户 = 3,
    }

    /// <summary>
    /// 配置类型
    /// </summary>
    public enum ConfigTypeEnum
    {
        /// <summary>
        /// 总控
        /// </summary>
        [Description("总控")]

        总控 = 0,
        /// <summary>
        /// 员工端
        /// </summary>
        [Description("员工端")]
        员工端 = 1,

        /// <summary>
        /// 业务员
        /// </summary>
        [Description("业务员")]
        业务员 = 2,
    }

    

   

    /// <summary>
    /// 审核状态
    /// </summary>
    public enum AuditStatusEnum
    {
        /// <summary>
        /// 未提交
        /// </summary>
        [Description("未提交")]
        未提交 = -1,

        /// <summary>
        /// 待审核
        /// </summary>
        [Description("待审核")]
        待审核 = 0,

        /// <summary>
        /// 审核通过
        /// </summary>
        [Description("审核通过")]
        审核通过 = 1,

        /// <summary>
        /// 审核未过
        /// </summary>
        [Description("审核未过")]
        审核未过 = 2
    }
    

    /// <summary>
    /// API文档分组
    /// </summary>
    public enum OpenApiGroup
    {
        /// <summary>
        /// 
        /// </summary>
        [Description("Admin")]
        Admin = 1,

        /// <summary>
        /// 
        /// </summary>
        [Description("WeixinApp")]
        WeixinApp = 2
    }

    /// <summary>
    /// 回调通知类型
    /// </summary>
    public enum CallbackNotifyTypeEnum
    {
        /// <summary>
        /// 
        /// </summary>
        企业微信通知=10
    }

    /// <summary>
    /// 回调通知处理状态
    /// </summary>
    public enum CallbackNotifyStatusEnum 
    { 
        /// <summary>
        /// 
        /// </summary>
        未处理=0,
        /// <summary>
        /// 
        /// </summary>
        处理成功=1,
        /// <summary>
        /// 
        /// </summary>
        处理失败=2,
    }

    /// <summary>
    /// 
    /// </summary>
    public enum ApiEnum
    {

    }

    /// <summary>
    /// 
    /// </summary>
    public enum ApiLogStatusEnum
    {
        /// <summary>
        /// 
        /// </summary>
        请求失败 = 0,
        /// <summary>
        /// 
        /// </summary>
        请求成功 = 1
    }

    /// <summary>
    /// 
    /// </summary>
    public enum ApiLogRelateTypeEnum
    {
        /// <summary>
        /// 
        /// </summary>
        无 = 0
    }

    /// <summary>
    /// 拥有自定义属性实体枚举
    /// </summary>
    public enum CustomPropertyEntityTypeEnum
    {
        /// <summary>
        /// HRMS员工
        /// </summary>
        HREmployee = 1
    }

    /// <summary>
    /// 消息渠道
    /// </summary>
    public enum MessageChannelEnum
    {
        /// <summary>
        /// 
        /// </summary>
        企业微信 = 1
    }

    /// <summary>
    /// 消息类型
    /// </summary>
    public enum MessageTypeEnum
    {
        /// <summary>
        /// 
        /// </summary>
        绩效考核结果通知 = 10000
    }
}
