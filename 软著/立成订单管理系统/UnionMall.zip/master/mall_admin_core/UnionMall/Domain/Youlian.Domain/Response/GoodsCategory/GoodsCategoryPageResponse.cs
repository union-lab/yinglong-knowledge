﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    public class GoodsCategoryPageResponse
    {
        public int Id{ get; set; }
        public string CategoryName { get; set; }
        public int ParentId { get; set; }
        public int Sort { get; set; }
        public string CategoryIco { get; set; }
        public bool IsShowHomePage { get; set; }
        public bool IsShow { get; set; }
        public DateTime ModifyTime { get; set; }
    }
}
