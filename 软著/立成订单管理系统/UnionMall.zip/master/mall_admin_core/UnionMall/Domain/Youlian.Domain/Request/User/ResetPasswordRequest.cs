﻿using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Request
{
    /// <summary>
    /// 试客重置密码
    /// </summary>
    public class MadouResetPasswordRequest
    {
        /// <summary>
        /// 
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// 新密码
        /// </summary>
        public string Password { get; set; }
    }

    /// <summary>
    /// 商家重置密码
    /// </summary>
    public class SellerResetPasswordRequest : ResetPasswordRequest
    {
        /// <summary>
        /// 短信验证码
        /// </summary>
        public string SmsCode { get; set; }
    }

    /// <summary>
    /// 重置密码
    /// </summary>
    public class ResetPasswordRequest
    {
        /// <summary>
        /// 
        /// </summary>
        public UserTypeEnum UserType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Password { get; set; }
    }
}
