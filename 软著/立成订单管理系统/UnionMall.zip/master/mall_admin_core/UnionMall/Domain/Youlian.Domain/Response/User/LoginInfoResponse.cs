﻿using Youlian.Common.Extention;
using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// Admin用户登录信息
    /// </summary>
    public class AdminLoginInfoResponse : BaseLoginInfoResponse
    {
        /// <summary>
        /// 姓名
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        /// 角色
        /// </summary>
        public List<string> Roles { get; set; }

        /// <summary>
        /// 登录后弹窗显示的公告
        /// </summary>
        public List<TopShowNoticeResponse> TopShowSystemNotice { get; set; }

    }
    /// <summary>
    /// 用户登录信息
    /// </summary>
    public class LoginInfoResponse : BaseLoginInfoResponse
    {
        /// <summary>
        /// 姓名
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        /// 昵称
        /// </summary>
        public string NickName { get; set; }

        /// <summary>
        /// 是否关注
        /// </summary>
        public bool? Subscribe { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class EmployeeLoginInfoResponse : BaseLoginInfoResponse
    {
        /// <summary>
        /// 姓名
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        /// 是否部门负责人
        /// </summary>
        public bool IsDepartmentLeader { get; set; }
    }
}
