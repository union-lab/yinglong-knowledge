﻿using SqlSugar;
using System;
using Youlian.Domain.Enums;
using Youlian.SDK.Weixin.Work;

namespace Youlian.Domain.Entities
{
    /// <summary>
    /// 审批单
    /// </summary>
    [SugarTable("t_wwx_approval")]
    public class Approval : ModifyEntity
    {
        /// <summary>
        /// 审批编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 模板名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 模板ID
        /// </summary>
        public string Template { get; set; }

        /// <summary>
        /// 申请时间
        /// </summary>
        public DateTime ApplyTime { get; set; }

        /// <summary>
        /// 审批类型
        /// </summary>
        public SysApprovalTypeEnum Type { get; set; }

        /// <summary>
        /// 审批状态
        /// </summary>
        public SysApprovalStatusEnum Status { get; set; }
    }
}