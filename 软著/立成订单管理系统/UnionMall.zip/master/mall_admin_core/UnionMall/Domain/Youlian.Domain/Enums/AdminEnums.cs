﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Domain.Enums
{
    /// <summary>
    /// 系统菜单类型
    /// </summary>
    public enum SysMenuTypeEnum
    {
        /// <summary>
        /// 
        /// </summary>
        菜单 = 0,
        /// <summary>
        /// 
        /// </summary>
        功能 = 1
    }
    /// <summary>
    /// 系统菜单类型
    /// </summary>
    public enum SysMenuStatusEnum
    {
        /// <summary>
        /// 
        /// </summary>
        隐藏 = 0,
        /// <summary>
        /// 
        /// </summary>
        显示 = 1
    }
    /// <summary>
    /// 操作权限枚举
    /// </summary>
    public enum ActionEnum
    {
        /// <summary>
        /// 查询
        /// </summary>
        [Description("查询")]
        View = 0,
        /// <summary>
        /// 新增
        /// </summary>
        [Description("新增")]
        Add = 1,
        /// <summary>
        /// 修改
        /// </summary>
        [Description("修改")]
        Update = 2,
        /// <summary>
        /// 删除
        /// </summary>
        [Description("删除")]
        Delete = 3,
        /// <summary>
        /// 审核
        /// </summary>
        [Description("审核")]
        Audit = 4,
        /// <summary>
        /// 导入
        /// </summary>
        [Description("导入")]
        Import = 5,
        /// <summary>
        /// 导出
        /// </summary>
        [Description("导出")]
        Export = 6
    }

    /// <summary>
    /// 账户状态
    /// </summary>
    public enum ActiveEnum
    {
        /// <summary>
        /// 禁用
        /// </summary>
        禁用 = 0,
        /// <summary>
        /// 启用
        /// </summary>
        启用 = 1,
    }

    /// <summary>
    /// 系统日志类型
    /// </summary>
    public enum SysLogTypeEnum
    {
        //未定义 = 0,
        /// <summary>
        /// 
        /// </summary>
        用户登录 = 1,
        /// <summary>
        /// 
        /// </summary>
        修改用户名 = 2,

        /// <summary>
        /// 
        /// </summary>
        微信通讯录回调=1001,

        /// <summary>
        /// 
        /// </summary>
        接口错误 = 9990,

        /// <summary>
        /// 
        /// </summary>
        系统错误 = 9991
    }
}
