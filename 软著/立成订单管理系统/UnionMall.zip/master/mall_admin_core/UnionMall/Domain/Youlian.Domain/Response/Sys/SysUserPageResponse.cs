﻿using Youlian.Common.Extention;
using Youlian.Domain.Enums;
using System;
using System.Collections.Generic;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 系统用户列表
    /// </summary>
    public class SysUserPageResponse
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime AddTime { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        /// 部门
        /// </summary>
        public string Department { get; set; }

        /// <summary>
        /// 职位
        /// </summary>
        public string Position { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string Tel { get; set; }

        /// <summary>
        /// 角色Ids
        /// </summary>
        public string RoleIds { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public ActiveEnum Active { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public string ActiveName => Active.ToString();

        /// <summary>
        /// 是否删除
        /// </summary>
        public bool Deleted { get; set; }
    }
}