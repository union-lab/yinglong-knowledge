﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Request;

namespace Youlian.Domain.Response
{
    /// <summary>
    /// 
    /// </summary>
    public class AreaComponentResponse
    {
        /// <summary>
        /// 
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 拼音首字母
        /// </summary>
        public string PinyinPrefix { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool Leaf { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<AreaComponentResponse> Children { get; set; }
    }
}