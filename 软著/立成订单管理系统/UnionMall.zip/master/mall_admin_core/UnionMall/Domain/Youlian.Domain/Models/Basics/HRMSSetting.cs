﻿using Youlian.Domain.Enums;
using System.Collections.Generic;
using System.ComponentModel;

namespace Youlian.Domain.Models.Basics
{
    /// <summary>
    /// HR模块相关设置
    /// </summary>
    public class HRMSSetting : IBasicsConfig
    {
        /// <summary>
        /// 提醒微信用户ID,逗号分隔
        /// </summary>
        public string RemindWxUserIds { get; set; }

        /// <summary>
        /// 开启转正提醒
        /// </summary>
        public bool IsRemindOfficialStaff { get; set; }
        /// <summary>
        /// 是否开启转正提醒提醒对应部门经理人
        /// </summary>
        public bool IsRemindLeader { get; set; }

        /// <summary>
        /// 开启合同到期提醒
        /// </summary>
        public bool IsRemindContractExpire { get; set; }

        /// <summary>
        /// 开启离职一个月提醒
        /// </summary>
        public bool IsRemindToResign { get; set; }
        /// <summary>
        /// 入职提醒
        /// </summary>
        public bool IsRemindToEntry { get; set; }
        /// <summary>
        /// 入职提醒信息内容模板
        /// </summary>
        public string EntryContent { get; set; }
    }
}
