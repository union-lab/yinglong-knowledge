﻿using Youlian.Domain.Request;
using Youlian.Domain.Response;
using SqlSugar;
using System.Threading.Tasks;

namespace Youlian.Repository
{
    /// <summary>
    /// 查询扩展
    /// </summary>
    public static class QueryableExtension
    {
        /// <summary>
        /// 读取列表
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public static async Task<PageResponse<T>> ToPageAsync<T>(this ISugarQueryable<T> source, PageRequest parm)
        {
            var page = new PageResponse<T>();
            RefAsync<int> total = 0;
            page.Data = await source.OrderByIF(!string.IsNullOrEmpty(parm.OrderBy), $"{parm.Sort} {(parm.OrderBy == "desc" ? "desc" : "asc")}").ToPageListAsync(parm.PageIndex, parm.PageSize, total);
            page.Total = total;
            return page;
        }

        /// <summary>
        /// 读取列表
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public static PageResponse<T> ToPage<T>(this ISugarQueryable<T> source, PageRequest parm)
        {
            var page = new PageResponse<T>();
            var total = 0;
            page.Data = source.OrderByIF(!string.IsNullOrEmpty(parm.OrderBy), $"{parm.Sort} {(parm.OrderBy == "desc" ? "desc" : "asc")}").ToPageList(parm.PageIndex, parm.PageSize,ref total);
            page.Total = total;
            return page;
        }

    }
}
