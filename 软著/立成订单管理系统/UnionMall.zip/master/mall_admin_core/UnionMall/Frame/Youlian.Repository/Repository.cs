﻿using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Response;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Youlian.Repository
{
    public class Repository<T> : DbContext, IRepository<T> where T : BaseEntity, new()
    {

        SqlSugarScope IRepository<T>._db => _db;

        ISugarQueryable<T> IRepository<T>.Queryable => _db.Queryable<T>();
        IUpdateable<T> IRepository<T>.Updateable => _db.Updateable<T>();

        #region 构造函数

        public Repository()
        {

        }
        #endregion

        #region 添加操作
        /// <summary>
        /// 添加一条数据
        /// </summary>
        /// <param name="model">T</param>
        /// <returns></returns>
        public bool Insert(T model)
        {
            return _db.Insertable(model).ExecuteCommandIdentityIntoEntity();
        }


        /// <summary>
        /// 添加一条数据
        /// </summary>
        /// <param name="model">T</param>
        /// <returns></returns>
        public async Task<bool> InsertAsync(T model)
        {
            return await _db.Insertable(model).ExecuteCommandIdentityIntoEntityAsync();
        }

        /// <summary>
        /// 添加一条数据
        /// </summary>
        /// <param name="model">T</param>
        /// <returns></returns>
        public async Task<bool> InsertAsync<T1>(object model) where T1 : class, new()
        {
            return await _db.Insertable<T1>(model).ExecuteCommandIdentityIntoEntityAsync();
        }


        /// <summary>
        /// 批量添加数据
        /// </summary>
        /// <param name="models">List<T></param>
        /// <returns></returns>
        public int Insert(List<T> models)
        {
            return _db.Insertable(models).ExecuteCommand();
        }


        /// <summary>
        /// 批量添加数据
        /// </summary>
        /// <param name="models">List<T></param>
        /// <returns></returns>
        public async Task<int> InsertAsync(List<T> models)
        {
            return await _db.Insertable(models).ExecuteCommandAsync();
        }


        /// <summary>
        /// 添加或更新数据
        /// </summary>
        /// <param name="model">List<T></param>
        /// <returns></returns>
        public T Saveable(T model, Expression<Func<T, object>> uClumns = null, Expression<Func<T, object>> iColumns = null)
        {
            var command = _db.Saveable(model);

            if (uClumns != null)
            {
                command = command.UpdateIgnoreColumns(uClumns);
            }

            if (iColumns != null)
            {
                command = command.InsertIgnoreColumns(iColumns);
            }
            return command.ExecuteReturnEntity();
        }


        /// <summary>
        /// 添加或更新数据
        /// </summary>
        /// <param name="model">List<T></param>
        /// <returns></returns>
        public async Task<T> SaveableAsync(T model, Expression<Func<T, object>> uClumns = null, Expression<Func<T, object>> iColumns = null)
        {
            var command = _db.Saveable(model);

            if (uClumns != null)
            {
                command = command.UpdateIgnoreColumns(uClumns);
            }

            if (iColumns != null)
            {
                command = command.InsertIgnoreColumns(iColumns);
            }
            return await command.ExecuteReturnEntityAsync();
        }


        /// <summary>
        /// 批量添加或更新数据
        /// </summary>
        /// <param name="models">List<T></param>
        /// <returns></returns>
        public List<T> Saveable(List<T> models, Expression<Func<T, object>> uClumns = null, Expression<Func<T, object>> iColumns = null)
        {
            var command = _db.Saveable(models);
            if (uClumns != null)
            {
                command = command.UpdateIgnoreColumns(uClumns);
            }
            if (iColumns != null)
            {
                command = command.InsertIgnoreColumns(iColumns);
            }
            return command.ExecuteReturnList();
        }


        /// <summary>
        /// 批量添加或更新数据
        /// </summary>
        /// <param name="models">List<T></param>
        /// <returns></returns>
        public async Task<List<T>> SaveableAsync(List<T> models, Expression<Func<T, object>> uClumns = null, Expression<Func<T, object>> iColumns = null)
        {
            var command = _db.Saveable(models);
            if (uClumns != null)
            {
                command = command.UpdateIgnoreColumns(uClumns);
            }
            if (iColumns != null)
            {
                command = command.InsertIgnoreColumns(iColumns);
            }
            return await command.ExecuteReturnListAsync();
        }

        #endregion

        #region 删除操作
        /// <summary>
        /// 删除一条或多条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        public int Delete(int id)
        {
            return _db.Deleteable<T>(id).ExecuteCommand();
        }


        /// <summary>
        /// 删除一条或多条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        public async Task<int> DeleteAsync(int id)
        {
            return await _db.Deleteable<T>(id).ExecuteCommandAsync();
        }

        /// <summary>
        /// 删除一条或多条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        public async Task<int> DeleteAsync<T1>(Expression<Func<T1, bool>> where) where T1 : class, new()
        {
            return await _db.Deleteable<T1>().Where(where).ExecuteCommandAsync();
        }

        /// <summary>
        /// 删除一条或多条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        public int Delete(int[] ids)
        {
            return _db.Deleteable<T>().In(ids).ExecuteCommand();
        }


        /// <summary>
        /// 删除一条或多条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        public async Task<int> DeleteAsync(int[] ids)
        {
            return await _db.Deleteable<T>().In(ids).ExecuteCommandAsync();
        }


        /// <summary>
        /// 根据条件删除一条或多条数据
        /// </summary>
        /// <param name="where">过滤条件</param>
        /// <returns></returns>
        public int Delete(Expression<Func<T, bool>> where)
        {
            return _db.Deleteable<T>().Where(where).ExecuteCommand();
        }


        /// <summary>
        /// 根据条件删除一条或多条数据
        /// </summary>
        /// <param name="where">过滤条件</param>
        /// <returns></returns>
        public async Task<int> DeleteAsync(Expression<Func<T, bool>> where)
        {
            return await _db.Deleteable<T>().Where(where).ExecuteCommandAsync();
        }
        #endregion

        #region 修改操作


        /// <summary>
        /// 修改一条数据
        /// </summary>
        /// <param name="model">T</param>
        /// <returns></returns>
        public int Update(T model, Expression<Func<T, object>> columns = null, Expression<Func<T, bool>> where = null)
        {
            var query = _db.Updateable<T>(model).UpdateColumnsIF(columns != null, columns);
            if (where != null)
            {
                query = query.Where(where);
            }
            return query.ExecuteCommand();
        }

        /// <summary>
        /// 修改一条数据
        /// </summary>
        /// <param name="model">T</param>
        /// <returns></returns>
        public async Task<int> UpdateAsync(T model, Expression<Func<T, object>> columns = null, Expression<Func<T, bool>> where = null)
        {
            var query = _db.Updateable<T>(model).UpdateColumnsIF(columns != null, columns);
            if (where != null)
            {
                query = query.Where(where);
            }
            return await query.ExecuteCommandAsync();
        }

        /// <summary>
        /// 批量修改
        /// </summary>
        /// <param name="models">T</param>
        /// <returns></returns>
        public int Update(List<T> models, Expression<Func<T, object>> columns = null)
        {
            return _db.Updateable(models).UpdateColumnsIF(columns != null, columns).ExecuteCommand();
        }

        /// <summary>
        /// 批量修改
        /// </summary>
        /// <param name="models">T</param>
        /// <returns></returns>
        public async Task<int> UpdateAsync(List<T> models, Expression<Func<T, object>> columns = null)
        {
            return await _db.Updateable(models).UpdateColumnsIF(columns != null, columns).ExecuteCommandAsync();
        }
        #endregion

        #region 查询操作
        /// <summary>
        /// 根据条件查询数据是否存在
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        public bool Any(Expression<Func<T, bool>> where)
        {
            return _db.Queryable<T>().Any(where);
        }


        /// <summary>
        /// 根据条件查询数据是否存在
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        public async Task<bool> AnyAsync(Expression<Func<T, bool>> where)
        {
            return await _db.Queryable<T>().AnyAsync(where);
        }


        /// <summary>
        /// 根据条件合计字段
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        public TResult Sum<TResult>(Expression<Func<T, bool>> where, Expression<Func<T, TResult>> field)
        {
            return _db.Queryable<T>().Where(where).Sum(field);
        }


        /// <summary>
        /// 根据条件合计字段
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        public async Task<TResult> SumAsync<TResult>(Expression<Func<T, bool>> where, Expression<Func<T, TResult>> field)
        {
            return await _db.Queryable<T>().Where(where).SumAsync(field);
        }


        /// <summary>
        /// 根据主值查询单条数据
        /// </summary>
        /// <param name="pkValue">主键值</param>
        /// <returns>泛型实体</returns>
        public T GetById(int pkValue)
        {
            return _db.Queryable<T>().InSingle(pkValue);
        }


        /// <summary>
        /// 根据主值查询单条数据
        /// </summary>
        /// <param name="pkValue">主键值</param>
        /// <returns>泛型实体</returns>
        public async Task<T> GetByIdAsync(int pkValue)
        {
            return await _db.Queryable<T>().InSingleAsync(pkValue);
        }


        /// <summary>
        /// 根据主键查询多条数据
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public List<T> GetIn(int[] ids)
        {
            return _db.Queryable<T>().In(ids).ToList();
        }


        /// <summary>
        /// 根据主键查询多条数据
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public async Task<List<T>> GetInAsync(int[] ids)
        {
            return await _db.Queryable<T>().In(ids).ToListAsync();
        }


        /// <summary>
        /// 根据条件取条数
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        public int GetCount(Expression<Func<T, bool>> where)
        {
            if (where == null) return _db.Queryable<T>().Count();
            return _db.Queryable<T>().Count(where);
        }


        /// <summary>
        /// 根据条件取条数
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        public async Task<int> GetCountAsync(Expression<Func<T, bool>> where)
        {
            if (where == null) return await _db.Queryable<T>().CountAsync();
            return await _db.Queryable<T>().CountAsync(where);
        }

        /// <summary>
        /// 查询所有数据(无分页,请慎用)
        /// </summary>
        /// <returns></returns>
        public List<T> GetAll(bool useCache = false, int cacheSecond = 3600)
        {
            return _db.Queryable<T>().WithCacheIF(useCache, cacheSecond).ToList();
        }


        /// <summary>
        /// 查询所有数据(无分页,请慎用)
        /// </summary>
        /// <returns></returns>
        public async Task<List<T>> GetAllAsync(bool useCache = false, int cacheSecond = 3600)
        {
            return await _db.Queryable<T>().WithCacheIF(useCache, cacheSecond).ToListAsync();
        }


        /// <summary>
        /// 获得一条数据
        /// </summary>
        /// <param name="where">Expression<Func<T, bool>></param>
        /// <returns></returns>
        public T GetFirst(Expression<Func<T, bool>> where)
        {
            return _db.Queryable<T>().Where(where).First();
        }


        /// <summary>
        /// 获得一条数据
        /// </summary>
        /// <param name="where">Expression<Func<T, bool>></param>
        /// <returns></returns>
        public async Task<T> GetFirstAsync(Expression<Func<T, bool>> where, Expression<Func<T, object>> order = null)
        {
            return await _db.Queryable<T>().Where(where)
               .OrderByIF(order != null, order, OrderByType.Asc)
                .FirstAsync();
        }

        /// <summary>
        /// 获得一条数据
        /// </summary>
        /// <param name="where">Expression<Func<T, bool>></param>
        /// <returns></returns>
        public async Task<T> GetLastAsync(Expression<Func<T, bool>> where, Expression<Func<T, object>> order)
        {
            return await _db.Queryable<T>().Where(where)
               .OrderBy(order, OrderByType.Desc)
                .FirstAsync();
        }

        /// <summary>
        /// 获得一条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        public T GetFirst(string parm)
        {
            return _db.Queryable<T>().Where(parm).First();
        }


        /// <summary>
        /// 获得一条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        public async Task<T> GetFirstAsync(string parm)
        {
            return await _db.Queryable<T>().Where(parm).FirstAsync();
        }


        /// <summary>
        /// 根据条件查询分页数据
        /// </summary>
        /// <param name="where"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        public PageResponse<T> GetPages(Expression<Func<T, bool>> where, PageRequest page)
        {
            var source = _db.Queryable<T>().Where(where);
            return source.ToPage(page);
        }


        /// <summary>
        /// 根据条件查询分页数据
        /// </summary>
        /// <param name="where"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        public async Task<PageResponse<T>> GetPagesAsync(Expression<Func<T, bool>> where, PageRequest page, Expression<Func<T, object>> order = null, bool isAsc = false)
        {
            var source = _db.Queryable<T>().Where(where).OrderByIF(order != null, order, isAsc ? OrderByType.Asc : OrderByType.Desc);
            return await source.ToPageAsync(page);
        }

        /// <summary>
        /// 根据条件查询数据
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        public List<T> GetWhere(Expression<Func<T, bool>> where, Expression<Func<T, object>> order, OrderByType type = OrderByType.Desc, bool useCache = false, int cacheSecond = 3600)
        {
            var query = _db.Queryable<T>().Where(where).OrderByIF(order != null, order, type)
                .WithCacheIF(useCache, cacheSecond);
            return query.ToList();
        }

        public ISugarQueryable<T> GetQuery(Expression<Func<T, bool>> where, Expression<Func<T, object>> order = null, OrderByType type = OrderByType.Desc)
        {
            var query = _db.Queryable<T>().WhereIF(where != null, where).OrderByIF(order != null, order, type);
            return query;
        }

        /// <summary>
        /// 根据条件查询数据
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        public async Task<List<T>> GetWhereAsync(Expression<Func<T, bool>> where, Expression<Func<T, object>> order = null, OrderByType type = OrderByType.Desc, bool useCache = false, int cacheSecond = 3600)
        {
            var query = _db.Queryable<T>().Where(where).OrderByIF(order != null, order, type).WithCacheIF(useCache, cacheSecond);
            return await query.ToListAsync();
        }

        /// <summary>
        /// 根据条件查询数据
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        public async Task<List<TResult>> GetWhereByDtoAsync<TResult>(Expression<Func<T, bool>> where, Expression<Func<T, object>> order = null, OrderByType type = OrderByType.Desc, bool useCache = false, int cacheSecond = 3600)
        {
            var query = _db.Queryable<T>().Where(where).OrderByIF(order != null, order, type).WithCacheIF(useCache, cacheSecond);
            return await query.Select<TResult>().ToListAsync();
        }

        #endregion
    }
}
