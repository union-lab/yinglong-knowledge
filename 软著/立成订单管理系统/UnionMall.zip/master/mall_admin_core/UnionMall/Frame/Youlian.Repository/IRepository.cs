﻿using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Response;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Youlian.Repository
{
    public interface IRepository<T> where T : BaseEntity, new()
    {
        SqlSugarScope _db { get; }

        ISugarQueryable<T> Queryable { get; }
        IUpdateable<T> Updateable { get; }

        #region 添加操作
        /// <summary>
        /// 添加一条数据
        /// </summary>
        /// <param name="model">T</param>
        /// <returns></returns>
        bool Insert(T model);


        /// <summary>
        /// 添加一条数据
        /// </summary>
        /// <param name="model">T</param>
        /// <returns></returns>
        Task<bool> InsertAsync(T model);


        /// <summary>
        /// 批量添加数据
        /// </summary>
        /// <param name="models">List<T></param>
        /// <returns></returns>
        int Insert(List<T> models);


        /// <summary>
        /// 批量添加数据
        /// </summary>
        /// <param name="models">List<T></param>
        /// <returns></returns>
        Task<int> InsertAsync(List<T> models);


        /// <summary>
        /// 添加或更新数据
        /// </summary>
        /// <param name="model">List<T></param>
        /// <returns></returns>
        T Saveable(T model, Expression<Func<T, object>> uClumns = null, Expression<Func<T, object>> iColumns = null);


        /// <summary>
        /// 添加或更新数据
        /// </summary>
        /// <param name="model">List<T></param>
        /// <returns></returns>
        Task<T> SaveableAsync(T model, Expression<Func<T, object>> uClumns = null, Expression<Func<T, object>> iColumns = null);


        /// <summary>
        /// 批量添加或更新数据
        /// </summary>
        /// <param name="models">List<T></param>
        /// <returns></returns>
        List<T> Saveable(List<T> models, Expression<Func<T, object>> uClumns = null, Expression<Func<T, object>> iColumns = null);


        /// <summary>
        /// 批量添加或更新数据
        /// </summary>
        /// <param name="models">List<T></param>
        /// <returns></returns>
        Task<List<T>> SaveableAsync(List<T> models, Expression<Func<T, object>> uClumns = null, Expression<Func<T, object>> iColumns = null);
        #endregion


        #region 删除操作
        /// <summary>
        /// 删除一条或多条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        int Delete(int id);


        /// <summary>
        /// 删除一条或多条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        Task<int> DeleteAsync(int id);


        /// <summary>
        /// 删除一条或多条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        int Delete(int[] ids);


        /// <summary>
        /// 删除一条或多条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        Task<int> DeleteAsync(int[] ids);


        /// <summary>
        /// 根据条件删除一条或多条数据
        /// </summary>
        /// <param name="where">过滤条件</param>
        /// <returns></returns>
        int Delete(Expression<Func<T, bool>> where);


        /// <summary>
        /// 根据条件删除一条或多条数据
        /// </summary>
        /// <param name="where">过滤条件</param>
        /// <returns></returns>
        Task<int> DeleteAsync(Expression<Func<T, bool>> where);
        #endregion


        #region 修改操作
        /// <summary>
        /// 修改一条数据
        /// </summary>
        /// <param name="model">T</param>
        /// <returns></returns>
        int Update(T model, Expression<Func<T, object>> columns = null, Expression<Func<T, bool>> where = null);


        /// <summary>
        /// 修改一条数据
        /// </summary>
        /// <param name="model">T</param>
        /// <returns></returns>
        Task<int> UpdateAsync(T model, Expression<Func<T, object>> columns = null, Expression<Func<T, bool>> where = null);


        /// <summary>
        /// 批量修改
        /// </summary>
        /// <param name="models"></param>
        /// <param name="columns"></param>
        /// <returns></returns>
        int Update(List<T> models, Expression<Func<T, object>> columns = null);

        /// <summary>
        /// 批量修改
        /// </summary>
        /// <param name="models"></param>
        /// <param name="columns"></param>
        /// <returns></returns>
        Task<int> UpdateAsync(List<T> models, Expression<Func<T, object>> columns = null);

        #endregion


        #region 查询操作
        /// <summary>
        /// 根据条件查询数据是否存在
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        bool Any(Expression<Func<T, bool>> where);


        /// <summary>
        /// 根据条件查询数据是否存在
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        Task<bool> AnyAsync(Expression<Func<T, bool>> where);


        /// <summary>
        /// 根据条件合计字段
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        TResult Sum<TResult>(Expression<Func<T, bool>> where, Expression<Func<T, TResult>> field);


        /// <summary>
        /// 根据条件合计字段
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        Task<TResult> SumAsync<TResult>(Expression<Func<T, bool>> where, Expression<Func<T, TResult>> field);


        /// <summary>
        /// 根据主值查询单条数据
        /// </summary>
        /// <param name="pkValue">主键值</param>
        /// <returns>泛型实体</returns>
        T GetById(int pkValue);


        /// <summary>
        /// 根据主值查询单条数据
        /// </summary>
        /// <param name="pkValue">主键值</param>
        /// <returns>泛型实体</returns>
        Task<T> GetByIdAsync(int pkValue);


        /// <summary>
        /// 根据主键查询多条数据
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        List<T> GetIn(int[] ids);


        /// <summary>
        /// 根据主键查询多条数据
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        Task<List<T>> GetInAsync(int[] ids);


        /// <summary>
        /// 根据条件取条数
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        int GetCount(Expression<Func<T, bool>> where);


        /// <summary>
        /// 根据条件取条数
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        Task<int> GetCountAsync(Expression<Func<T, bool>> where);

        /// <summary>
        /// 查询所有数据(无分页,请慎用)
        /// </summary>
        /// <returns></returns>
        List<T> GetAll(bool useCache = false, int cacheSecond = 3600);

        /// <summary>
        /// 查询所有数据(无分页,请慎用)
        /// </summary>
        /// <returns></returns>
        Task<List<T>> GetAllAsync(bool useCache = false, int cacheSecond = 3600);


        /// <summary>
        /// 获得一条数据
        /// </summary>
        /// <param name="where">Expression<Func<T, bool>></param>
        /// <returns></returns>
        T GetFirst(Expression<Func<T, bool>> where);


        /// <summary>
        /// 获得一条数据
        /// </summary>
        /// <param name="where">Expression<Func<T, bool>></param>
        /// <returns></returns>
        Task<T> GetFirstAsync(Expression<Func<T, bool>> where, Expression<Func<T, object>> order = null);

        /// <summary>
        /// 获得一条数据
        /// </summary>
        /// <param name="where">Expression<Func<T, bool>></param>
        /// <returns></returns>
        Task<T> GetLastAsync(Expression<Func<T, bool>> where, Expression<Func<T, object>> order);

        /// <summary>
        /// 获得一条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        T GetFirst(string parm);

        /// <summary>
        /// 获得一条数据
        /// </summary>
        /// <param name="parm">string</param>
        /// <returns></returns>
        Task<T> GetFirstAsync(string parm);

        /// <summary>
        /// 根据条件查询分页数据
        /// </summary>
        /// <param name="where"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        PageResponse<T> GetPages(Expression<Func<T, bool>> where, PageRequest page);


        /// <summary>
        /// 根据条件查询分页数据
        /// </summary>
        /// <param name="where"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        Task<PageResponse<T>> GetPagesAsync(Expression<Func<T, bool>> where, PageRequest page, Expression<Func<T, object>> order = null, bool isAsc = false);

        /// <summary>
        /// 获取当前表查询
        /// </summary>
        ISugarQueryable<T> GetQuery(Expression<Func<T, bool>> where, Expression<Func<T, object>> order = null, OrderByType type = OrderByType.Desc);
        /// <summary>
        /// 根据条件查询数据
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        List<T> GetWhere(Expression<Func<T, bool>> where, Expression<Func<T, object>> order = null, OrderByType type = OrderByType.Desc, bool useCache = false, int cacheSecond = 3600);
        /// <summary>
        /// 根据条件查询数据
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        Task<List<T>> GetWhereAsync(Expression<Func<T, bool>> where, Expression<Func<T, object>> order = null, OrderByType type = OrderByType.Desc, bool useCache = false, int cacheSecond = 3600);

        /// <summary>
        /// 根据条件查询数据DTO
        /// </summary>
        /// <param name="where">条件表达式树</param>
        /// <returns></returns>
        Task<List<TResult>> GetWhereByDtoAsync<TResult>(Expression<Func<T, bool>> where, Expression<Func<T, object>> order = null, OrderByType type = OrderByType.Desc, bool useCache = false, int cacheSecond = 3600);
        #endregion
    }
}
