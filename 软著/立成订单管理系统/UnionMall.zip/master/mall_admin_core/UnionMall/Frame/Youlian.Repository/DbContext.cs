﻿using SqlSugar;
using SqlSugar.IOC;

namespace Youlian.Repository
{
    /// <summary>
    /// 数据库上下文
    /// </summary>
    public class DbContext
    {

        /// <summary>
        /// 用来处理事务多表查询和复杂的操作
        /// </summary>
        protected SqlSugarScope _db => DbScoped.SugarScope;

        /// <summary>
        /// 构造当前上下文
        /// </summary>
        public static DbContext Current
        {
            get
            {
                return new DbContext();
            }
        }

    }
}
