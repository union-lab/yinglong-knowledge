﻿using Mapster;
using Youlian.Common.Extention;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Request;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    public class SysRoleService : BaseService, ISysRoleService
    {
        private readonly ICacheManager _cache;
        private readonly IRepository<SysRole> _repository;
        private readonly IRepository<SysMenu> _sysMenuRepository;
        private readonly IRepository<SysRolePermission>  _permissionRepository;
        public SysRoleService(ICacheManager cache,IRepository<SysRole> repository,IRepository<SysMenu> sysMenuRepository, IRepository<SysRolePermission> permissionRepository)
        {
            _cache = cache;
            _repository = repository;
            _sysMenuRepository = sysMenuRepository;
            _permissionRepository = permissionRepository;
        }

        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<SysRole> GetInfo(int id)
        {
            return await _repository.GetByIdAsync(id);
        }
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<SysRole>> GetList(SysRolePageRequest param)
        {
            Expression<Func<SysRole, bool>> lambda = m => true;
            if (!string.IsNullOrEmpty(param.RoleName)) lambda = lambda.And(m => m.RoleName == param.RoleName);
            var list = await _repository.GetPagesAsync(lambda, param);
            return list;
        }
        #endregion

        #region 编辑角色
        /// <summary>
        /// 编辑角色
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Edit(EditSysRoleRequest param)
        {
            if (param.Id <= 0 && string.IsNullOrEmpty(param.RoleName)) return ResultHelper.Bad("角色名称不能为空");
            if (await _repository.AnyAsync(m => m.RoleName == param.RoleName && m.Id != param.Id)) return ResultHelper.Bad("角色已存在");

            var userId = CurrentUser.Id;
            var result = new Result<int>();

            SysRole entity;
            if (param.Id > 0)
            {
                entity = await _repository.GetByIdAsync(param.Id);
                if (entity == null)
                {
                    return result.Bad("ID不存在");
                }
                entity.RoleName = param.RoleName;
                entity.Description = param.Description;
                await _repository.UpdateAsync(entity);
            }
            else
            {
                entity = param.Adapt<SysRole>();
                entity.CreatorId = userId;
                await _repository.InsertAsync(entity);
            }
            return result.Ok();
        }
        #endregion

        #region 删除角色
        /// <summary>
        /// 删除角色
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Delete(int id)
        {
            var result = await _repository.DeleteAsync(id) > 0;
            return result ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion

        #region 获取权限
        /// <summary>
        /// 获取权限
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<List<SysRoleMenuResponse>> GetMenuPermissionList(int roleId)
        {
            var list = (await _sysMenuRepository.GetWhereAsync(m => true)).Adapt<List<SysRoleMenuResponse>>().OrderBy(m => m.SortId).ThenBy(m => m.Id).ToList();
            var permissionList = await _permissionRepository.GetWhereAsync(m => m.RoleId == roleId);
            foreach (var item in list)
            {
                item.Actions = permissionList.Where(m => m.MenuId == item.Id).SelectMany(m => m.Actions.ToIntArr()).ToList();
            }
            return list;
        }
        #endregion

        #region 设置权限
        /// <summary>
        /// 设置权限
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> EditPermission(RolePermissionEditRequest param)
        {
            var rolePermissions = await _permissionRepository.GetWhereAsync(s => s.RoleId == param.RoleId);
            //先删掉旧数据
            if (rolePermissions.Any())
            {
                await _permissionRepository.DeleteAsync(rolePermissions.Select(m => m.Id).ToList().ToArray());
            }
            rolePermissions = param.List.Select(m => new SysRolePermission()
            {
                MenuId = m.MenuId,
                RoleId = param.RoleId,
                Actions = m.Actions.Distinct().ToJoinStr(),
            }).ToList();
            int ret = await _permissionRepository.InsertAsync(rolePermissions);
            if (ret > 0)
            {
                ClearCache();
                return ResultHelper.Ok(0, "提交成功");
            }
            return ResultHelper.Bad("提交失败");
        }
        #endregion

        #region 权限验证
        /// <summary>
        /// 根据权限标识获取菜单id（从缓存中）
        /// </summary>
        /// <param name="permissions"></param>
        /// <returns></returns>
        public async Task<IEnumerable<int>> GetActions(IEnumerable<int> roleIds, IEnumerable<int> menuIds)
        {
            if (roleIds == null || !roleIds.Any())
            {
                return new List<int>();
            }
            var key = string.Format(CacheKeys.SysRoleMenuAction);
            var list = _cache.Get<List<RolePermissionModel>>(key);
            if (list == null)
            {
                list = (await _permissionRepository.GetWhereAsync(m => true)).Select(m => new RolePermissionModel { RoleId = m.RoleId, MenuId = m.MenuId, Actions = m.Actions }).ToList();
                _cache.Set(key, list, TimeSpan.FromDays(1));
            }
            var result = list.Where(m => roleIds.Contains(m.RoleId) && menuIds.Contains(m.MenuId)).SelectMany(m => m.Actions.ToIntArr()).Distinct();
            //var b = list.Where(m => roleIds.Contains(m.RoleId)).ToList();
            return result;
        }
        /// <summary>
        /// 删除缓存数据
        /// </summary>
        public void ClearCache()
        {
            var key = string.Format(CacheKeys.SysRoleMenuAction);
            _cache.Remove(key);
        }
        #endregion
    }
}
