﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Request.GoodsCategory;
using Youlian.Domain.Response;

namespace Youlian.Services.Abstractions
{
    public interface IGoodsService : IBaseService
    {
        Task<PageResponse<GoodsPageResponse>> GetPageList(GoodsPageRequest param);
        Task<List<SelectComponentResponse>> GetComponentData();
        Task <List<GoodsSkuModelValueResponse>>GetSkuModelValues(int skuId=0);

        Task<Result<Goods>> AddOrEdit(GoodsRequest param);
    }
}
