﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Youlian.Domain.Models;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    public class CookieAuthenticationService : IAuthenticateService
    {
        private readonly IHttpContextAccessor _contextAccessor;
        public CookieAuthenticationService(IHttpContextAccessor contextAccessor)
        {
            _contextAccessor = contextAccessor;
        }

        public async Task<Result<string>> SignInAsync<T>(T param) where T : BaseAuthenticationData
        {
            var identity = new ClaimsIdentity(AppSettings.CookieAuthenticationScheme);
            var claims = new[]
            {
                new Claim(ClaimTypes.PrimarySid, param.Id.ToString()),//PrimarySid保存用户ID
                new Claim(ClaimTypes.Name, param.UserName),
                new Claim(ClaimTypes.UserData,  param.ToJson()),
            };
            identity.AddClaims(claims);
            await _contextAccessor.HttpContext.SignInAsync(AppSettings.CookieAuthenticationScheme, new ClaimsPrincipal(identity));

            return ResultHelper.Ok(string.Empty);
        }

        public async Task<Result<int>> SignOutAsync()
        {
            await _contextAccessor.HttpContext.SignOutAsync(AppSettings.CookieAuthenticationScheme);
            return ResultHelper.Ok();
        }
    }
}
