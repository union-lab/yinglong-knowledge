﻿using log4net;
using Mapster;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using System.Transactions;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Request;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.SDK.Weixin.Work.Models;
using Youlian.Services.Abstractions;

namespace Youlian.Services.Implements
{
    public class AreaService : BaseService, IAreaService
    {
        private readonly ICacheManager _cache;
        private readonly IRepository<Area> _repository;

        public AreaService(ICacheManager cache,
            IRepository<Area> repository)
        {
            _cache = cache;
            _repository = repository;
        }

        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<Area> GetInfo(int id, bool fromCache = false)
        {
            if (fromCache)
            {
                var key = string.Format(CacheKeys.AreaInfo, id);
                var value = _cache.Get<Area>(key);
                if (value == null)
                {
                    value = await _repository.GetFirstAsync(m => m.Id == id);
                    _cache.Set(key, value, TimeSpan.FromDays(1));
                }
                return value;
            }
            return await _repository.GetFirstAsync(m => m.Id == id);
        }
        #endregion

        #region 获取镇/街道信息
        /// <summary>
        /// 获取镇/街道信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<TownModel> GetTownInfo(int id)
        {
            var model = new TownModel()
            {
                TownId = id,
            };
            var area = await GetInfo(id, true);
            if (area == null) return null;
            model.TownName = area.ExtName.IsNull(area.Name);
            area = await GetInfo(area.ParentId, true);
            if (area == null) return model;
            model.DistrictId = area.Id;
            model.DistrictName = area.ExtName.IsNull(area.Name);
            area = await GetInfo(area.ParentId, true);
            if (area == null) return model;
            model.CityId = area.Id;
            model.CityName = area.ExtName.IsNull(area.Name);
            area = await GetInfo(area.ParentId, true);
            if (area == null) return model;
            model.ProvinceId = area.Id;
            model.ProvinceName = area.ExtName.IsNull(area.Name);
            return model;
        }
        #endregion

        #region 获取区县信息
        /// <summary>
        /// 获取区县信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<DistrictModel> GetDistrictInfo(int id)
        {
            var model = new DistrictModel()
            {
                DistrictId = id,
            };
            var area = await GetInfo(id, true);
            if (area == null) return null;
            model.DistrictId = area.Id;
            model.DistrictName = area.ExtName.IsNull(area.Name);
            area = await GetInfo(area.ParentId, true);
            if (area == null) return model;
            model.CityId = area.Id;
            model.CityName = area.ExtName.IsNull(area.Name);
            if (area == null) return model;
            model.ProvinceId = area.Id;
            model.ProvinceName = area.ExtName.IsNull(area.Name);
            return model;
        }
        #endregion

        #region 获取城市信息
        /// <summary>
        /// 获取城市信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<CityModel> GetCityInfo(int id)
        {
            var model = new CityModel()
            {
                CityId = id,
            };
            var area = await GetInfo(id, true);
            if (area == null) return null;
            model.CityId = area.Id;
            model.CityName = area.ExtName.IsNull(area.Name);
            area = await GetInfo(area.ParentId, true);
            if (area == null) return model;
            model.ProvinceId = area.Id;
            model.ProvinceName = area.ExtName.IsNull(area.Name);
            return model;
        }
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<Area>> GetPageList(AreaPageRequest param)
        {
            Expression<Func<Area, bool>> lambda = m => true;
            if (!string.IsNullOrEmpty(param.Name)) lambda = lambda.And(m => m.Name == param.Name);
            if (param.ParentId.HasValue) lambda = lambda.And(m => m.ParentId == param.ParentId);
            var list = await _repository.GetPagesAsync(lambda, param);
            return list;
        }

        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<AreaPageResponse>> GetResponseList(AreaPageRequest param)
        {
            var list = await GetPageList(param);
            var newList = list.Adapt<PageResponse<AreaPageResponse>>();
            return newList;
        }
        #endregion

        #region 获取区域组件数据
        /// <summary>
        /// 获取区域组件数据
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<List<AreaComponentResponse>> GetComponentData(AreaComponentRequest param, bool fromCache = false)
        {
            if (!param.ParentId.HasValue) return new List<AreaComponentResponse>();
            List<Area> list = null;
            if (fromCache)
            {
                var key = string.Format(CacheKeys.AreaComponentInfo, param.ParentId);
                list = _cache.Get<List<Area>>(key);
                if (list == null)
                {
                    list = await _repository.GetWhereAsync(m => m.ParentId == param.ParentId);
                    _cache.Set(key, list, TimeSpan.FromDays(30));
                }
            }
            else
            {
                list = await _repository.GetWhereAsync(m => m.ParentId == param.ParentId);
            }
            var newList = list.Select(m => new AreaComponentResponse()
            {
                Id = m.Id,
                Name = m.ExtName.IsNull(m.Name),
            }).ToList();
            if (param.TownId.HasValue)
            {
                var townInfo = await GetTownInfo(param.TownId.Value);
                if (townInfo == null) return newList;
                var item = newList.Find(m => m.Id == townInfo.ProvinceId);
                if (item != null)
                {
                    item.Children = new List<AreaComponentResponse>()
                    {
                        new AreaComponentResponse()
                        {
                            Id=townInfo.CityId,
                            Name=townInfo.CityName,
                            Children=new List<AreaComponentResponse>()
                            {
                                new AreaComponentResponse()
                                {
                                    Id=townInfo.DistrictId,
                                    Name=townInfo.DistrictName,
                                    Children=new List<AreaComponentResponse>()
                                    {
                                        new AreaComponentResponse()
                                        {
                                            Id=townInfo.TownId,
                                            Name=townInfo.TownName,
                                            Leaf =true
                                        }
                                    }
                                }
                            }
                        }
                    };
                }
            }
            return newList;
        }
        #endregion
    }
}
