﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Response;
using Youlian.Domain.Response.Basics;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;

namespace Youlian.Services.Abstractions
{
    public interface IConfigService : IBaseService
    {
        #region 系统配置
        #region 获取系统配置
        /// <summary>
        /// 获取系统配置
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="configType"></param>
        /// <returns></returns>
        Task<T> GetConfig<T>(ConfigTypeEnum configType = ConfigTypeEnum.总控) where T : IBasicsConfig, new();
        #endregion

        #region 保存系统配置
        /// <summary>
        /// 保存系统配置
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="param"></param>
        /// <param name="configType"></param>
        /// <returns></returns>
        Task<Result<bool>> SaveConfig<T>(T param, ConfigTypeEnum configType = ConfigTypeEnum.总控) where T : IBasicsConfig, new();
        #endregion

        #region 保存参数配置
        /// <summary>
        /// 保存参数配置
        /// </summary>
        Task<Result<bool>> SaveConfig(string ConfigKey, ConfigTypeEnum ConfigType, string ConfigValue);
        #endregion
        #endregion

        /// <summary>
        /// 获取短信参数配置
        /// </summary>
        Task<SmsSetting> GetSmsConfig();

    }
}
