﻿using Youlian.Domain.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Youlian.Domain.Models;
using Youlian.Common.Extention;

namespace Youlian.Services.Implements
{

    /// <summary>
    /// token 管理
    /// </summary>
    public class AuthenticationDataManager
    {
        /// <summary>
        /// HTTP上下文
        /// </summary>
        private readonly IHttpContextAccessor _httpContext;

        /// <summary>
        /// 构造注入
        /// </summary> 
        public AuthenticationDataManager(IHttpContextAccessor httpContextAccessor)
        {
            _httpContext = httpContextAccessor;
        }

        /// <summary>
        /// 当前用户IP地址
        /// </summary>
        public string IPAddress => _httpContext.HttpContext.Connection.RemoteIpAddress.MapToIPv4().ToString();

        private ApiAuthenticationData _currentUser;
        /// <summary>
        /// 获取当前用户信息
        /// </summary>
        public ApiAuthenticationData CurrentUser
        {
            get
            {
                if (_currentUser == null)
                {
                    if (_httpContext?.HttpContext?.User?.Identity?.IsAuthenticated == true)
                        _currentUser = JsonExtention.Deserialize<ApiAuthenticationData>(_httpContext?.HttpContext?.User?.Claims?.FirstOrDefault(m => m.Type == System.Security.Claims.ClaimTypes.UserData)?.Value);
                }
                return _currentUser;
            }
        }
    }
}
