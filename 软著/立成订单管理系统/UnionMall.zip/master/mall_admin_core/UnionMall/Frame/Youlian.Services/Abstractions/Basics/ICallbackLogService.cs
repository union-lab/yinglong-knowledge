﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Response;
using Youlian.Domain.Response.Basics;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using System;

namespace Youlian.Services.Abstractions
{
    public interface ICallbackLogService : IBaseService
    {
        /// <summary>
        /// 获取回调记录
        /// </summary>
        /// <param name="notifyType"></param>
        /// <param name="status"></param>
        /// <param name="timeSpan"></param>
        /// <returns></returns>
        Task<List<CallbackLog>> GetLogList(CallbackNotifyTypeEnum notifyType, CallbackNotifyStatusEnum status, TimeSpan timeSpan);
        /// <summary>
        /// 添加回调记录
        /// </summary>
        /// <param name="notifyId"></param>
        /// <param name="notifyType"></param>
        /// <param name="requestUrl"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<CallbackLog> AddLog(string notifyId, CallbackNotifyTypeEnum notifyType, string requestUrl, string param);

        /// <summary>
        /// 更新回调记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<bool> UpdateStatus(CallbackLog model, CallbackNotifyStatusEnum status);
    }
}
