﻿using Dm;
using Mapster;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Request.GoodsCategory;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using static COSXML.Model.Tag.DeleteResult;

namespace Youlian.Services.Implements
{
    public class GoodsService : BaseService, IGoodsService
    {
        private readonly IRepository<Goods> _repository;
        private readonly IGoodsCategoryService _goodsCategoryService;
        private readonly IBrandService _brandService;
        private readonly IRepository<GoodsProducts> _goodsProductsRepository;
        private readonly IRepository<GoodsSkuModel> _goodsSkuModelRepository;
        private readonly IRepository<GoodsSkuModelValue> _goodsSkuModelValueRepository;

        public GoodsService(
            IRepository<Goods> repository,
            IGoodsCategoryService goodsCategoryService,
            IBrandService brandService,
            IRepository<GoodsProducts> goodsProductsRepository,
            IRepository<GoodsSkuModel> goodsSkuModelRepository,
            IRepository<GoodsSkuModelValue> goodsSkuModelValueRepository)
        {
            _repository = repository;
            _goodsCategoryService = goodsCategoryService;
            _brandService = brandService;
            _goodsProductsRepository = goodsProductsRepository;
            _goodsSkuModelRepository = goodsSkuModelRepository;
            _goodsSkuModelValueRepository = goodsSkuModelValueRepository;
        }
        public virtual async Task<PageResponse<GoodsPageResponse>> GetPageList(GoodsPageRequest param)
        {
            //
            Expression<Func<Goods, bool>> lambda = m => m.Deleted == false;
            if (!string.IsNullOrEmpty(param.GoodsName))
            {
                lambda = lambda.And(w => w.GoodsName.Contains(param.GoodsName));
            }
            if (param.DataType.HasValue)
            {
                switch (param.DataType.Value)
                {
                    case Domain.Enums.GoodsRequestDataTypeEnum.上架商品:
                        lambda = lambda.And(w => w.IsMarketable == true);
                        break;
                    case Domain.Enums.GoodsRequestDataTypeEnum.下架商品:
                        lambda = lambda.And(w => w.IsMarketable == false);
                        break;
                    case Domain.Enums.GoodsRequestDataTypeEnum.库存警告:
                        var goodsProducts = await _goodsProductsRepository.GetWhereAsync(w => w.Stock < 10);
                        var stockWarnGoodsIds = goodsProducts.Select(w => w.GoodsId).ToList();
                        lambda = lambda.And(w => stockWarnGoodsIds.Contains(w.Id));
                        break;
                }
            }
            var list = await _repository.GetPagesAsync(lambda, param);
            var newList = list.Adapt<PageResponse<GoodsPageResponse>>();
            //获取商品分类数据
            var goodsCategoryList = await _goodsCategoryService.GetGoodsCategoryList();
            //获取品牌数据
            var brandList = await _brandService.GetList();
            var goodsIds = list.Data.Select(w => w.Id).ToList();
            //根据商品Id获取对应货品列表
            var goodsProductList = await _goodsProductsRepository.GetWhereAsync(w => goodsIds.Contains(w.GoodsId));
            foreach (var item in newList.Data)
            {
                var goodsCategory = goodsCategoryList.FirstOrDefault(w => w.Id == item.GoodsCategoryId);
                var brand = brandList.FirstOrDefault(w => w.Id == item.BrandId);
                if (goodsCategory != null)
                {
                    item.GoodsCategoryName = goodsCategory.CategoryName;
                }
                if (brand != null)
                {
                    item.GoodsBrandName = brand.Name;
                }
                if (goodsProductList.Count > 0)
                {
                    item.GoodsProductList = goodsProductList.Where(w => w.GoodsId == item.Id).ToList();
                    item.DefaultGoodsProduct = item.GoodsProductList.FirstOrDefault(w => w.IsDefalut == true);
                }
                var imgList = item.Images.Split(',');
                List<Domain.Response.ImageList> goodsImageList = new List<Domain.Response.ImageList>();
                foreach (var img in imgList)
                {
                    Domain.Response.ImageList model = new Domain.Response.ImageList();
                    model.Url = img;
                    goodsImageList.Add(model);
                }
                item.ImgeArr = goodsImageList;
            }
            return newList;
        }
        public virtual async Task<List<SelectComponentResponse>> GetComponentData()
        {
            List<GoodsSkuModel> list = null;
            list = await _goodsSkuModelRepository.GetAllAsync();
            var newList = list.Select(m => new SelectComponentResponse()
            {
                value = m.Id,
                label = m.SkuName.IsNull(m.SkuName)
            }).ToList();
            return newList;
        }
        public virtual async Task<List<GoodsSkuModelValueResponse>> GetSkuModelValues(int skuId = 0)
        {
            List<GoodsSkuModelValue> list = null;
            if (skuId <= 0)
                return null;
            list = await _goodsSkuModelValueRepository.GetWhereAsync(w => w.SpecId == skuId);
            var newList = list.Adapt<List<GoodsSkuModelValueResponse>>();
            return newList;
        }


        #region 新增编辑
        public virtual async Task<Result<Goods>> AddOrEdit(GoodsRequest param)
        {
            var result = ResultHelper.Bad<Goods>(string.Empty);
            if (param.Id <= 0 && string.IsNullOrEmpty(param.GoodsName)) return result.Bad("商品名称不能为空");
            try
            {
                if (await _repository.AnyAsync(m => m.GoodsName == param.GoodsName && m.Id != param.Id))
                {
                    return result.Bad("商品名称已存在");
                }
                if (param.GoodsCategoryId <= 0)
                {
                    return result.Bad("请选择商品分类");
                }
                //拼接图集
                var images = string.Empty;
                foreach (var item in param.ImgeArr)
                {
                    images += item.Url + ',';
                }
                Goods entity;
                var isSuccess = false;
                using (var scope = new TransactionScope())
                {
                    if (param.Id > 0)
                    {
                        entity = await _repository.GetByIdAsync(param.Id);
                        if (entity == null)
                        {
                            return result.Bad("ID不存在");
                        }
                        entity = param.Adapt(entity);
                        entity.Images = images.TrimEnd(',');
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.UpdateAsync(entity) > 0;
                        if (isSuccess)
                        {
                            //添加到货品列表
                            isSuccess = AddOrEditGoodsProduct(entity, param.GoodsProductList).Result;
                        }
                    }
                    else
                    {
                        entity = param.Adapt<Goods>();
                        entity.Images = images.TrimEnd(','); ;
                        entity.AddTime = DateTime.Now;
                        entity.ModifyTime = DateTime.Now;
                        if (entity.IsMarketable)
                        {
                            entity.UpTime = DateTime.Now;
                        }
                        isSuccess = await _repository.InsertAsync(entity);
                        if (isSuccess)
                        {
                            //添加到货品列表
                            isSuccess = AddOrEditGoodsProduct(entity, param.GoodsProductList).Result;
                        }
                    }
                    if (isSuccess)
                    {
                        scope.Complete();
                    }
                }
                return isSuccess ? result.Ok(entity) : result.Bad("提交失败");

            }
            catch
            {

            }
            return result.Bad("提交失败");
        }
        #endregion

        #region 商品货品列表添加编辑
        public virtual async Task<bool> AddOrEditGoodsProduct(Goods goods, List<GoodsProductList> productList)
        {
            bool isSuccess = false;
            using (var scope = new TransactionScope())
            {
                //根据商品ID获取对应货品列表
                var orginValueList = await _goodsProductsRepository.GetWhereAsync(w => w.GoodsId == goods.Id);
                //找出不同id的进行删除
                var srGorup = orginValueList.Where(x => !productList.Any(a => x.Id == a.Id)).ToList();
                if (srGorup.Any())
                {
                    //删除
                    var Ids = srGorup.Select(w => w.Id).ToArray();
                    isSuccess = await _goodsProductsRepository.DeleteAsync(Ids) > 0;
                }
                else
                {
                    isSuccess = true;
                }
                if (isSuccess)
                {
                    List<GoodsProducts> addModelList = new List<GoodsProducts>();
                    List<GoodsProducts> updateModelList = new List<GoodsProducts>();
                    foreach (var item in productList)
                    {
                        if (item.Id == 0)
                        {
                            //新增
                            GoodsProducts addmodel = new GoodsProducts()
                            {
                                GoodsId = goods.Id,
                                BarCode = goods.BarCode,
                                Sn = item.Sn,
                                Price = item.Price,
                                CostPrice = item.CostPrice,
                                MktPrice = item.MktPrice,
                                IsMarketable = true,
                                Weight = item.Weight,
                                Stock = item.Stock,
                                FreezeStock = 0,
                                SkuModelValue = item.SkuModelValue,
                                IsDefalut = item.IsDefalut,
                                Image = item.Image,
                                Deleted = false,
                                AddTime = DateTime.Now,
                                ModifyTime = DateTime.Now
                            };
                            addModelList.Add(addmodel);
                        }
                        else
                        {
                            //修改
                            GoodsProducts updatemodel = new GoodsProducts()
                            {
                                Id=item.Id,
                                GoodsId=goods.Id,
                                BarCode = goods.BarCode,
                                Sn = item.Sn,
                                Price = item.Price,
                                CostPrice = item.CostPrice,
                                MktPrice = item.MktPrice,
                                IsMarketable = true,
                                Weight = item.Weight,
                                Stock = item.Stock,
                                FreezeStock = 0,
                                SkuModelValue = item.SkuModelValue,
                                IsDefalut = item.IsDefalut,
                                Image = item.Image,
                                Deleted = false,
                                ModifyTime = DateTime.Now
                            };
                            updateModelList.Add(updatemodel);
                        }
                    }
                    if (addModelList.Count > 0)
                    {
                        isSuccess = await _goodsProductsRepository.InsertAsync(addModelList) > 0;
                    }
                    if (isSuccess && updateModelList.Count > 0)
                    {
                        isSuccess = await _goodsProductsRepository.UpdateAsync(updateModelList) > 0;
                    }
                }
                if (isSuccess)
                {
                    scope.Complete();
                }
                return isSuccess;
            }
        }
        #endregion
    }
}
