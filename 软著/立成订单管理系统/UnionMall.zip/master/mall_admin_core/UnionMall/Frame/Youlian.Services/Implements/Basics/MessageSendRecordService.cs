﻿using Mapster;
using Youlian.Domain.Constant;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Response;
using Youlian.Domain.Response.Basics;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    public class MessageSendRecordService : BaseService, IMessageSendRecordService
    {
        private readonly IRepository<MessageSendRecord> _repository;
        public MessageSendRecordService(IRepository<MessageSendRecord> repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// 添加记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<bool> Add(MessageSendRecord model)
        {
            return await _repository.InsertAsync(model);
        }

        /// <summary>
        /// 判断是否存在
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<bool> Exist(MessageTypeEnum type, string messageId)
        {
            return await _repository.AnyAsync(m => m.Type == type && m.MessageId == messageId);
        }
    }
}
