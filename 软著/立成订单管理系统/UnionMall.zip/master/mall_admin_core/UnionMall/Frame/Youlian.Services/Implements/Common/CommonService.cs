﻿using Youlian.Common;
using Youlian.Domain.Enums;
using Youlian.Services.Abstractions;
using Mapster;
using System.Threading.Tasks;
using System.Collections.Generic;
using Youlian.Common.Extention;
using System;
using Youlian.Domain.Models.Basics;
using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;
using Aliyun.OSS;
using Microsoft.AspNetCore.WebUtilities;
using System.IO;
using Youlian.Common.Cache;
using Youlian.Common.Helpers;
using Youlian.Domain.Response;
using Microsoft.Extensions.Configuration;
using Youlian.SDK.Weixin.Work;

namespace Youlian.Services.Implements
{
    public class CommonService : ICommonService
    {
        private readonly ICacheManager _cache;
        private readonly IHttpContextAccessor _httpContext;
        private readonly IConfigService _configService;
        private readonly IConfiguration _configuration;
        public CommonService(ICacheManager cache, IHttpContextAccessor httpContext, IConfigService configService, IConfiguration configuration)
        {
            _cache = cache;
            _httpContext = httpContext;
            _configService = configService;
            _configuration = configuration;
        }

        /// <summary>
        /// 获取枚举值
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual Result<List<Dictionary<string, object>>> GetEnumValues(string type)
        {
            var list = new List<Dictionary<string, object>>();
            switch (type)
            {
                case "Enum.UserType": list = typeof(UserTypeEnum).GetValues(); break;
                case "Enum.ActionPermission": list = typeof(ActionEnum).GetValues(); break;
                case "Enum.SysLogType": list = typeof(SysLogTypeEnum).GetValues(); break;
                case "Enum.SystemClient": list = typeof(SystemClientEnum).GetValues(); break;
            }

            return ResultHelper.Ok(list);
        }


        #region 按配置上传腾讯云或阿里云
        /// <summary>
        /// 按配置上传腾讯云或阿里云,files为空则使用流式传输上传，不为空使用缓冲的模型绑定上传
        /// </summary>
        /// <param name="files"></param>
        /// <returns></returns>
        public async Task<Result<List<string>>> YunUpload(string basePath = "default", Dictionary<string, Stream> files = null)
        {
            var type = _configuration["Oss:Type"];
            if (type == "0")
            {
                return ResultHelper.Bad<List<string>>("暂不支持本地上传");
            }
            if (type == "1")
            {
                return await AliYunUpload(basePath);
            }
            if (type == "2")
            {
                return await TencentYunUpload(basePath, files);
            }
            return ResultHelper.Bad<List<string>>("上传配置错误");
        }

        #region 上传阿里云OSS
        /// <summary>
        /// 上传阿里云OSS
        /// </summary>
        /// <returns></returns>
        private async Task<Result<List<string>>> AliYunUpload(string basePath)
        {
            var result = ResultHelper.Bad<List<string>>("");
            try
            {
                var request = _httpContext.HttpContext.Request;

                if (!request.HasFormContentType || !MediaTypeHeaderValue.TryParse(request.ContentType, out var mediaTypeHeader) || string.IsNullOrEmpty(mediaTypeHeader.Boundary.Value))
                {
                    return result.Bad("上传文件不能为空");
                }

                string Endpoint = _configuration["Oss:AliYun:Endpoint"];
                string AccessKeyID = _configuration["Oss:AliYun:AccessKeyID"];
                string AccessKeySecret = _configuration["Oss:AliYun:AccessKeySecret"];
                string Host = _configuration["Oss:AliYun:Host"];
                string BucketName = _configuration["Oss:AliYun:BucketName"];

                List<string> fs = new List<string>();
                var write = new OssClient(Endpoint, AccessKeyID, AccessKeySecret);
                var read = new OssClient(Endpoint, AccessKeyID, AccessKeySecret);

                var reader = new MultipartReader(mediaTypeHeader.Boundary.Value, request.Body);
                var section = await reader.ReadNextSectionAsync();

                while (section != null)
                {
                    var hasContentDispositionHeader = ContentDispositionHeaderValue.TryParse(section.ContentDisposition,
                        out var contentDisposition);

                    if (hasContentDispositionHeader && contentDisposition.DispositionType.Equals("form-data") &&
                        !string.IsNullOrEmpty(contentDisposition.FileName.Value))
                    {
                        string fileInfo = "upload/" + basePath + "/" + DateTime.Today.ToString("yyyy/MM/dd") + "/" + SnowflakeHelper.CreateUniqueId + contentDisposition.FileName.Value.Substring(contentDisposition.FileName.Value.LastIndexOf('.'));

                        using (var ms = new MemoryStream())
                        {
                            await section.Body.CopyToAsync(ms);
                            ms.Position = 0;
                            write.PutObject(BucketName, fileInfo, ms);
                        }
                        DateTime exporation = DateTime.Now.AddYears(10);
                        var url = read.GeneratePresignedUri(BucketName, fileInfo, exporation);
                        string urlString = url.ToString();
                        fs.Add(urlString);
                    }
                    section = await reader.ReadNextSectionAsync();
                }
                return ResultHelper.Ok(fs);
            }
            catch (Exception ex)
            {
                return result.Bad(ex.Message);
            }
        }
        #endregion

        #region 上传腾讯云COS
        /// <summary>
        /// 上传腾讯云COS
        /// </summary>
        /// <returns></returns>
        private async Task<Result<List<string>>> TencentYunUpload(string basePath)
        {
            var result = ResultHelper.Bad<List<string>>("");
            try
            {
                var request = _httpContext.HttpContext.Request;

                if (!request.HasFormContentType || !MediaTypeHeaderValue.TryParse(request.ContentType, out var mediaTypeHeader) || string.IsNullOrEmpty(mediaTypeHeader.Boundary.Value))
                {
                    return result.Bad("上传文件不能为空");
                }

                string secretId = _configuration["Oss:TencentYun:SecretId"];
                string secretKey = _configuration["Oss:TencentYun:SecretKey"];
                string region = _configuration["Oss:TencentYun:Region"];
                string bucket = _configuration["Oss:TencentYun:BucketName"];

                List<string> fs = new List<string>();

                var reader = new MultipartReader(mediaTypeHeader.Boundary.Value, request.Body);
                var section = await reader.ReadNextSectionAsync();

                while (section != null)
                {
                    var hasContentDispositionHeader = ContentDispositionHeaderValue.TryParse(section.ContentDisposition,
                        out var contentDisposition);

                    if (hasContentDispositionHeader && contentDisposition.DispositionType.Equals("form-data") &&
                        !string.IsNullOrEmpty(contentDisposition.FileName.Value))
                    {
                        string fileInfo = "upload/" + basePath + "/" + DateTime.Today.ToString("yyyy/MM/dd") + "/" + SnowflakeHelper.CreateUniqueId + contentDisposition.FileName.Value.Substring(contentDisposition.FileName.Value.LastIndexOf('.'));
                        using (var ms = new MemoryStream())
                        {
                            await section.Body.CopyToAsync(ms);
                            ms.Position = 0;
                            var putResult = TencentCosHelper.PutObjectStream(secretId, secretKey, region, bucket, fileInfo, ms);
                            fs.Add(putResult);
                        }
                    }
                    section = await reader.ReadNextSectionAsync();
                }
                return ResultHelper.Ok(fs);
            }
            catch (Exception ex)
            {
                return result.Bad(ex.Message);
            }
        }

        /// <summary>
        /// 上传腾讯云COS
        /// </summary>
        /// <param name="files"></param>
        /// <returns></returns>
        private async Task<Result<List<string>>> TencentYunUpload(string basePath, ICollection<IFormFile> files)
        {
            if (files == null) return await TencentYunUpload(basePath);
            var result = ResultHelper.Bad<List<string>>("");
            try
            {
                string secretId = _configuration["Oss:TencentYun:SecretId"];
                string secretKey = _configuration["Oss:TencentYun:SecretKey"];
                string region = _configuration["Oss:TencentYun:Region"];
                string bucket = _configuration["Oss:TencentYun:BucketName"];

                List<string> fs = new List<string>();

                foreach (var item in files)
                {
                    string fileInfo = "upload/" + basePath + "/" + DateTime.Today.ToString("yyyy/MM/dd") + "/" + SnowflakeHelper.CreateUniqueId + item.FileName.Substring(item.FileName.LastIndexOf('.'));
                    using (var ms = new MemoryStream())
                    {
                        await item.CopyToAsync(ms);
                        ms.Position = 0;
                        var putResult = TencentCosHelper.PutObjectStream(secretId, secretKey, region, bucket, fileInfo, ms);
                        fs.Add(putResult);
                    }
                }

                return ResultHelper.Ok(fs);
            }
            catch (Exception ex)
            {
                return result.Bad(ex.Message);
            }
        }
        private async Task<Result<List<string>>> TencentYunUpload(string basePath, Dictionary<string, Stream> files)
        {
            if (files == null) return await TencentYunUpload(basePath);
            var result = ResultHelper.Bad<List<string>>("");
            try
            {
                string secretId = _configuration["Oss:TencentYun:SecretId"];
                string secretKey = _configuration["Oss:TencentYun:SecretKey"];
                string region = _configuration["Oss:TencentYun:Region"];
                string bucket = _configuration["Oss:TencentYun:BucketName"];

                List<string> fs = new List<string>();

                foreach (var item in files)
                {
                    string fileInfo = "upload/" + basePath + "/" + DateTime.Today.ToString("yyyy/MM/dd") + "/" + SnowflakeHelper.CreateUniqueId + item.Key.Substring(item.Key.LastIndexOf('.'));
                    using (var ms = item.Value)
                    {
                        ms.Position = 0;
                        var putResult = TencentCosHelper.PutObjectStream(secretId, secretKey, region, bucket, fileInfo, ms);
                        fs.Add(putResult);
                    }
                }

                return ResultHelper.Ok(fs);
            }
            catch (Exception ex)
            {
                return result.Bad(ex.Message);
            }
        }
        #endregion

        #region 获取上传配置
        public dynamic GetOssConfig()
        {
            string region = _configuration["Oss:TencentYun:Region"];
            string bucket = _configuration["Oss:TencentYun:BucketName"];
            var data = new
            {
                Region = region,
                Bucket = bucket,
                Upload = $"upload/{DateTime.Today.Year}/{DateTime.Today.Month}/{DateTime.Today.Day}/",
            };
            return data;
        }
        #endregion

        #region 获取Cos临时密钥
        public Dictionary<string, object> GetCosCredential()
        {
            string secretId = _configuration["Oss:TencentYun:SecretId"];
            string secretKey = _configuration["Oss:TencentYun:SecretKey"];
            string region = _configuration["Oss:TencentYun:Region"];
            string bucket = _configuration["Oss:TencentYun:BucketName"];
            var result = TencentCosHelper.GetCredential(secretId, secretKey, region, bucket);
            return result;
        }
        #endregion

        #region 获取WxJsConfig
        /// <summary>
        /// 获取WxJsConfig
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public Result<WxJsSdkConfigReponse> GetWxJsConfig(int appId, string url)
        {
            var noncestr = RandomHelper.GetRandomString(16);
            var timestamp = DateTime.Now.ToUnixTimeStamp();
            var config = new WxJsSdkConfigReponse
            {
                Bate = true,
                Debug = true,
                AppId = WorkWeixinApi.CorpId,
                NonceStr = noncestr,
                Timestamp = timestamp,
                Signature = WeixinClientApi.GetSignature(appId, noncestr, timestamp, url)
            };
            return ResultHelper.Ok(config);
        }
        #endregion
        #endregion
    }
}