﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Request;
using Youlian.Domain.Request.GoodsCategory;
using Youlian.Domain.Request.GoodsComment;
using Youlian.Domain.Response;

namespace Youlian.Services.Abstractions
{
    public interface IGoodsCommentService : IBaseService
    {
        Task<PageResponse<GoodsCommentPageResponse>> GetResponseList(GoodsCommentPageRequest param);
        Task<Result<string>> UpdataStatus(UpdataGoodsCommentStatusRequest param);
        Task<Result<string>> EditSellerContent(UpdataGoodsCommentSellerContentRequest param);
        Task<Result<int>> Deletes(int ids);
    }
}
