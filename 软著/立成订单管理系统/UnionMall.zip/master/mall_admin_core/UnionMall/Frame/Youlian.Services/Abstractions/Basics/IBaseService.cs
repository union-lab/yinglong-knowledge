﻿using Youlian.Domain.Entities;
using Youlian.Domain.Models;
using Youlian.Repository;

namespace Youlian.Services.Abstractions
{
    public interface IBaseService
    {
        ApiAuthenticationData CurrentUser { get; }
    }

    public interface IBaseService<TEntity> : IBaseService where TEntity : BaseEntity, new()
    {
        IRepository<TEntity> Repository { get; }
    }
}
