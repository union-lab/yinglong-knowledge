﻿using Mapster;
using Org.BouncyCastle.Crypto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Response;
using Youlian.Domain.Response.MallSetting;
using Youlian.Repository;
using Youlian.Services.Abstractions;

namespace Youlian.Services.Implements
{
    public class ShopService : BaseService, IShopService
    {
        private readonly IRepository<Shop> _repository;
        private readonly IAreaService _areaService;
        public ShopService(IRepository<Shop> repository
            , IAreaService areaService)
        {
            _repository = repository;
            _areaService = areaService;
        }
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<ShopPageResponse>> GetResponseList(ShopPageRequest param)
        {
            Expression<Func<Shop, bool>> lambda = m => true;
            if (!string.IsNullOrEmpty(param.ShopName))
                lambda = lambda.And(w => w.ShopName.Contains(param.ShopName));
            var list = await _repository.GetPagesAsync(lambda, param);
            var newList = list.Adapt<PageResponse<ShopPageResponse>>();
            return newList;
        }
        public virtual async Task<Result<Shop>> AddOrEdit(ShopRequest param)
        {
            var result = ResultHelper.Bad<Shop>(string.Empty);
            if (param.Id <= 0 && string.IsNullOrEmpty(param.ShopName)) return result.Bad("店铺名称不能为空");
            try
            {
                var townInfo = await _areaService.GetTownInfo(param.TownId);
                if (townInfo == null)
                {
                    if (param.DistrictId <= 0) return result.Bad("镇/街道不能为空");
                    var districtInfo = await _areaService.GetDistrictInfo(param.DistrictId);
                    if (districtInfo == null)
                    {
                        if (param.CityId <= 0 || string.IsNullOrEmpty(param.DistrictName)) return result.Bad("城市ID为空或者区县名称为空");
                        var cityInfo = await _areaService.GetCityInfo(param.CityId);
                        if (cityInfo == null)
                            return result.Bad($"行政区划{param.TownName}不存在,请联系管理员");
                        townInfo = new Domain.Models.Basics.TownModel()
                        {
                            ProvinceId = cityInfo.ProvinceId,
                            ProvinceName = cityInfo.ProvinceName,
                            CityId = cityInfo.CityId,
                            CityName = cityInfo.CityName,
                            DistrictId = param.DistrictId,
                            DistrictName = param.DistrictName,
                            TownId = param.TownId,
                            TownName = param.TownName,
                        };
                    }
                    else
                    {
                        townInfo = new Domain.Models.Basics.TownModel()
                        {
                            ProvinceId = districtInfo.ProvinceId,
                            ProvinceName = districtInfo.ProvinceName,
                            CityId = districtInfo.CityId,
                            CityName = districtInfo.CityName,
                            DistrictId = districtInfo.DistrictId,
                            DistrictName = districtInfo.DistrictName,
                            TownId = param.TownId,
                            TownName = param.TownName,
                        };
                    }
                }
                Shop entity;
                var isSuccess = false;
                using (var scope = new TransactionScope())
                {
                    if (param.Id > 0)
                    {
                        entity = await _repository.GetByIdAsync(param.Id);
                        if (entity == null)
                        {
                            return result.Bad("ID不存在");
                        }
                        entity = param.Adapt(entity);
                        entity.TownId = townInfo.TownId;
                        entity.TownName = townInfo.TownName;
                        entity.DistrictId = townInfo.DistrictId;
                        entity.DistrictName = townInfo.DistrictName;
                        entity.CityId = townInfo.CityId;
                        entity.CityName = townInfo.CityName;
                        entity.ProvinceId = townInfo.ProvinceId;
                        entity.ProvinceName = townInfo.ProvinceName;
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.UpdateAsync(entity) > 0;
                    }
                    else
                    {
                        entity = param.Adapt<Shop>();
                        entity.AddTime = DateTime.Now;
                        entity.ModifyTime = DateTime.Now;
                        entity.TownId = townInfo.TownId;
                        entity.TownName = townInfo.TownName;
                        entity.DistrictId = townInfo.DistrictId;
                        entity.DistrictName = townInfo.DistrictName;
                        entity.CityId = townInfo.CityId;
                        entity.CityName = townInfo.CityName;
                        entity.ProvinceId = townInfo.ProvinceId;
                        entity.ProvinceName = townInfo.ProvinceName;
                        isSuccess = await _repository.InsertAsync(entity);
                    }
                    if (isSuccess)
                    {
                        scope.Complete();
                    }
                }
                return isSuccess ? result.Ok(entity) : result.Bad("提交失败");

            }
            catch
            {

            }
            return result.Bad("提交失败");
        }

        public virtual async Task<Result<int>> Delete(int id)
        {
            var isSuccess = false;
            try
            {
                isSuccess = await _repository.DeleteAsync(id) > 0;
            }
            catch (Exception e)
            {
                isSuccess = false;
            }
            return isSuccess ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }

    }
}
