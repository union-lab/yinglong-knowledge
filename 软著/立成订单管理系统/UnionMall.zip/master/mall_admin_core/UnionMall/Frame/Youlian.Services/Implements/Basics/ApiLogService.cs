﻿using Mapster;
using Youlian.Domain.Constant;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Response;
using Youlian.Domain.Response.Basics;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    public class ApiLogService : BaseService, IApiLogService
    {
        private readonly IRepository<ApiLog> _repository;
        public ApiLogService(IRepository<ApiLog> repository)
        {
            _repository = repository;
        }
    }
}
