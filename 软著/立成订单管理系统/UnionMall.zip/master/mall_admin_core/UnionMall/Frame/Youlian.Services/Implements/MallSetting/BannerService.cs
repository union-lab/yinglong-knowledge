﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request.Brand;
using Youlian.Domain.Request;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using Youlian.Common.Extention;
using Mapster;
using Youlian.Domain.Response.MallSetting;

namespace Youlian.Services.Implements
{
    public class BannerService : BaseService, IBannerService
    {
        private readonly IRepository<Banner> _repository;
        public BannerService(IRepository<Banner> repository)
        {
            _repository = repository;
        }
        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public async Task<PageResponse<BannerPageResponse>> GetPageList(BannerPageRequest param)
        {
            Expression<Func<Banner, bool>> lambda = n => true;
            if (param.IsShow.HasValue)
            {
                lambda = lambda.And(n => n.IsShow == param.IsShow);
            }
            var pageList = await _repository.GetPagesAsync(lambda, param);
            var result = pageList.Adapt<PageResponse<BannerPageResponse>>();
            return result;
        }
        #endregion

        #region 新增编辑
        public virtual async Task<Result<Banner>> AddOrEdit(BannerRequest param)
        {
            var result = ResultHelper.Bad<Banner>(string.Empty);
            if (param.Id <= 0 && string.IsNullOrEmpty(param.PageUrl)) return result.Bad("跳转地址不能为空");
            try
            {
                Banner entity;
                var isSuccess = false;
                using (var scope = new TransactionScope())
                {
                    if (param.Id > 0)
                    {
                        entity = await _repository.GetByIdAsync(param.Id);
                        if (entity == null)
                        {
                            return result.Bad("ID不存在");
                        }
                        entity = param.Adapt(entity);
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.UpdateAsync(entity) > 0;
                    }
                    else
                    {
                        entity = param.Adapt<Banner>();
                        entity.AddTime = DateTime.Now;
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.InsertAsync(entity);
                    }
                    if (isSuccess)
                    {
                        scope.Complete();
                    }
                }
                return isSuccess ? result.Ok(entity) : result.Bad("提交失败");

            }
            catch
            {

            }
            return result.Bad("提交失败");
        }
        #endregion

        #region 更新是否开启
        public async Task<Result<string>> UpdataIsShow(BannerRequest param)
        {
            var result = ResultHelper.Bad<string>(string.Empty);
            var model = await _repository.GetByIdAsync(param.Id);
            if (model == null)
            {
                return result.Bad("找不到对应消息");
            }
            model.IsShow = param.IsShow.Value;
            model.ModifyTime = DateTime.Now;
            return await _repository.UpdateAsync(model) > 0 ? result.Ok("更改成功") : result.Bad("更改失败");
        }
        #endregion
        #region 删除记录
        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Deletes(List<int> ids)
        {
            var isSuccess = false;
            try
            {
                isSuccess = await _repository.DeleteAsync(ids.ToArray()) > 0;
            }
            catch (Exception e)
            {
                isSuccess = false;
            }
            return isSuccess ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion
    }
}
