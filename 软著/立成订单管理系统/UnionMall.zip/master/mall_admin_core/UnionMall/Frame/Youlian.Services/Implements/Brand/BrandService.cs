﻿using Mapster;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Request.Brand;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;

namespace Youlian.Services.Implements
{
    public class BrandService : BaseService, IBrandService
    {
        private readonly IRepository<Brand> _repository;
        public BrandService(IRepository<Brand> repository)
        {
            _repository = repository;
        }

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public async Task<PageResponse<Brand>> GetPageList(BrandPageRuquest param)
        {
            Expression<Func<Brand, bool>> lambda = n => true;
            if (!string.IsNullOrEmpty(param.Name))
            {
                lambda = lambda.And(n => n.Name.Contains(param.Name));
            }

            if (param.IsShow.HasValue)
            {
                lambda = lambda.And(n => n.IsShow == param.IsShow);
            }

            var pageList = await _repository.GetPagesAsync(lambda, param);
            return pageList;
        }
        #endregion

        #region 新增编辑
        public virtual async Task<Result<Brand>> AddOrEdit(BrandRequest param)
        {
            var result = ResultHelper.Bad<Brand>(string.Empty);
            if (param.Id <= 0 && string.IsNullOrEmpty(param.Name)) return result.Bad("品牌名称不能为空");
            try
            {
                if (await _repository.AnyAsync(m => m.Name == param.Name && m.Id != param.Id))
                {
                    return result.Bad("品牌名称已存在");
                }
                Brand entity;
                var isSuccess = false;
                using (var scope = new TransactionScope())
                {
                    if (param.Id > 0)
                    {
                        entity = await _repository.GetByIdAsync(param.Id);
                        if (entity == null)
                        {
                            return result.Bad("ID不存在");
                        }
                        entity = param.Adapt(entity);
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.UpdateAsync(entity) > 0;
                    }
                    else
                    {
                        entity = param.Adapt<Brand>();
                        entity.AddTime = DateTime.Now;
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.InsertAsync(entity);
                    }
                    if (isSuccess)
                    {
                        scope.Complete();
                    }
                }
                return isSuccess ? result.Ok(entity) : result.Bad("提交失败");

            }
            catch
            {

            }
            return result.Bad("提交失败");
        }
        #endregion

        #region 更新是否开启
        public async Task<Result<string>> UpdataIsShow(BrandRequest param)
        {
            var result = ResultHelper.Bad<string>(string.Empty);
            //所有问题只能展示一个
            var model = await _repository.GetByIdAsync(param.Id);
            if (model == null)
            {
                return result.Bad("找不到对应消息");
            }
            model.IsShow = param.IsShow.Value;
            model.ModifyTime = DateTime.Now;
            return await _repository.UpdateAsync(model) > 0 ? result.Ok("更改成功") : result.Bad("更改失败");
        }
        #endregion
        #region 删除记录
        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Deletes(List<int> ids)
        {
            var isSuccess = false;
            try
            {
                isSuccess = await _repository.DeleteAsync(ids.ToArray()) > 0;
            }
            catch (Exception e)
            {
                isSuccess = false;
            }
            return isSuccess ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion

        #region 获取所有品牌数据
        public virtual async Task<List<Brand>> GetList()
        {
            Expression<Func<Brand, bool>> lambda = n => n.IsShow==true;
            return await _repository.GetWhereAsync(lambda);
        }
        #endregion
        #region 获取区域组件数据
        /// <summary>
        /// 获取区域组件数据
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<List<SelectComponentResponse>> GetComponentData()
        {
            List<Brand> list = null;
            list = await _repository.GetWhereAsync(w => w.IsShow ==true);
            var newList = list.Select(m => new SelectComponentResponse()
            {
                value = m.Id,
                label = m.Name.IsNull(m.Name)
            }).ToList();
            return newList;
        }
        #endregion
    }
}
