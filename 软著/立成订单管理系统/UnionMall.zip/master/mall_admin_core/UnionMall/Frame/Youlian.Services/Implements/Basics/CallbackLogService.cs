﻿using Mapster;
using Youlian.Domain.Constant;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Response;
using Youlian.Domain.Response.Basics;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    public class CallbackLogService : BaseService, ICallbackLogService
    {
        private readonly IRepository<CallbackLog> _repository;
        public CallbackLogService(IRepository<CallbackLog> repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// 获取回调记录
        /// </summary>
        /// <param name="notifyType"></param>
        /// <param name="status"></param>
        /// <param name="timeSpan"></param>
        /// <returns></returns>
        public virtual async Task<List<CallbackLog>> GetLogList(CallbackNotifyTypeEnum notifyType, CallbackNotifyStatusEnum status,TimeSpan timeSpan)
        {
            var time = DateTime.Now.Add(-timeSpan);
            var list = await _repository.GetWhereAsync(m => m.NotifyType == notifyType && m.Status == status && m.AddTime >= time);
            return list;
        }

        /// <summary>
        /// 添加回调记录
        /// </summary>
        /// <param name="notifyId"></param>
        /// <param name="notifyType"></param>
        /// <param name="requestUrl"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<CallbackLog> AddLog(string notifyId, CallbackNotifyTypeEnum notifyType, string requestUrl, string param)
        {
            try
            {
                var model = new CallbackLog()
                {
                    NotifyId = notifyId,
                    NotifyType = notifyType,
                    RequestUrl = requestUrl,
                    Param = param
                };
                await _repository.InsertAsync(model);
                return model;
            }
            catch 
            {
                return null;   
            }
        }

        /// <summary>
        /// 更新回调记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public virtual async Task<bool> UpdateStatus(CallbackLog model, CallbackNotifyStatusEnum status)
        {
            model.Status = status;
            return await _repository.UpdateAsync(model, p => p.Status) > 0;
        }
    }
}
