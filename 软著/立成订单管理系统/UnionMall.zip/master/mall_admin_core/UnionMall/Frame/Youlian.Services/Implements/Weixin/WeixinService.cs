﻿using Youlian.Common.Extention;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Request;
using Youlian.Common.Cache;
using Youlian.Domain.Response;
using Microsoft.AspNetCore.Http;
using Youlian.SDK.Weixin.Work.Models;
using Microsoft.Extensions.Logging;
using Youlian.SDK.Weixin.Work;
using Mapster;
using Youlian.SDK;

namespace Youlian.Services.Implements
{
    /// <summary>
    /// 企业微信服务
    /// </summary>
    public class WeixinService : BaseService, IWeixinService
    {
        private readonly ILogger<WorkWeixinService> _logger;
        private readonly ICacheManager _cache;
        private readonly IHttpContextAccessor _contextAccessor;

        public WeixinService(ILogger<WorkWeixinService> logger,
            ICacheManager cache, 
            IHttpContextAccessor contextAccessor)
        {
            _logger = logger;
            _cache = cache;
            _contextAccessor = contextAccessor;
        }

        /// <summary>
        /// 授权回调中心
        /// </summary>
        public Result<string> AuthorizeCallback(WeixinAuthorizeCallbackRequest param)
        {
            string key = param.State;
            var redirectUri = _cache.GetString(key);
            if (redirectUri == null) return ResultHelper.Bad<string>("授权失败:State Error");
            redirectUri += $"{(redirectUri.Contains("?") ? "&" : "?")}code={param.Code}&state={param.State}";

            var userInfo = SDK.Weixin.MP.MPApi.GetSubscribeUserInfoByCodeAsync(param.Code);
            if (userInfo==null)
            {
                return ResultHelper.Bad<string>("授权失败:Code Error");
            }
            return ResultHelper.Ok(redirectUri);
        }
        /// <summary>
        /// 获取授权信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual Result<WeixinOauth2AuthorizeResponse> GetAuthorizeInfo(WeixinOauth2AuthorizeRequest param)
        {
            var result = new WeixinOauth2AuthorizeResponse();
            string key = string.Format(CacheKeys.CSRFtoken, Guid.NewGuid().ToString());
            _cache.SetString(key, param.RedirectUri, TimeSpan.FromSeconds(60 * 5));
            result.AuthorizeUrl = SDK.Weixin.MP.MPApi.GetOauth2Authorize(param.NeedConfirm, param.CallbackUrl, key);
            return ResultHelper.Ok(result);
        }
    }
}
