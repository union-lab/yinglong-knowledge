﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Request;
using Youlian.Domain.Response;

namespace Youlian.Services.Abstractions
{
    /// <summary>
    /// 行政区划服务
    /// </summary>
    public interface IAreaService : IBaseService
    {
        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Area> GetInfo(int id, bool fromCache = false);
        #endregion

        #region 获取镇/街道信息
        /// <summary>
        /// 获取镇/街道信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<TownModel> GetTownInfo(int id);
        #endregion

        #region 获取区县信息
        /// <summary>
        /// 获取区县信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<DistrictModel> GetDistrictInfo(int id);
        #endregion

        #region 获取城市信息
        /// <summary>
        /// 获取城市信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<CityModel> GetCityInfo(int id);
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<PageResponse<Area>> GetPageList(AreaPageRequest param);

        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<PageResponse<AreaPageResponse>> GetResponseList(AreaPageRequest param);
        #endregion

        #region 获取区域组件数据
        /// <summary>
        /// 获取区域组件数据
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<List<AreaComponentResponse>> GetComponentData(AreaComponentRequest param, bool fromCache = false);
        #endregion
    }
}