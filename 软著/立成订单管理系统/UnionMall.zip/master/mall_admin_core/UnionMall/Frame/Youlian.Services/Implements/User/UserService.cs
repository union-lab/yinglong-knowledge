﻿using Youlian.Domain.Models;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Services.Abstractions;
using System;
using System.Threading.Tasks;
using Youlian.Repository;
using Youlian.Domain.Request.User;
using Microsoft.AspNetCore.Http;
using System.IO;
using Youlian.Domain.Models.User;
using log4net;
using System.Linq.Expressions;
using Youlian.Domain.Response;
using Youlian.Domain.Models.Basics;
using Youlian.Common.Cache;
using Youlian.Common.Helpers;
using Youlian.Common.Extention;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using TencentCloud.Cme.V20191029.Models;
using Mapster;

namespace Youlian.Services.Implements
{
    /// <summary>
    /// 用户服务
    /// </summary>
    public class UserService : BaseService<User>, IUserService
    {
        private readonly ILogger<IUserService> _log;
        private readonly ICacheManager _cache;
        private readonly LockHelper _lockHelper;
        private readonly IRepository<User> _repository;
        private readonly IEncryptionService _encryptionService;
        private readonly ISmsService _smsService;
        private readonly ISysLogService _sysLogService;

        public UserService(ILogger<IUserService> log,
            ICacheManager cache,
            LockHelper lockHelper,
            IRepository<User> repository,
            IEncryptionService encryptionService,
            ISmsService smsService,
            ISysLogService sysLogService)
            :base(repository)
        {
            _log = log;
            _cache = cache;
            _lockHelper = lockHelper;
            _repository = repository;
            _encryptionService = encryptionService;
            _smsService = smsService;
            _sysLogService = sysLogService;
        }

        #region 获取用户信息
        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public virtual async Task<User> GetInfoByUserName(string userName, UserTypeEnum userType)
        {
            return await _repository.GetFirstAsync(m => m.UserName == userName && m.UserType == userType);
        }

        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public virtual async Task<User> GetInfo(int userId, bool fromCache = false)
        {
            if (fromCache)
            {
                var key = string.Format(CacheKeys.UserInfo, userId);
                var result = _cache.Get<User>(key);
                if (result == null)
                {
                    result = await _repository.GetFirstAsync(m => m.Id == userId);
                    _cache.Set(key, result, TimeSpan.FromDays(1));
                }
                return result;
            }
            return await _repository.GetFirstAsync(m => m.Id == userId);
        }

        /// <summary>
        /// 清除缓存
        /// </summary>
        /// <param name="userId"></param>
        public virtual void ClearCache(int userId)
        {
            var key = string.Format(CacheKeys.UserInfo, userId);
            _cache.Remove(key);
        }
        #endregion

        #region 获取用户列表
        /// <summary>
        /// 获取用户分页列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<List<User>> GetListByIds(List<int> ids)
        {
            var list = await _repository.GetWhereAsync(m => ids.Contains(m.Id));
            return list;
        }

        /// <summary>
        /// 获取用户分页列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<User>> GetUserPageList(UserPageRequest param)
        {
            Expression<Func<User, bool>> lambda = m => true;
            if (param.StartTime.HasValue) lambda = lambda.And(m => m.AddTime >= param.StartTime);
            if (param.EndTime.HasValue) lambda = lambda.And(m => m.AddTime <= param.EndTime);
            var list = await _repository.GetPagesAsync(lambda, param);
            return list;
        }
        #endregion

        #region 验证用户名
        /// <summary>
        /// 验证用户名
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="userType"></param>
        /// <returns></returns>
        public virtual async Task<Result<string>> CheckUserName(string userName, UserTypeEnum userType)
        {
            if (string.IsNullOrEmpty(userName))
            {
                return ResultHelper.Bad<string>("用户名不能为空");
            }
            var exists = await _repository.AnyAsync(a => a.UserName == userName && a.UserType == userType);
            if (!exists)
            {
                return ResultHelper.Ok("可以注册");
            }
            else
            {
                return ResultHelper.Bad<string>("当前账户已注册，请更换信息");
            }
        }
        #endregion

        #region 登录验证
        /// <summary>
        /// 登录验证
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<User>> Login(LoginRequest param)
        {
            var result = ResultHelper.Bad<User>("");
            if (param.UserType == UserTypeEnum.管理员)
            {
                if (param.Key?.Length != 19)
                {
                    return result.Bad("请求信息有误");
                }
                var obj = _cache.GetString(param.Key);
                if (obj != param.ImgCode)
                {
                    return result.Bad("验证码错误。");
                }
                _cache.Remove(param.Key);
            }
            if (string.IsNullOrEmpty(param.UserName))
            {
                return result.Bad("请输入用户名");
            }
            if (string.IsNullOrEmpty(param.Password))
            {
                return result.Bad("请输入密码");
            }
            var user = await _repository.GetFirstAsync(a => a.UserName == param.UserName && a.UserType == param.UserType);
            if (user == null)
            {
                return result.Bad("账号或密码错误");
            }
            var encryptPassword = _encryptionService.EncryptText(param.Password, user.PasswordSalt);
            if (user.Password != encryptPassword)
            {
                return result.Bad("账号或密码错误");
            }
            if (user.Active != ActiveEnum.启用)
            {
                return result.Bad($"该账户已{user.Active}");
            }
            user.LastLoginTime = DateTime.Now;
            _ = _repository.UpdateAsync(user, p => p.LastLoginTime);
            return ResultHelper.Ok(user);
        }

        /// <summary>
        /// 微信小程序登录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<User>> LoginForMiniProgram(WeixinCode2SessionRequest param)
        {
            var result = ResultHelper.Bad<User>(string.Empty);
            if (string.IsNullOrEmpty(param?.Code))
            {
                return result.Bad("参数错误");
            }
            string key = string.Format(CacheKeys.WeixinAuthCode, param.Code);
            var apiResult = _cache.Get<SDK.Weixin.Models.Code2SessionResult>(key);
            
            if (apiResult == null)
            {
                apiResult = await SDK.Weixin.WeixinApi.Code2Session(param.AppId, param.Code);
                if (!apiResult.Success)
                {
                    return result.Bad(apiResult.ErrMsg);
                }
                _cache.Set(key, apiResult, TimeSpan.FromMinutes(5));
            }

            return await LoginForWeixin(param.AppId, apiResult.OpenId, apiResult.UnionId);
        }

        public virtual async Task<Result<User>> LoginForWeixin(WeixinLoginRequest param)
        {
            var result = ResultHelper.Bad<User>(string.Empty);
            if (string.IsNullOrEmpty(param?.Code))
            {
                return result.Bad("参数错误");
            }
            var userResult = await SDK.Weixin.MP.MPApi.GetUserInfoAsync(param.Code);
            if (userResult == null) return result.Bad("获取用户信息失败");
            var apiResult = await SDK.Weixin.MP.MPApi.GetSubscribeUserInfoByCodeAsync(param.Code);
            if (apiResult == null) return result.Bad("获取用户信息失败！");
            return await LoginForWeixin(SDK.Weixin.MP.MPApi.MPAppId, apiResult.OpenId,apiResult.UnionId, userResult.NickName, userResult.Sex, userResult.HeadImgUrl);
        }
        /// <summary>
        /// 微信登录
        /// </summary>
        /// <param name="openId"></param>
        /// <param name="unionId"></param>
        /// <returns></returns>
        private async Task<Result<User>> LoginForWeixin(string appId, string openId, string unionId, string nickName = null, int sex = 0, string headImgUrl = null, string sessionKey = null,string encryptedData=null,string iv=null)
        {
            var result = ResultHelper.Bad<User>(string.Empty);

            User userInfo = null;
            if (!string.IsNullOrEmpty(unionId))
            {
                userInfo = await _repository.GetFirstAsync(m => m.WxUnionId == unionId);
            }
            if (userInfo == null)
            {
                userInfo = await _repository.GetFirstAsync(m => m.WxOpenId == openId);
            }
            if (userInfo == null)
            {
                //解密手机号码
                var decodedEntity = EncryptHelper.DecryptPhoneNumber(sessionKey, encryptedData, iv);
                
                var userName = unionId.IsNull(openId);
                userInfo = new User()
                {
                    UserName = decodedEntity.phoneNumber,
                    //Password = _encryptionService.EncryptText(param.PassWord.IsNull("123456")),
                    UserType = UserTypeEnum.用户,
                    Avatar = headImgUrl,
                    WxOpenId = openId,
                    WxUnionId = unionId,
                    NickName = nickName,
                    Sex = sex,
                    AppId = appId,
                    //SessionKey=sessionKey,
                };
                var registerResult = await Register(userInfo);
                if (!registerResult.OK)
                {
                    return result.Bad(registerResult.Msg);
                }
            }
            return result.Ok(userInfo);
        }
        #endregion

        #region 注册
        /// <summary>
        /// 注册
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<Result<User>> Register(User user)
        {
            var result = ResultHelper.Bad<User>("");
            if (user == null) return result.Bad("参数不可为空");
            if (string.IsNullOrEmpty(user.UserName)) return result.Bad("用户名不能为空");

            if (!_lockHelper.LockOperation(UserOperationLockEnum.注册锁, user.UserName)) return result.Bad("系统繁忙，请稍后重试");
            try
            {
                var checkResult = await CheckUserName(user.UserName, user.UserType);
                if (!checkResult.OK) { return result.Bad($"用户已存在"); }

                if (!await _repository.InsertAsync(user))
                {
                    return result.Bad("注册失败");
                }
                ClearCache(user.Id);
                return result.Ok(user, "注册成功");
            }
            catch
            {
                return result.Bad("注册失败");
            }
            finally
            {
                _lockHelper.UnLockOperation(UserOperationLockEnum.注册锁, user.UserName);
            }
        }
        #endregion

        #region 修改密码
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="oldPassword"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> UpdatePassword(UpdatePasswordRequest param)
        {
            if (string.IsNullOrEmpty(param.Password) || param.Password.Length < 6)
            {
                return ResultHelper.Bad("密码长度不能少于6个字符");
            }
            var model = await GetInfo(param.UserId);
            if (model == null)
            {
                return ResultHelper.Bad("用户不存在");
            }
            if (model.Password != _encryptionService.EncryptText(param.OldPassword))
            {
                return ResultHelper.Bad("旧密码错误");
            }
            model.Password = _encryptionService.EncryptText(param.Password);
            model.ModifyTime = DateTime.Now;
            var result = await _repository.UpdateAsync(model, m => new { m.Password, m.ModifyTime }) > 0;
            return result ? ResultHelper.Ok() : ResultHelper.Bad("提交失败");
        }
        #endregion

        #region 重置密码

        #region 重置密码
        /// <summary>
        /// 重置密码
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> SellerResetPassword(SellerResetPasswordRequest param)
        {
            if (string.IsNullOrEmpty(param.SmsCode))
            {
                return ResultHelper.Bad("短信验证码不能为空");
            }
            var checkResult = await _smsService.CheckSms(param.UserName, param.SmsCode, SmsTypeEnum.重置密码);
            if (!checkResult.OK)
            {
                return ResultHelper.Bad(checkResult.Msg);
            }
            if (string.IsNullOrEmpty(param.Password) || param.Password.Length < 6)
            {
                return ResultHelper.Bad("密码长度不能少于6个字符");
            }
            return await BaseResetPassword(new ResetPasswordRequest() { UserType = UserTypeEnum.员工, UserName = param.UserName, Password = param.Password });
        }
        #endregion
        /// <summary>
        /// 重置密码
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> BaseResetPassword(ResetPasswordRequest param)
        {
            if (string.IsNullOrEmpty(param.UserName))
            {
                return ResultHelper.Bad("UserName Error");
            }
            if (string.IsNullOrEmpty(param.Password) || param.Password.Length < 6)
            {
                return ResultHelper.Bad("密码长度不能少于6个字符");
            }
            var model = await _repository.GetFirstAsync(m => m.UserName == param.UserName && m.UserType == param.UserType);
            if (model == null)
            {
                return ResultHelper.Bad("提交失败");
            }
            model.Password = _encryptionService.EncryptText(param.Password);
            model.ModifyTime = DateTime.Now;
            var result = await _repository.UpdateAsync(model, m => new { m.Password, m.ModifyTime }) > 0;
            return result ? ResultHelper.Ok() : ResultHelper.Bad("提交失败");
        }
        #endregion

        #region 获取用户数量
        /// <summary>
        /// 获取用户数量
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public virtual async Task<int> GetUserCount(UserTypeEnum userType)
        {
            return await _repository.GetCountAsync(m => m.UserType == userType && m.Deleted == 0);
        }
        #endregion

        #region 禁用启用
        /// <summary>
        /// 禁用启用
        /// </summary>
        /// <param name="user"></param>
        /// <param name="active"></param>
        /// <returns></returns>
        public virtual async Task<bool> SetActive(User user,ActiveEnum active)
        {
            var isUpdateActive = user.Active != active;
            if (isUpdateActive)
            {
                user.Active = active;
                ClearCache(user.Id);
                return await _repository.UpdateAsync(user, p => p.Active) > 0;
            }
            return true;
        }
        #endregion

        #region 更新头像昵称等信息
        /// <summary>
        /// 更新头像昵称等信息
        /// </summary>
        /// <returns></returns>
        public virtual async Task<bool> UpdateBaseInfo(UpdateBaseInfoRequest param)
        {
            if (param == null) return false;
            if (CurrentUser == null) return false;
            var result = await _repository.UpdateAsync(new User() { NickName = param.NickName, Avatar = param.AvatarUrl }, p => new { p.NickName, p.Avatar }, m => m.Id == CurrentUser.Id) > 0;
            if (result)
            {
                ClearCache(CurrentUser.Id);
            }
            return result;
        }
        #endregion

        #region 小程序手机号码授权登录
        public virtual async Task<Result<User>> AuthLogin(WxAuthLoginRequest param)
        {
            var result = ResultHelper.Bad<User>(string.Empty);
            if (string.IsNullOrEmpty(param?.Code))
            {
                return result.Bad("参数错误");
            }
            string key = string.Format(CacheKeys.WeixinAuthCode, param.Code);
            var apiResult = _cache.Get<SDK.Weixin.Models.Code2SessionResult>(key);
            if (apiResult == null)
            {
                //根据Code获取用户信息
                apiResult = await SDK.Weixin.WeixinApi.Code2Session(param.AppId, param.Code);
                if (!apiResult.Success)
                {
                    return result.Bad(apiResult.ErrMsg);
                }
                _cache.Set(key, apiResult, TimeSpan.FromMinutes(5));
            }

            return await LoginForWeixin(param.AppId, apiResult.OpenId, apiResult.UnionId, param.NickName, Convert.ToInt32(param.Gender), param.AvatarUrl, apiResult.SessionKey, param.EncryptedData,param.Iv);
        }
        #endregion

        #region 获取微信用户列表
        public virtual async Task<PageResponse<MemberUserPageResponse>> GetMemberUserPageList(MemberUserPageRequest param)
        {
            Expression<Func<User, bool>> lambda = m => m.Deleted == 0;
            if (!string.IsNullOrEmpty(param.UserName)) lambda = lambda.And(m => m.UserName.Contains(param.UserName));
            if (!string.IsNullOrEmpty(param.NickName)) lambda = lambda.And(m => m.NickName.Contains(param.NickName));
            if (param.UserType.HasValue) lambda = lambda.And(m => m.UserType == param.UserType);
            var list =await _repository.GetPagesAsync(lambda,param);
            var newList = list.Adapt<PageResponse<MemberUserPageResponse>>();
            return newList;
        }
        #endregion
    }
}
