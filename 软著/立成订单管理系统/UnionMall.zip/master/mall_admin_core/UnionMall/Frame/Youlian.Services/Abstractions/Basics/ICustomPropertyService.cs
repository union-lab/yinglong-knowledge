﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Response;
using Youlian.Domain.Response.Basics;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Request;

namespace Youlian.Services.Abstractions
{
    /// <summary>
    /// 扩展属性服务
    /// </summary>
    public interface ICustomPropertyService : IBaseService
    {
        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<CustomProperty> GetInfo(int id);
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<List<CustomProperty>> GetList(CustomPropertyEntityTypeEnum entityType);
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<PageResponse<CustomPropertyResponse>> GetResponseList(CustomPropertyPageRequest param);
        #endregion

        #region 编辑记录
        /// <summary>
        /// 编辑记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<CustomProperty>> Edit(EditCustomPropertyRequest param);
        #endregion

        #region 删除记录
        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Result<int>> Delete(int id);
        #endregion
    }
}
