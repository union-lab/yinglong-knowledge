﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Response;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Request;
using Youlian.SDK.Weixin.Work.Models;

namespace Youlian.Services.Abstractions
{
    /// <summary>
    /// 
    /// </summary>
    public interface IWeixinService : IBaseService
    {
        Result<string> AuthorizeCallback(WeixinAuthorizeCallbackRequest param);
        /// <summary>
        /// 获取授权信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Result<WeixinOauth2AuthorizeResponse> GetAuthorizeInfo(WeixinOauth2AuthorizeRequest param);
    }
}