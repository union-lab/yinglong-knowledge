﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request.Brand;
using Youlian.Domain.Request;
using Youlian.Domain.Response;
using Youlian.Domain.Response.MallSetting;

namespace Youlian.Services.Abstractions
{
    public interface IBannerService:IBaseService
    {
        /// <summary>
        /// 获取列表
        /// </summary>
        Task<PageResponse<BannerPageResponse>> GetPageList(BannerPageRequest param);

        Task<Result<Banner>> AddOrEdit(BannerRequest param);
        Task<Result<string>> UpdataIsShow(BannerRequest param);
        Task<Result<int>> Deletes(List<int> ids);
    }
}
