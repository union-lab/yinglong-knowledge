﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models.User;
using Youlian.Domain.Request;
using Youlian.Domain.Request.User;
using Youlian.Domain.Response;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using System.Collections.Generic;

namespace Youlian.Services.Abstractions
{
    /// <summary>
    /// 用户服务
    /// </summary>
    public interface IUserService : IBaseService<User>
    {
        #region 获取用户信息
        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        Task<User> GetInfoByUserName(string userName, UserTypeEnum userType);

        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        Task<User> GetInfo(int userId, bool fromCache = false);

        /// <summary>
        /// 清除缓存
        /// </summary>
        /// <param name="userId"></param>
        void ClearCache(int userId);
        #endregion

        #region 获取用户列表
        /// <summary>
        /// 获取用户分页列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<List<User>> GetListByIds(List<int> ids);

        /// <summary>
        /// 获取用户分页列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<PageResponse<User>> GetUserPageList(UserPageRequest param);
        #endregion

        #region 验证用户名
        /// <summary>
        /// 验证用户名
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="userType"></param>
        /// <returns></returns>
        Task<Result<string>> CheckUserName(string userName, UserTypeEnum userType);
        #endregion

        #region 登录验证
        /// <summary>
        /// 登录验证
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<User>> Login(LoginRequest param);

        /// <summary>
        /// 微信小程序登录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<User>> LoginForMiniProgram(WeixinCode2SessionRequest param);

        /// <summary>
        /// 微信网页登录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<User>> LoginForWeixin(WeixinLoginRequest param);
        #endregion

        #region 修改密码
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="oldPassword"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        Task<Result<int>> UpdatePassword(UpdatePasswordRequest param);
        #endregion

        #region 重置密码

        #region 商家重置密码
        /// <summary>
        /// 试客重置密码
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<int>> SellerResetPassword(SellerResetPasswordRequest param);
        #endregion

        /// <summary>
        /// 重置密码
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<int>> BaseResetPassword(ResetPasswordRequest param);
        #endregion

        #region 获取用户数量
        /// <summary>
        /// 获取用户数量
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        Task<int> GetUserCount(UserTypeEnum userType);
        #endregion

        #region 禁用启用
        /// <summary>
        /// 禁用启用
        /// </summary>
        /// <param name="user"></param>
        /// <param name="active"></param>
        /// <returns></returns>
        Task<bool> SetActive(User user, ActiveEnum active);
        #endregion

        #region 更新头像昵称等信息
        /// <summary>
        /// 更新头像昵称等信息
        /// </summary>
        /// <returns></returns>
        Task<bool> UpdateBaseInfo(UpdateBaseInfoRequest param);
        #endregion

        Task<Result<User>> AuthLogin(WxAuthLoginRequest param);
        Task<PageResponse<MemberUserPageResponse>> GetMemberUserPageList(MemberUserPageRequest param);
    }
}