﻿using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using System.Threading.Tasks;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;

namespace Youlian.Services.Abstractions
{
    public interface ISysTasksLogService : IBaseService
    {

        #region 添加记录
        /// <summary>
        /// 添加记录
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="logModel"></param>
        /// <returns></returns>

        Task<SysTasksLog> AddTaskLog(int jobId, SysTasksLog tasksLog);
        #endregion

        #region 查询日志
        /// <summary>
        /// 查询日志
        /// </summary>
        Task<PageResponse<SysTasksLog>> GetList(SysTasksLogPageRequest param);
        #endregion

        /// <summary>
        /// 删除定时任务调用日志
        /// </summary>
        /// <param name="jobIds"></param>
        /// <returns></returns>
        Task<Result<int>> Delete(int[] ids);

        /// <summary>
        /// 清空日志
        /// </summary>
        /// <returns></returns>
        Task<Result<int>> Clean();
    }
}