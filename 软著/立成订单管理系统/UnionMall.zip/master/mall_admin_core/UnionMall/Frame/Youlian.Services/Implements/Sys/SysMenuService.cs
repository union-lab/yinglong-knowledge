﻿using Mapster;
using Youlian.Common.Extention;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    public class SysMenuService : BaseService, ISysMenuService
    {
        private readonly ICacheManager _cache;
        private readonly IRepository<SysMenu> _repository;
        private readonly IRepository<SysRolePermission> _permissionRepository;
        public SysMenuService(ICacheManager cache,
            IRepository<SysMenu> repository,
            IRepository<SysRolePermission> permissionRepository)
        {
            _cache = cache;
            _repository = repository;
            _permissionRepository = permissionRepository;
        }

        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<SysMenu> GetInfo(int id)
        {
            return await _repository.GetByIdAsync(id);
        }
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<List<SysMenu>> GetList(SysMenuListRequest param)
        {
            Expression<Func<SysMenu, bool>> lambda = m => true;
            if (!string.IsNullOrEmpty(param.Title)) lambda = lambda.And(m => m.Title == param.Title);
            var list = (await _repository.GetWhereAsync(lambda)).OrderByDescending(m => m.SortId).ThenBy(m => m.Id).ToList();
            return list;
        }
        #endregion

        #region 编辑菜单
        /// <summary>
        /// 编辑菜单
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Edit(EditSysMenuRequest param)
        {
            if (param.Id <= 0 && string.IsNullOrEmpty(param.Title)) return ResultHelper.Bad("菜单名称不能为空");
            if (await _repository.AnyAsync(m => m.Title == param.Title && m.Id != param.Id)) return ResultHelper.Bad("菜单已存在");

            var userId = CurrentUser.Id;
            var result = new Result<int>();

            SysMenu entity;
            if (param.Id > 0)
            {
                entity = await _repository.GetByIdAsync(param.Id.Value);
                if (entity == null)
                {
                    return result.Bad("ID不存在");
                }
                entity = param.Adapt<SysMenu>();
                await _repository.UpdateAsync(entity);
            }
            else
            {
                entity = param.Adapt<SysMenu>();
                await _repository.InsertAsync(entity);
            }
            ClearCache(entity.Permission);
            return result.Ok(entity.Id);
        }
        #endregion

        #region 删除菜单
        /// <summary>
        /// 删除菜单
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Delete(int id)
        {
            if(await _repository.AnyAsync(m=>m.ParentId==id)) return ResultHelper.Bad("该菜单含有下级菜单，不能删除");
            var result = await _repository.DeleteAsync(id) > 0;
            return result ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion

        #region 权限
        /// <summary>
        /// 根据权限标识获取菜单id（从缓存中）
        /// </summary>
        /// <param name="permissions"></param>
        /// <returns></returns>
        public async Task<int[]> GetMenuIdsByPermission(string permission)
        {
            var key = string.Format(CacheKeys.SysPermissionMenu, permission);
            var result = _cache.GetString(key);
            if (result == null)
            {
                var arr = permission.ToArr();
                result = (await _repository.GetWhereAsync(m => arr.Contains(m.Permission))).Select(m => m.Id).ToJoinStr() ?? string.Empty;
                _cache.SetString(key, result, TimeSpan.FromDays(1));
            }
            return result.ToIntArr();
        }
        /// <summary>
        /// 删除缓存数据
        /// </summary>
        public void ClearCache(string permission)
        {
            var key = string.Format(CacheKeys.SysPermissionMenu, permission);
            _cache.Remove(key);
        }
        #endregion

        #region 根据角色列表获取权限
        /// <summary>
        /// 根据角色列表获取权限
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<List<SysMenuListResponse>> GetMenuList(List<int> roleIds)
        {
            if (roleIds == null || !roleIds.Any()) return new List<SysMenuListResponse>();
            var permissionList = await _permissionRepository.GetWhereAsync(m => roleIds.Contains(m.RoleId));
            var menuIds = permissionList.Where(m => m.Actions.ToIntArr().Contains((int)ActionEnum.View)).Select(m => m.MenuId).ToList();
            if (!menuIds.Any()) return new List<SysMenuListResponse>();
            var list = (await _repository.GetWhereAsync(m => menuIds.Contains(m.Id))).Adapt<List<SysMenuListResponse>>().OrderBy(m => m.SortId).ThenBy(m => m.Id).ToList();
            list.ForEach(m => m.Actions = permissionList.Find(n => n.MenuId == m.Id)?.Actions.ToIntArr());
            return list;
        }
        #endregion
    }
}
