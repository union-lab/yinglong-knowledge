﻿using Mapster;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;

namespace Youlian.Services.Implements
{
    public class ShipService:BaseService,IShipService
    {
        private readonly IRepository<Ship> _repository;
        public ShipService(IRepository<Ship> repository)
        {
            _repository = repository;
        }
        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public async Task<PageResponse<Ship>> GetPageList(ShipPageRequest param)
        {
            Expression<Func<Ship, bool>> lambda = n => true;
            if (param.IsShow.HasValue)
            {
                lambda = lambda.And(n => n.IsShow == param.IsShow);
            }
            var pageList = await _repository.GetPagesAsync(lambda, param);
            return pageList;
        }
        #endregion

        #region 新增编辑
        public virtual async Task<Result<Ship>> AddOrEdit(ShipRequest param)
        {
            var result = ResultHelper.Bad<Ship>(string.Empty);
            if (param.Id <= 0 && string.IsNullOrEmpty(param.Name)) return result.Bad("配送方式名称不能为空");
            try
            {
                Ship entity;
                var isSuccess = false;
                using (var scope = new TransactionScope())
                {
                    //如果是默认的 应先获取原有默认的数据 进行更改未非默认
                    if (param.IsDefault.Value)
                    {
                        var isDefaultList = await _repository.GetWhereAsync(w => w.IsDefault == true);
                        List<Ship> listModel = new List<Ship>();
                        foreach (var item in isDefaultList)
                        {
                            item.IsDefault = false;
                            listModel.Add(item);
                        }
                        await _repository.UpdateAsync(listModel);
                    }
                    if (param.Id > 0)
                    {
                        entity = await _repository.GetByIdAsync(param.Id);
                        if (entity == null)
                        {
                            return result.Bad("ID不存在");
                        }
                        entity = param.Adapt(entity);
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.UpdateAsync(entity) > 0;
                    }
                    else
                    {
                        entity = param.Adapt<Ship>();
                        entity.AddTime = DateTime.Now;
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.InsertAsync(entity);
                    }
                    if (isSuccess)
                    {
                        scope.Complete();
                    }
                }
                return isSuccess ? result.Ok(entity) : result.Bad("提交失败");

            }
            catch
            {

            }
            return result.Bad("提交失败");
        }
        #endregion

        #region 更新是否开启
        public async Task<Result<string>> UpdataIsShow(UpdataShipRequest param)
        {
            var result = ResultHelper.Bad<string>(string.Empty);
            var model = await _repository.GetByIdAsync(param.Id);
            if (model == null)
            {
                return result.Bad("找不到对应消息");
            }
            if (param.Type == 0)
            {
                //是否默认只能是一个，如果更改应将之前有默认的更改为不是默认的
                var isDefaultList = await _repository.GetWhereAsync(w => w.IsDefault == true);
                List<Ship> listModel = new List<Ship>();
                foreach (var item in isDefaultList)
                {
                    item.IsDefault = false;
                    listModel.Add(item);
                }
                await _repository.UpdateAsync(listModel);
                model.IsDefault = param.BoolValue.Value;
            }
            if (param.Type == 1)
            {
                model.IsShow = param.BoolValue.Value;
            }
            model.ModifyTime = DateTime.Now;
            return await _repository.UpdateAsync(model) > 0 ? result.Ok("更改成功") : result.Bad("更改失败");
        }
        #endregion
        #region 删除记录
        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Deletes(List<int> ids)
        {
            var isSuccess = false;
            try
            {
                isSuccess = await _repository.DeleteAsync(ids.ToArray()) > 0;
            }
            catch (Exception e)
            {
                isSuccess = false;
            }
            return isSuccess ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion
    }
}
