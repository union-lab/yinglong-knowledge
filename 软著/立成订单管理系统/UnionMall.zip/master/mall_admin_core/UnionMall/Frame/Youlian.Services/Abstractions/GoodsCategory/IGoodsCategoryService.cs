﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Request.GoodsCategory;
using Youlian.Domain.Response;

namespace Youlian.Services.Abstractions
{
    public interface IGoodsCategoryService : IBaseService
    {
        Task<PageResponse<GoodsCategoryPageResponse>> GetResponseList(GoodsCategoryPageRequest param);
        Task<List<GoodsCategory>> GetGoodsCategoryList();
        Task<Result<GoodsCategory>> AddOrEdit(GoodsCategoryRequest param);
        Task<Result<string>> UpdataStatus(UpdataCategoryStatusRequest param);
        Task<Result<int>> Deletes(int ids);

        Task<List<GoodsCategoryComponentResponse>> GetComponentData(GoodsCategoryComponentRequest param);
    }
}
