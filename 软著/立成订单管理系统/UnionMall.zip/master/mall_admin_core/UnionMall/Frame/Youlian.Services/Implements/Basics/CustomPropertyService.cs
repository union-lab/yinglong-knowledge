﻿using Mapster;
using Youlian.Domain.Constant;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Response;
using Youlian.Domain.Response.Basics;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using System.Linq.Expressions;
using Youlian.Domain.Request;

namespace Youlian.Services.Implements
{
    /// <summary>
    /// 扩展属性服务
    /// </summary>
    public class CustomPropertyService : BaseService, ICustomPropertyService
    {
        private readonly IRepository<CustomProperty> _repository;
        public CustomPropertyService(IRepository<CustomProperty> repository)
        {
            _repository = repository;
        }

        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<CustomProperty> GetInfo(int id)
        {
            return await _repository.GetByIdAsync(id);
        }
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<List<CustomProperty>> GetList(CustomPropertyEntityTypeEnum entityType)
        {
            Expression<Func<CustomProperty, bool>> lambda = m => m.EntityType == entityType && m.Deleted == false;
            var list = await _repository.GetWhereAsync(lambda);
            return list;
        }
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<CustomPropertyResponse>> GetResponseList(CustomPropertyPageRequest param)
        {
            Expression<Func<CustomProperty, bool>> lambda = m => m.EntityType == param.EntityType && m.Deleted == false;
            if (!string.IsNullOrEmpty(param.Name)) lambda = lambda.And(m => m.Name == param.Name);
            var list = await _repository.GetPagesAsync(lambda, param);
            return list.Adapt<PageResponse<CustomPropertyResponse>>();
        }
        #endregion

        #region 编辑记录
        /// <summary>
        /// 编辑记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<CustomProperty>> Edit(EditCustomPropertyRequest param)
        {
            var result = ResultHelper.Bad<CustomProperty>(string.Empty);
            if (string.IsNullOrEmpty(param.Name)) return result.Bad("属性名称不能为空");
            if (string.IsNullOrEmpty(param.ValueType)) return result.Bad("属性值类型不能为空");
            if(!param.EntityType.HasValue) return result.Bad("实体类型不能为空");
            if (await _repository.AnyAsync(m => m.Name == param.Name && m.Id != param.Id)) return result.Bad("类别名称已存在");

            CustomProperty entity;
            if (param.Id > 0)
            {
                entity = await _repository.GetByIdAsync(param.Id.Value);
                if (entity == null)
                {
                    return result.Bad("ID不存在");
                }
                entity.Name = param.Name;
                entity.ValueType = param.ValueType;
                entity.ModifyTime = DateTime.Now;
                await _repository.UpdateAsync(entity);
            }
            else
            {
                entity = param.Adapt<CustomProperty>();
                await _repository.InsertAsync(entity);
            }
            return result.Ok(entity);
        }
        #endregion

        #region 删除记录
        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Delete(int id)
        {
            var result = await _repository.UpdateAsync(new CustomProperty() { Deleted = true }, p => p.Deleted, p => p.Id == id) > 0;
            return result ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion
    }
}
