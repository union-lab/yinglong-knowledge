﻿using Youlian.Common.Helpers;
using Youlian.Domain.Enums;
using Youlian.Domain.Models.Basics;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Youlian.Services.Abstractions
{

    /// <summary>
    /// 
    /// </summary>
    public interface IPermissionService
    {
        /// <summary>
        /// 验证用户权限
        /// </summary>
        /// <param name="action"></param>
        /// <returns></returns>
        Task<bool> HasPermission(params ActionEnum[] action);
        /// <summary>
        /// 验证用户权限
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="permission"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        Task<bool> HasPermission(int userId,string permission, params int[] action);

    }
}
