﻿using Microsoft.Extensions.DependencyInjection;
using Quartz;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Services.Abstractions;

namespace Youlian.Services.Implements
{
    public class BaseJob : IJob
    {
        public async Task Execute(IJobExecutionContext context)
        {
            await ExecuteTask(context);
        }
        /// <summary>
        /// 执行指定任务
        /// </summary>
        /// <param name="context">作业上下文</param>
        public async Task<SysTasksLog> ExecuteTask(IJobExecutionContext context)
        {
            double elapsed = 0;
            int status = 0;
            string logMsg;
            try
            {
                //var s = context.Trigger.Key.Name;
                //记录Job时间
                Stopwatch stopwatch = new();
                stopwatch.Start();
                //执行任务
                await ExecuteJob(context);
                stopwatch.Stop();
                elapsed = stopwatch.Elapsed.TotalMilliseconds;
                logMsg = "success";
            }
            catch (Exception ex)
            {
                JobExecutionException e2 = new(ex)
                {
                    //true  是立即重新执行任务 
                    RefireImmediately = true
                };
                status = 1;
                logMsg = $"Job Run Fail，Exception：{ex.Message}";
            }

            var logModel = new SysTasksLog()
            {
                Elapsed = elapsed,
                Status = status,
                JobMessage = logMsg
            };

            await RecordTaskLog(context, logModel);
            return logModel;
        }

        /// <summary>
        /// 记录到日志
        /// </summary>
        /// <param name="context"></param>
        /// <param name="logModel"></param>
        protected async Task RecordTaskLog(IJobExecutionContext context, SysTasksLog logModel)
        {
            var tasksLogService = AppSettings.GetScopeServices().GetService<ISysTasksLogService>();
            var taskQzService = AppSettings.GetScopeServices().GetService<ISysTasksQzService>();

            // 可以直接获取 JobDetail 的值
            IJobDetail job = context.JobDetail;

            logModel.InvokeTarget = job.JobType.FullName;
            logModel = await tasksLogService.AddTaskLog(job.Key.Name.ToInt(), logModel);
            //成功后执行次数+1
            if (logModel.Status == 0)
            {
                await taskQzService.UpdateRunInfo(job.Key.Name.ToInt());
            }
        }

        /// <summary>
        /// 执行任务内容
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        protected virtual Task ExecuteJob(IJobExecutionContext context)
        {
            return Task.CompletedTask;
        }
    }
}
