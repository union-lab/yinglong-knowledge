﻿using Mapster;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Request.GoodsCategory;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;

namespace Youlian.Services.Implements
{
    public class GoodsSkuModelService : BaseService, IGoodsSkuModelService
    {
        private readonly IRepository<GoodsSkuModel> _repository;
        private readonly IRepository<GoodsSkuModelValue> _goodsSkuModelValueRepository;
        public GoodsSkuModelService(
            IRepository<GoodsSkuModel> repository,
            IRepository<GoodsSkuModelValue> goodsSkuModelValueRepository)
        {
            _repository = repository;
            _goodsSkuModelValueRepository = goodsSkuModelValueRepository;
        }
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<GoodsSkuModelPageResponse>> GetResponseList(GoodsSkuModelPageRequest param)
        {
            Expression<Func<GoodsSkuModel, bool>> lambda = m => true;
            if (!string.IsNullOrEmpty(param.SkuName))
                lambda = lambda.And(w => w.SkuName.Contains(param.SkuName));
            var list = await _repository.GetPagesAsync(lambda, param);
            var newList = list.Adapt<PageResponse<GoodsSkuModelPageResponse>>();
            var GoodsSkuModelValueList = await _goodsSkuModelValueRepository.GetAllAsync();
            foreach (var item in newList.Data)
            {
                item.GoodsSkuModelValues = GoodsSkuModelValueList.Where(w => w.SpecId == item.Id).ToList().Adapt<List<GoodsSkuModelValueResponse>>();
            }
            return newList;
        }
        #region 新增编辑
        public virtual async Task<Result<GoodsSkuModel>> AddOrEdit(GoodsSkuModelRequest param)
        {
            var result = ResultHelper.Bad<GoodsSkuModel>(string.Empty);
            if (param.Id <= 0 && string.IsNullOrEmpty(param.SkuName)) return result.Bad("SKU模型名称不能为空");
            try
            {
                if (await _repository.AnyAsync(m => m.SkuName == param.SkuName && m.Id != param.Id))
                {
                    return result.Bad("SKU模型名称已存在");
                }
                GoodsSkuModel entity;
                var isSuccess = false;
                using (var scope = new TransactionScope())
                {
                    if (param.Id > 0)
                    {
                        entity = await _repository.GetByIdAsync(param.Id);
                        if (entity == null)
                        {
                            return result.Bad("ID不存在");
                        }
                       
                        entity = param.Adapt(entity);
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.UpdateAsync(entity) > 0;
                        if (isSuccess)
                        {
                            //先删除当前sku模型下的sku模型值
                            var orginValueList = await _goodsSkuModelValueRepository.GetWhereAsync(w => w.SpecId == param.Id);
                            //找出不同id的进行删除
                            var srGorup = orginValueList.Where(x => !param.GoodsSkuModelValues.Any(a => x.Id == a.Id)).ToList();
                            if (srGorup.Any())
                            {
                                //删除
                                var Ids = srGorup.Select(w => w.Id).ToArray();
                                isSuccess = await _goodsSkuModelValueRepository.DeleteAsync(Ids) > 0;
                            }
                            if (isSuccess)
                            {
                                List<GoodsSkuModelValue> addModelList = new List<GoodsSkuModelValue> ();
                                List<GoodsSkuModelValue> updateModelList = new List<GoodsSkuModelValue>();
                                foreach (var item in param.GoodsSkuModelValues)
                                {
                                    if (item.Id == 0)
                                    {
                                        //新增
                                        GoodsSkuModelValue addmodel = new GoodsSkuModelValue()
                                        {
                                            SpecId = param.Id,
                                            SpecValue = item.SpecValue,
                                            AddTime = DateTime.Now,
                                            ModifyTime = DateTime.Now
                                        };
                                        addModelList.Add(addmodel);
                                    }
                                    else
                                    {
                                        //修改
                                        GoodsSkuModelValue updatemodel = new GoodsSkuModelValue()
                                        {
                                            Id=item.Id,
                                            SpecId=param.Id,
                                            SpecValue = item.SpecValue,
                                            ModifyTime = DateTime.Now
                                        };
                                        updateModelList.Add(updatemodel);
                                    }

                                    
                                }
                                isSuccess = await _goodsSkuModelValueRepository.InsertAsync(addModelList) >0;
                                isSuccess = await _goodsSkuModelValueRepository.UpdateAsync(updateModelList) > 0;
                            }
                        }
                    }
                    else
                    {
                        entity = param.Adapt<GoodsSkuModel>();
                        entity.AddTime = DateTime.Now;
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.InsertAsync(entity);
                        if (isSuccess)
                        {
                            //添加对应模型值
                            if (entity.Id <= 0)
                            {
                                isSuccess = false;
                            }
                            else
                            {
                                List<GoodsSkuModelValue> modelList = new List<GoodsSkuModelValue>();
                                foreach (var item in param.GoodsSkuModelValues)
                                {
                                    GoodsSkuModelValue model = new GoodsSkuModelValue()
                                    {
                                        Id = item.Id,
                                        SpecId = entity.Id,
                                        SpecValue = item.SpecValue,
                                        AddTime = DateTime.Now,
                                        ModifyTime = DateTime.Now
                                    };
                                    modelList.Add(model);
                                }
                                isSuccess = await _goodsSkuModelValueRepository.InsertAsync(modelList) > 0;
                            }

                        }
                    }
                    if (isSuccess)
                    {
                        scope.Complete();
                    }
                }
                return isSuccess ? result.Ok(entity) : result.Bad("提交失败");

            }
            catch
            {

            }
            return result.Bad("提交失败");
        }
        #endregion


        #region 删除记录
        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Deletes(List<int> ids)
        {
            var isSuccess = false;
            try
            {
                using (var scope = new TransactionScope()) {
                    isSuccess = await _repository.DeleteAsync(ids.ToArray()) > 0;
                    if (isSuccess)
                    {
                        //删除该sku模型下的模型值
                        foreach (var id in ids)
                        {
                            _goodsSkuModelValueRepository.Delete(w => w.SpecId == id);
                        }
                    }
                    if (isSuccess)
                    {
                        scope.Complete();
                    }
                }
                    
            }
            catch (Exception e)
            {
                isSuccess = false;
            }
            return isSuccess ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion
    }
}
