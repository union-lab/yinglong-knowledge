﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Response;

namespace Youlian.Services.Abstractions
{
    public  interface IShipService : IBaseService
    {
        /// <summary>
        /// 获取列表
        /// </summary>
        Task<PageResponse<Ship>> GetPageList(ShipPageRequest param);

        Task<Result<Ship>> AddOrEdit(ShipRequest param);
        Task<Result<string>> UpdataIsShow(UpdataShipRequest param);
        Task<Result<int>> Deletes(List<int> ids);
    }
}
