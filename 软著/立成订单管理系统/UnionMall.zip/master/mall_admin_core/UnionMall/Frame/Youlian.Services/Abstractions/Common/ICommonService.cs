﻿using Youlian.Domain.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Response;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace Youlian.Services.Abstractions
{
    /// <summary>
    /// 
    /// </summary>
    public interface ICommonService
    {

        /// <summary>
        /// 获取枚举值
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Result<List<Dictionary<string, object>>> GetEnumValues(string type);

        #region 按配置上传腾讯云或阿里云
        /// <summary>
        /// 按配置上传腾讯云或阿里云,files为空则使用流式传输上传，不为空使用缓冲的模型绑定上传
        /// </summary>
        /// <returns></returns>
        Task<Result<List<string>>> YunUpload(string basePath = "default", Dictionary<string, Stream> files = null);
        #endregion

        #region 获取上传配置
        dynamic GetOssConfig();
        #endregion

        #region 获取Cos临时密钥
        Dictionary<string, object> GetCosCredential();
        #endregion

        #region 获取WxJsConfig
        /// <summary>
        /// 获取WxJsConfig
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        Result<WxJsSdkConfigReponse> GetWxJsConfig(int appId, string url);
        #endregion
    }
}
