﻿using Mapster;
using Youlian.Domain.Constant;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Response;
using Youlian.Domain.Response.Basics;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    public class ConfigService : BaseService, IConfigService
    {
        private readonly IRepository<Config> _repository;
        private readonly ICacheManager _cache;
        public ConfigService(ICacheManager cache, IRepository<Config> repository)
        {
            _cache = cache;
            _repository = repository;
        }

        private string SetCachePrefix(string key)
        {
            return $"Config:{key}";
        }
        #region 系统配置
        #region 获取系统配置
        /// <summary>
        /// 获取系统配置
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="configType"></param>
        /// <returns></returns>
        public async Task<T> GetConfig<T>(ConfigTypeEnum configType = ConfigTypeEnum.总控) where T : IBasicsConfig, new()
        {
            string configKey = typeof(T).Name.TrimEnd("Config");
            var cacheKey = SetCachePrefix(configKey);
            var configValue = _cache.GetString(cacheKey);
            if (!string.IsNullOrEmpty(configValue))
            {
                var info = configValue.TryDeserialize<T>();
                return info;
            }
            else
            {
                var configInfo = await _repository.GetFirstAsync(m => m.ConfigKey == configKey && m.ConfigType == configType);
                if (!string.IsNullOrEmpty(configInfo?.ConfigValue))
                {
                    _cache.SetString(cacheKey, configInfo.ConfigValue, TimeSpan.FromMinutes(60));
                    var info = configInfo.ConfigValue.TryDeserialize<T>();
                    return info;
                }
            }
            return new T();
        }
        #endregion

        #region 保存系统配置
        /// <summary>
        /// 保存系统配置
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="param"></param>
        /// <param name="configType"></param>
        /// <returns></returns>
        public async Task<Result<bool>> SaveConfig<T>(T param, ConfigTypeEnum configType = ConfigTypeEnum.总控) where T : IBasicsConfig, new()
        {
            string configKey = typeof(T).Name.TrimEnd("Config");
            var configValue = param.ToJson();
            return await SaveConfig(configKey, configType, configValue);
        }
        #endregion

        #region 保存参数配置
        /// <summary>
        /// 保存参数配置
        /// </summary>
        public async Task<Result<bool>> SaveConfig(string ConfigKey, ConfigTypeEnum ConfigType, string ConfigValue)
        {
            var isSuccess = false;
            var configInfo = await _repository.GetFirstAsync(m => m.ConfigKey == ConfigKey && m.ConfigType == ConfigType);
            if (configInfo == null)
            {
                configInfo = new Config()
                {
                    ConfigKey = ConfigKey,
                    ConfigValue = ConfigValue,
                    ConfigType = ConfigType
                };
                isSuccess = await _repository.InsertAsync(configInfo);
            }
            else
            {
                configInfo.ModifyTime = System.DateTime.Now;
                configInfo.ConfigValue = ConfigValue;
                isSuccess = await _repository.UpdateAsync(configInfo, m => new { m.ConfigValue, m.ModifyTime }) > 0; ;
            }
            if (isSuccess)
            {
                _cache.SetString(SetCachePrefix(ConfigKey), ConfigValue, TimeSpan.FromMinutes(60));
            }
            return isSuccess ? ResultHelper.Ok<bool>(true) : ResultHelper.Bad<bool>("保存参数失败");

        }
        #endregion
        #endregion
       

        /// <summary>
        /// 获取短信配置
        /// </summary>
        /// <returns></returns>
        public async Task<SmsSetting> GetSmsConfig()
        {
            return await GetConfig<SmsSetting>();
        }
    }
}
