﻿using Youlian.Common.Extention;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Threading.Tasks;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    /// <summary>
    /// 短信服务
    /// </summary>
    public class SmsService : BaseService, ISmsService
    {
        private readonly LockHelper _lockHelper;
        private readonly IRepository<QueuedSms> _repository;
        private readonly IConfigService _configService;

        public SmsService(LockHelper lockHelper, IRepository<QueuedSms> repository, IConfigService configService)
        {
            _lockHelper = lockHelper;
            _repository = repository;
            _configService = configService;
        }

        #region 获取最后一条短信
        /// <summary>
        /// 获取最后一条短信
        /// </summary>
        /// <param name="phone"></param>
        /// <param name="smsType"></param>
        /// <returns></returns>
        public async Task<QueuedSms> GetLastInfoAsync(string phone,SmsTypeEnum smsType)
        {
            return await _repository.GetLastAsync(m => m.Phone == phone && m.Type == smsType, m => m.Id);
        }
        #endregion

        #region 使用验证码校验
        /// <summary>
        /// 使用验证码校验
        /// </summary>
        /// <param name="phone"></param>
        /// <param name="code"></param>
        /// <param name="smsType"></param>
        /// <returns></returns>
        public async Task<Result<QueuedSms>> CheckSms(string phone, string code, SmsTypeEnum smsType)
        {
            var log = await _repository.GetLastAsync(m => m.Phone == phone && m.Type == smsType, m => m.Id);
            if (log == null || log.Status != SmsLogStatusEnum.未使用 || log.AddTime.AddMinutes(10) < DateTime.Now || log.CheckCode != code)
            {
                return ResultHelper.Bad<QueuedSms>("验证码错误");
            }
            log.Status = SmsLogStatusEnum.已使用;
            await _repository.UpdateAsync(log, p => p.Status);
            return ResultHelper.Ok(log, "验证码正确");
        }
        #endregion

        #region 发送短信
        /// <summary>
        /// 发送短信
        /// </summary>
        /// <param name="phone"></param>
        /// <param name="smsType"></param>
        /// <returns></returns>
        public async Task<Result<string>> SendSms(string phone, SmsTypeEnum smsType, string[] templateParam = null)
        {
            try
            {
               

                var smsSettings = await _configService.GetSmsConfig();
                var templateCode = "";
                var body = "";

                var queuedSms = new QueuedSms();
                if (smsType == SmsTypeEnum.登录验证码 || smsType == SmsTypeEnum.注册验证码 || smsType == SmsTypeEnum.重置密码)
                {
                    if (!_lockHelper.LockOperation(UserOperationLockEnum.短信锁, phone))
                    {
                        return ResultHelper.Bad<string>("短时间内请勿重复操作");
                    }
                    templateCode = smsSettings.TemplateNo.IsNull("SMS_100001");
                    var lastLog = await _repository.GetLastAsync(m => m.Phone == phone && m.Type == smsType, p => p.Id);
                    var times = lastLog?.AddTime.Date == DateTime.Today ? lastLog.Times : 0;
                    if (times >= smsSettings.NumberslimitDay)
                    {
                        _lockHelper.UnLockOperation(UserOperationLockEnum.短信锁, phone);
                        return ResultHelper.Bad<string>("该手机号已达到每日发送短信上限");
                    }
                    if (lastLog != null)
                    {
                        if ((DateTime.Now - lastLog.AddTime).TotalSeconds < (smsSettings.TimelimitSeconds > 0 ? smsSettings.TimelimitSeconds : 120)) //todo 短信间隔时间配置
                        {
                            _lockHelper.UnLockOperation(UserOperationLockEnum.短信锁, phone);
                            return ResultHelper.Bad<string>("间隔时间太短!");
                        }
                    }
                    var checkCode = RandomHelper.GetRandomString(RandomHelper.GetRandomSeed(), 6, "0123456789");
                    body = new { code = checkCode }.ToJson();
                    queuedSms = new QueuedSms()
                    {
                        Type = smsType,
                        Phone = phone,
                        Body = body,
                        CheckCode = checkCode,
                        AddTime = DateTime.Now,
                        Times = times + 1
                    };
                    if (AppSettings.Configuration["Settings:IsTest"] == "1") //测试环境直接返回验证码
                    {
                        // 测试环境

                        await _repository.InsertAsync(queuedSms);
                        _lockHelper.UnLockOperation(UserOperationLockEnum.短信锁, phone);
                        return ResultHelper.Ok(body);
                    }
                }

                //var tuple = await _testService.SendSmsAsync(smsSettings.Sign, phone, templateCode, body);
                var tuple = new { Success = false, Msg = "未实现" };
                if (tuple.Success)
                {
                    if (smsType == SmsTypeEnum.登录验证码 || smsType == SmsTypeEnum.注册验证码 || smsType == SmsTypeEnum.重置密码)
                    {
                        await _repository.InsertAsync(queuedSms);

                    }

                    return ResultHelper.Ok("发送成功");

                }
                else
                {
                    _lockHelper.UnLockOperation(UserOperationLockEnum.短信锁,phone);
                    return ResultHelper.Bad<string>(tuple.Msg);
                }
            }
            catch(Exception ex)
            {
                return ResultHelper.Bad<string>("发送失败,消息:"+ex.Message);
            }
        }
        #endregion
    }
}
