﻿using Youlian.Common;
using Youlian.Domain.Enums;
using Youlian.Services.Abstractions;
using Mapster;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using System.Collections.Generic;
using Youlian.Common.Extention;
using System;
using Youlian.Domain.Models.Basics;
using Microsoft.AspNetCore.Http;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Http.Features;
using Youlian.Common.Cache;

namespace Youlian.Services.Implements
{
    public class PermissionService : BaseService,IPermissionService
    {
        private readonly ICacheManager _cache;
        private readonly IHttpContextAccessor _httpContext;
        private readonly ISysMenuService _sysMenuService;
        private readonly ISysUserService _sysUserService;
        private readonly ISysRoleService _sysRoleService;
        public PermissionService(ICacheManager cache,
            IHttpContextAccessor httpContextAccessor,
            ISysMenuService sysMenuService,
            ISysUserService sysUserService,
            ISysRoleService sysRoleService)
        {
            _cache = cache;
            _httpContext = httpContextAccessor;
            _sysMenuService = sysMenuService;
            _sysUserService = sysUserService;
            _sysRoleService = sysRoleService;
        }

        /// <summary>
        /// 验证用户权限
        /// </summary>
        /// <param name="action"></param>
        /// <returns></returns>
        public virtual async Task<bool> HasPermission(params ActionEnum[] action)
        {
            return false;
            /*var endpoint = _httpContext.HttpContext.Features.Get<IEndpointFeature>()?.Endpoint;
            if (endpoint == null) return false;
            var actionAttribute = endpoint.Metadata.GetMetadata<AdminAuthorizeAttribute>();
            if (actionAttribute == null) return true;
            return await HasPermission(CurrentUser?.Id ?? 0, actionAttribute.PermissionName, action.Select(m => m.GetHashCode()).ToArray());*/
        }
        /// <summary>
        /// 验证用户权限
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="permission"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        public virtual async Task<bool> HasPermission(int userId, string permission, params int[] action)
        {
            if (userId <= 0)
            {
                return false;
            }
            var menuIds = await _sysMenuService.GetMenuIdsByPermission(permission);
            if (!menuIds.Any())
            {
                return false;
            }
            var userRoleIds = _sysUserService.GetRolesByUserId(userId);
            var list = await _sysRoleService.GetActions(userRoleIds, menuIds);
            var actions = action;// action?.Select(m => m.GetHashCode());
            if (actions != null && !list.Intersect(actions).Any())
            {
                return false;
            }
            return true;
        }
    }
}
