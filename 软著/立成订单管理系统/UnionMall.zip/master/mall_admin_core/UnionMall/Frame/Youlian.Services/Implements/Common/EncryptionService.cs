﻿using Youlian.Common;
using Youlian.Domain.Enums;
using Youlian.Services.Abstractions;
using Mapster;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using System.Collections.Generic;
using Youlian.Common.Extention;
using Youlian.Common.Cache;
using System;
using System.Security.Cryptography;
using System.IO;
using System.Text;

namespace Youlian.Services.Implements
{
    public class EncryptionService : IEncryptionService
    {

        private const string EncryptionKey = "Youlian.Encryption";

        /// <summary>
        /// 创建加密盐键
        /// </summary>
        /// <param name="size"></param>
        /// <returns></returns>
        public virtual string CreateSaltKey(int size)
        {
            var rng = new RNGCryptoServiceProvider();
            var buff = new byte[size];
            rng.GetBytes(buff);

            return Convert.ToBase64String(buff);
        }

        /// <summary>
        /// 创建密码哈希值
        /// </summary>
        /// <param name="password"></param>
        /// <param name="saltkey"></param>
        /// <param name="passwordFormat"></param>
        /// <returns></returns>
        public virtual string CreatePasswordHash(string password, string saltkey, string passwordFormat = "SHA1")
        {
            if (String.IsNullOrEmpty(passwordFormat))
                passwordFormat = "SHA1";
            var saltAndPassword = String.Concat(password, saltkey);

            var algorithm = HashAlgorithm.Create(passwordFormat);
            if (algorithm == null)
                throw new ArgumentException("Unrecognized hash name");

            var hashByteArray = algorithm.ComputeHash(Encoding.UTF8.GetBytes(saltAndPassword));
            return BitConverter.ToString(hashByteArray).Replace("-", "");
        }

        /// <summary>
        /// 加密文本
        /// </summary>
        /// <param name="plainText"></param>
        /// <param name="encryptionPrivateKey"></param>
        /// <returns></returns>
        public virtual string EncryptText(string plainText, string encryptionPrivateKey = "")
        {
            if (string.IsNullOrEmpty(plainText))
                return plainText;

            if (String.IsNullOrEmpty(encryptionPrivateKey))
                encryptionPrivateKey = EncryptionKey;

            var tDESalg = new TripleDESCryptoServiceProvider();
            tDESalg.Key = new ASCIIEncoding().GetBytes(encryptionPrivateKey.Substring(0, 16));
            tDESalg.IV = new ASCIIEncoding().GetBytes(encryptionPrivateKey.Substring(8, 8));
            tDESalg.Mode = CipherMode.CBC;
            tDESalg.Padding = PaddingMode.PKCS7;

            byte[] encryptedBinary = EncryptTextToMemory(plainText, tDESalg);
            return Convert.ToBase64String(encryptedBinary);
        }

        /// <summary>
        /// 解密文本
        /// </summary>
        /// <param name="cipherText"></param>
        /// <param name="encryptionPrivateKey"></param>
        /// <returns></returns>
        public virtual string DecryptText(string cipherText, string encryptionPrivateKey = "")
        {
            if (String.IsNullOrEmpty(cipherText))
                return cipherText;

            if (String.IsNullOrEmpty(encryptionPrivateKey))
                encryptionPrivateKey = EncryptionKey;

            var tDESalg = new TripleDESCryptoServiceProvider();
            tDESalg.Key = new ASCIIEncoding().GetBytes(encryptionPrivateKey.Substring(0, 16));
            tDESalg.IV = new ASCIIEncoding().GetBytes(encryptionPrivateKey.Substring(8, 8));
            tDESalg.Mode = CipherMode.CBC;
            tDESalg.Padding = PaddingMode.PKCS7;

            byte[] buffer = Convert.FromBase64String(cipherText);
            return DecryptTextFromMemory(buffer, tDESalg);
        }

        #region Utilities

        private byte[] EncryptTextToMemory(string data, SymmetricAlgorithm algorithm)
        {
            using (var ms = new MemoryStream())
            {
                using (var cs = new CryptoStream(ms, algorithm.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    byte[] toEncrypt = new ASCIIEncoding().GetBytes(data);
                    cs.Write(toEncrypt, 0, toEncrypt.Length);
                    cs.FlushFinalBlock();
                }

                return ms.ToArray();
            }
        }

        private string DecryptTextFromMemory(byte[] data, SymmetricAlgorithm algorithm)
        {
            using (var ms = new MemoryStream(data))
            {
                using (var cs = new CryptoStream(ms, algorithm.CreateDecryptor(), CryptoStreamMode.Read))
                {
                    var sr = new StreamReader(cs, new ASCIIEncoding());
                    return sr.ReadLine();
                }
            }
        }

        #endregion
    }
}
