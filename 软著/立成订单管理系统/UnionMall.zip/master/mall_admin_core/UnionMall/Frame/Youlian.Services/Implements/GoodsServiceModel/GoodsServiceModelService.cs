﻿using Mapster;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;

namespace Youlian.Services.Implements
{
    public class GoodsServiceModelService : BaseService, IGoodsServiceModelService
    {
        private readonly IRepository<GoodsServiceModel> _repository;
        private readonly IRepository<GoodsServiceModelValue> _goodsServiceModelValueRepository;
        public GoodsServiceModelService(
            IRepository<GoodsServiceModel> repository,
            IRepository<GoodsServiceModelValue> goodsServiceModelValueRepository)
        {
            _repository = repository;
            _goodsServiceModelValueRepository = goodsServiceModelValueRepository;
        }
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<GoodsServiceModelPageResponse>> GetResponseList(GoodsServiceModelPageRequest param)
        {
            Expression<Func<GoodsServiceModel, bool>> lambda = m => true;
            if (!string.IsNullOrEmpty(param.Name))
                lambda = lambda.And(w => w.Name.Contains(param.Name));
            var list = await _repository.GetPagesAsync(lambda, param);
            var newList = list.Adapt<PageResponse<GoodsServiceModelPageResponse>>();
            var GoodsServiceModelValueList = await _goodsServiceModelValueRepository.GetAllAsync();
            foreach (var item in newList.Data)
            {
                item.GoodsServiceModelValues = GoodsServiceModelValueList.Where(w => w.GoodsServiceId == item.Id).ToList().Adapt<List<GoodsServiceModelValueResponse>>();
            }
            return newList;
        }
        #region 新增编辑
        public virtual async Task<Result<GoodsServiceModel>> AddOrEdit(GoodsServiceModelRequest param)
        {
            var result = ResultHelper.Bad<GoodsServiceModel>(string.Empty);
            if (param.Id <= 0 && string.IsNullOrEmpty(param.Name)) return result.Bad("模型名称不能为空");
            try
            {
                if (await _repository.AnyAsync(m => m.Name == param.Name && m.Id != param.Id))
                {
                    return result.Bad("模型名称已存在");
                }
                GoodsServiceModel entity;
                var isSuccess = false;
                using (var scope = new TransactionScope())
                {
                    if (param.Id > 0)
                    {
                        entity = await _repository.GetByIdAsync(param.Id);
                        if (entity == null)
                        {
                            return result.Bad("ID不存在");
                        }

                        entity = param.Adapt(entity);
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.UpdateAsync(entity) > 0;
                        if (isSuccess)
                        {
                            //先删除当前sku模型下的sku模型值
                            var orginValueList = await _goodsServiceModelValueRepository.GetWhereAsync(w => w.GoodsServiceId == param.Id);
                            //找出不同id的进行删除
                            var srGorup = orginValueList.Where(x => !param.GoodsServiceModelValues.Any(a => x.Id == a.Id)).ToList();
                            if (srGorup.Any())
                            {
                                //删除
                                var Ids = srGorup.Select(w => w.Id).ToArray();
                                isSuccess = await _goodsServiceModelValueRepository.DeleteAsync(Ids) > 0;
                            }
                            if (isSuccess)
                            {
                                List<GoodsServiceModelValue> addModelList = new List<GoodsServiceModelValue>();
                                List<GoodsServiceModelValue> updateModelList = new List<GoodsServiceModelValue>();
                                foreach (var item in param.GoodsServiceModelValues)
                                {
                                    if (item.Id == 0)
                                    {
                                        //新增
                                        GoodsServiceModelValue addmodel = new GoodsServiceModelValue()
                                        {
                                            GoodsServiceId = param.Id,
                                            ServiceModelValue = item.ServiceModelValue,
                                            AddTime = DateTime.Now,
                                            ModifyTime = DateTime.Now
                                        };
                                        addModelList.Add(addmodel);
                                    }
                                    else
                                    {
                                        //修改
                                        GoodsServiceModelValue updatemodel = new GoodsServiceModelValue()
                                        {
                                            Id = item.Id,
                                            GoodsServiceId = param.Id,
                                            ServiceModelValue = item.ServiceModelValue,
                                            ModifyTime = DateTime.Now
                                        };
                                        updateModelList.Add(updatemodel);
                                    }


                                }
                                isSuccess = await _goodsServiceModelValueRepository.InsertAsync(addModelList) > 0;
                                isSuccess = await _goodsServiceModelValueRepository.UpdateAsync(updateModelList) > 0;
                            }
                        }
                    }
                    else
                    {
                        entity = param.Adapt<GoodsServiceModel>();
                        entity.AddTime = DateTime.Now;
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.InsertAsync(entity);
                        if (isSuccess)
                        {
                            //添加对应模型值
                            if (entity.Id <= 0)
                            {
                                isSuccess = false;
                            }
                            else
                            {
                                List<GoodsServiceModelValue> modelList = new List<GoodsServiceModelValue>();
                                foreach (var item in param.GoodsServiceModelValues)
                                {
                                    GoodsServiceModelValue model = new GoodsServiceModelValue()
                                    {
                                        Id = item.Id,
                                        GoodsServiceId = entity.Id,
                                        ServiceModelValue = item.ServiceModelValue,
                                        AddTime = DateTime.Now,
                                        ModifyTime = DateTime.Now
                                    };
                                    modelList.Add(model);
                                }
                                isSuccess = await _goodsServiceModelValueRepository.InsertAsync(modelList) > 0;
                            }

                        }
                    }
                    if (isSuccess)
                    {
                        scope.Complete();
                    }
                }
                return isSuccess ? result.Ok(entity) : result.Bad("提交失败");

            }
            catch
            {

            }
            return result.Bad("提交失败");
        }
        #endregion


        #region 删除记录
        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Deletes(List<int> ids)
        {
            var isSuccess = false;
            try
            {
                using (var scope = new TransactionScope())
                {
                    isSuccess = await _repository.DeleteAsync(ids.ToArray()) > 0;
                    if (isSuccess)
                    {
                        //删除该sku模型下的模型值
                        foreach (var id in ids)
                        {
                            _goodsServiceModelValueRepository.Delete(w => w.GoodsServiceId == id);
                        }
                    }
                    if (isSuccess)
                    {
                        scope.Complete();
                    }
                }

            }
            catch (Exception e)
            {
                isSuccess = false;
            }
            return isSuccess ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion
    }
}
