﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;

namespace Youlian.Services.Abstractions
{
    public interface ISysRoleService : IBaseService
    {
        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<SysRole> GetInfo(int id);
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<PageResponse<SysRole>> GetList(SysRolePageRequest param);
        #endregion

        #region 编辑角色
        /// <summary>
        /// 编辑角色
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<int>> Edit(EditSysRoleRequest param);
        #endregion

        #region 删除角色
        /// <summary>
        /// 删除角色
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Result<int>> Delete(int id);
        #endregion

        #region 获取权限
        /// <summary>
        /// 获取权限
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<List<SysRoleMenuResponse>> GetMenuPermissionList(int roleId);
        #endregion

        #region 设置权限
        /// <summary>
        /// 设置权限
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<int>> EditPermission(RolePermissionEditRequest param);
        #endregion

        #region 权限验证
        /// <summary>
        /// 根据权限标识获取菜单id（从缓存中）
        /// </summary>
        /// <param name="permissions"></param>
        /// <returns></returns>
        Task<IEnumerable<int>> GetActions(IEnumerable<int> roleIds, IEnumerable<int> menuIds);
        /// <summary>
        /// 删除缓存数据
        /// </summary>
        public void ClearCache();
        #endregion
    }
}