﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Models;
using Youlian.Domain.Request;
using Youlian.Domain.Request.Brand;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;
using Youlian.Repository;

namespace Youlian.Services.Abstractions
{
    public interface IBrandService : IBaseService
    {
        /// <summary>
        /// 获取列表
        /// </summary>
        Task<PageResponse<Brand>> GetPageList(BrandPageRuquest param);

        Task<Result<Brand>> AddOrEdit(BrandRequest param);
        Task<Result<string>> UpdataIsShow(BrandRequest param);
        Task<Result<int>> Deletes(List<int> ids);
        Task<List<Brand>> GetList();
        Task <List<SelectComponentResponse>>GetComponentData();
    }
}
