﻿using Youlian.Common.Extention;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Request;
using Youlian.Common.Cache;
using Youlian.Domain.Response;
using Microsoft.AspNetCore.Http;
using Youlian.SDK.Weixin.Work.Models;
using Microsoft.Extensions.Logging;
using Youlian.SDK.Weixin.Work;
using Mapster;
using Youlian.SDK;

namespace Youlian.Services.Implements
{
    /// <summary>
    /// 企业微信服务
    /// </summary>
    public class WorkWeixinService : BaseService, IWorkWeixinService
    {
        private readonly ILogger<WorkWeixinService> _logger;
        private readonly ICacheManager _cache;
        private readonly IWorkContactService _workContactService;
        private readonly ICallbackLogService _callbackLogService;
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly ISysLogService _sysLogService;

        public WorkWeixinService(ILogger<WorkWeixinService> logger,
            ICacheManager cache, 
            IHttpContextAccessor contextAccessor,
            
            IWorkContactService workContactService,
            ICallbackLogService callbackLogService,
            ISysLogService sysLogService)
        {
            _logger = logger;
            _cache = cache;
            _contextAccessor = contextAccessor;
            _workContactService = workContactService;
            _callbackLogService = callbackLogService;
            _sysLogService = sysLogService;
        }
        #region 授权回调中心
        /// <summary>
        /// 授权回调中心
        /// </summary>
        public Result<string> AuthorizeCallback(WorkWeixinSsoCallbackRequest param)
        {
            string key = param.State;
            var redirectUri = _cache.GetString(key);
            if (redirectUri == null) return ResultHelper.Bad<string>("授权失败:State Error");
            redirectUri += $"{(redirectUri.Contains("?") ? "&" : "?")}code={param.Code}&state={param.State}&agentId={param.AgentId}";
            return ResultHelper.Ok(redirectUri);
        }

        /// <summary>
        /// 获取授权信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual Result<WorkWeixinLoginResponse> GetAuthorizeInfo(WorkWeixinSsoQrConnectRequest param)
        {
            var result = new WorkWeixinLoginResponse();
            if (CurrentUser != null)
            {
                result.IsAuthenticated = true;
            }
            else
            {
                string key = string.Format(CacheKeys.CSRFtoken, Guid.NewGuid().ToString());
                _cache.SetString(key, param.RedirectUri, TimeSpan.FromSeconds(60 * 5));
                if (_contextAccessor.HttpContext.Request.IsWorkWeixinBrowser())
                {
                    result.AuthorizeUrl = SDK.Weixin.Work.WorkWeixinApi.GetOauth2Authorize(param.CallbackUrl, key);
                }
                else
                {
                    result.AuthorizeUrl = SDK.Weixin.Work.WorkWeixinApi.GetSsoQrConnect(param.AgentId, param.CallbackUrl, key);
                }
            }
            return ResultHelper.Ok(result);
        }
        #endregion

        #region 通知回调
        /// <summary>
        /// 验证URL
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public string VerifyUrl(NotifyVerifyParam param)
        {
            _logger.LogDebug($"原参数:{param?.ToJson()}");
            if(string.IsNullOrEmpty(param.EchoStr)) return string.Empty;
            var wxcpt = new WXBizMsgCrypt(ApiHelper.NotifyToken, ApiHelper.NotifyEncodingAESKey, BaseWeixinApi.CorpId);
            var result = string.Empty;
            wxcpt.VerifyURL(param.MsgSignature, param.Timestamp, param.Nonce, param.EchoStr, ref result);
            return result;
        }

        /// <summary>
        /// 通知回调
        /// </summary>
        /// <param name="param">通知参数</param>
        /// <param name="data">请求数据</param>
        /// <returns></returns>
        public async Task<Result<string>> Notify(NotifyParam param, NotifyPostParam data)
        {
            var result = new Result<string>();
            try
            {
                _logger.LogDebug($"原参数:{param?.ToJson()},data:{data?.ToJson()}");
                if (data == null) return result.Bad("未获取到数据");
                var request = _contextAccessor.HttpContext?.Request;
                var log = await _callbackLogService.AddLog(param.MsgSignature, CallbackNotifyTypeEnum.企业微信通知, request?.GetCurrentHost() + request?.Path.ToString() + request?.QueryString, data?.ToJson());
                if (log == null) return result.Bad("重复通知");
                var wxcpt = new WXBizMsgCrypt(ApiHelper.NotifyToken, ApiHelper.NotifyEncodingAESKey, BaseWeixinApi.CorpId);
                var decryptMsg = string.Empty;
                var ret = wxcpt.DecryptMsg(param.MsgSignature, param.Timestamp, param.Nonce, data.Encrypt, ref decryptMsg);
                if (ret != 0)
                {
                    _logger.LogError($"签名错误:" + param?.ToJson());
                    return result.Bad("签名错误");
                }
                _logger.LogDebug("解密参数:" + decryptMsg);

                //异步处理
                _ = Task.Run(async () =>
                {
                    var result = await ExecuteCallback(decryptMsg);
                    if (result.OK)
                    {
                        await _callbackLogService.UpdateStatus(log, CallbackNotifyStatusEnum.处理成功);
                    }
                });
            }
            catch(Exception ex)
            {
                _ = _sysLogService.AddSystemLog(SysLogTypeEnum.微信通讯录回调, "微信通知回调错误", $"NotifyId:{param.MsgSignature}", true);
                _logger.LogError("微信通知回调错误", ex);
            }
            return result.Ok();//正常响应即可
        }
        /// <summary>
        /// 执行回调
        /// </summary>
        /// <param name="decryptMsg"></param>
        /// <returns></returns>
        private async Task<Result<string>> ExecuteCallback(string decryptMsg)
        {
            var eventData = XmlHelper.Deserialize<EventChangeData>(decryptMsg, "xml");
            var msgType = MsgTypeEnum.Ohter.GetEnumList().Find(m => m.ToString().ToLower() == eventData.MsgType);
            switch (msgType)
            {
                case MsgTypeEnum.Event:
                    return await EventCallback(eventData, decryptMsg);
                default:
                    break;
            }
            return ResultHelper.Ok("");
        }

        /// <summary>
        /// 回调事件
        /// </summary>
        /// <param name="eventData"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        private async Task<Result<string>> EventCallback(EventChangeData eventData,string data)
        {
            var result = new Result<string>();
            var eventType = EventTypeEnum.Ohter.GetEnumList().Find(m => m.ToString().ToLower() == eventData.Event);

            switch (eventType)
            {
                case EventTypeEnum.Ohter:
                    break;
                case EventTypeEnum.sys_approval_change:
                   // result = await _approvalService.ChangeEvent(data);
                    break;
                case EventTypeEnum.change_contact:
                    result = await _workContactService.ChangeEvent(data);
                    break;
                default:
                    break;
            }
            return result;
        }

        /// <summary>
        /// 重新执行通知回调
        /// </summary>
        /// <returns></returns>
        public async Task ReExcuteNotify()
        {
            var list = await _callbackLogService.GetLogList(CallbackNotifyTypeEnum.企业微信通知, CallbackNotifyStatusEnum.未处理, TimeSpan.FromDays(7));
            foreach (var item in list)
            {
                var match = Regex.Match(item.RequestUrl, @"(\?|&)msg_signature=([^&]*)(&|$)");
                var msgSignature = match.Success ? match.Groups[2].Value : "";
                match = Regex.Match(item.RequestUrl, @"(\?|&)timestamp=([^&]*)(&|$)");
                var timestamp = match.Success ? match.Groups[2].Value : "";
                match = Regex.Match(item.RequestUrl, @"(\?|&)nonce=([^&]*)(&|$)");
                var nonce = match.Success ? match.Groups[2].Value : "";
                if (string.IsNullOrEmpty(msgSignature) || string.IsNullOrEmpty(timestamp) || string.IsNullOrEmpty(nonce)) continue;
                var wxcpt = new WXBizMsgCrypt(ApiHelper.NotifyToken, ApiHelper.NotifyEncodingAESKey, BaseWeixinApi.CorpId);
                var decryptMsg = string.Empty;
                var ret = wxcpt.DecryptMsg(msgSignature, timestamp, nonce, JsonExtention.TryDeserialize<NotifyPostParam>(item.Param)?.Encrypt, ref decryptMsg);
                if (ret != 0)
                {
                    await _callbackLogService.UpdateStatus(item, CallbackNotifyStatusEnum.处理失败);
                    continue;
                }
                var result = await ExecuteCallback(decryptMsg);
                if (result.OK)
                {
                    await _callbackLogService.UpdateStatus(item, CallbackNotifyStatusEnum.处理成功);
                }
            }
        }
        #endregion
    }
}
