﻿using Mapster;
using Youlian.Common.Extention;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    public class SysUserService : BaseService, ISysUserService
    {
        private readonly ICacheManager _cache;
        private readonly IRepository<SysUser> _repository;
        private readonly IRepository<SysMenu> _sysMenuRepository;
        private readonly IRepository<SysRole> _sysRoleRepository;
        private readonly IRepository<SysRolePermission> _permissionRepository;
        private readonly ISysLogService _sysLogService;
        private readonly ISmsService _smsService;
        private readonly IEncryptionService _encryptionService;
        public SysUserService(ICacheManager cache,
            IRepository<SysUser> repository,
            IRepository<SysMenu> sysMenuRepository,
            IRepository<SysRole> sysRoleRepository,
            IRepository<SysRolePermission> permissionRepository,
            ISysLogService sysLogService,
            ISmsService smsService,
            IEncryptionService encryptionService)
        {
            _cache = cache;
            _repository = repository;
            _sysMenuRepository = sysMenuRepository;
            _sysRoleRepository = sysRoleRepository;
            _permissionRepository = permissionRepository;
            _sysLogService = sysLogService;
            _smsService = smsService;
            _encryptionService = encryptionService;
        }

        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<SysUser> GetInfo(int id)
        {
            return await _repository.GetByIdAsync(id);
        }
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<SysUser>> GetPageList(SysUserPageRequest param)
        {
            Expression<Func<SysUser, bool>> lambda = m => m.Deleted == false;
            if (!string.IsNullOrEmpty(param.UserName)) lambda = lambda.And(m => m.UserName == param.UserName);
            var list = await _repository.GetPagesAsync(lambda, param);
            return list;
        }
        #endregion

        #region 编辑用户
        /// <summary>
        /// 编辑用户
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<SysUser>> Edit(EditSysUserRequest param)
        {
            var result = ResultHelper.Bad<SysUser>(string.Empty);
            if (param.Id <= 0 && string.IsNullOrEmpty(param.UserName)) return result.Bad("用户名不能为空");
            if (param.Id <= 0 && param.UserName == "admin") return result.Bad("admin为系统保留账户，不能创建此账户");
            if (string.IsNullOrEmpty(param.RealName)) return result.Bad("姓名不能为空");
            if (string.IsNullOrEmpty(param.Position)) return result.Bad("职位不能为空");
            if (string.IsNullOrEmpty(param.Department)) return result.Bad("部门不能为空");
            if (string.IsNullOrEmpty(param.Tel)) return result.Bad("手机号不能为空");
            if (await _repository.AnyAsync(m => m.UserName == param.UserName && m.Id != param.Id)) return result.Bad("用户名已存在");

            var creatorId = CurrentUser?.Id ?? 0;

            SysUser entity;
            if (param.Id > 0)
            {
                entity = await _repository.GetByIdAsync(param.Id);
                if (entity == null)
                {
                    return result.Bad("ID不存在");
                }
                entity.RealName = param.RealName;
                entity.Department = param.Department;
                entity.Position = param.Position;
                entity.Tel = param.Tel;
                entity.Avatar = param.Avatar;
                entity.RoleIds = param.RoleIds;
                entity.ModifyTime = DateTime.Now;
                await _repository.UpdateAsync(entity);
            }
            else
            {
                entity = param.Adapt<SysUser>();
                var salt = _encryptionService.CreateSaltKey(5);
                entity.PasswordSalt = salt;
                entity.Password = _encryptionService.CreatePasswordHash(param.Password.IsNull("123456"), salt);
                entity.CreatorId = creatorId;
                await _repository.InsertAsync(entity);
            }
            ClearRolesCache(entity.Id);
            return result.Ok(entity);
        }
        #endregion

        #region 删除用户
        /// <summary>
        /// 删除用户
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Delete(int id)
        {
            var result = await _repository.UpdateAsync(new SysUser() { Deleted = true }, p => p.Deleted, p => p.Id == id) > 0;
            return result ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion

        #region 启用禁用
        /// <summary>
        /// 启用禁用
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> SetActive(int id, ActiveEnum active)
        {
            var result = await _repository.UpdateAsync(new SysUser() { Active = active }, p => p.Active, p => p.Id == id) > 0;
            return result ? ResultHelper.Ok(0, $"{active}成功") : ResultHelper.Bad($"{active}失败");
        }
        #endregion

        #region 修改密码
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> UpdatePassword(UpdateSysUserPasswordRequest param)
        {
            if ((param?.Password?.Length ?? 0) < 6) return ResultHelper.Bad("新密码长度不能小于6");
            var model = await GetInfo(CurrentUser.Id);
            if (model == null) return ResultHelper.Bad("用户不存在");
            var oldpwdhash = _encryptionService.CreatePasswordHash(param.OldPassword, model.PasswordSalt);
            if (oldpwdhash != model.Password) return ResultHelper.Bad("旧密码错误");
            model.Password = _encryptionService.CreatePasswordHash(param.Password, model.PasswordSalt);
            model.ModifyTime = DateTime.Now;
            var result = await _repository.UpdateAsync(model, p => new { p.Password, p.ModifyTime }) > 0;
            return result ? ResultHelper.Ok(0, $"修改成功") : ResultHelper.Bad($"修改失败");
        }
        #endregion

        #region 系统用户登录
        /// <summary>
        /// 系统用户登录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<SysUser>> Login(SysUserLoginRequest param)
        {
            var result = ResultHelper.Bad<SysUser>("");
            if (!AppSettings.IsDevelopment)
            {
                return result.Bad("密码登录通道已关闭，请您使用企业微信扫码登录");
            }
            if (string.IsNullOrEmpty(param.UserName))
            {
                return result.Bad("请输入登录帐号");
            }
            var userType = UserTypeEnum.管理员;
            if (string.IsNullOrEmpty(param.Password))
            {
                return result.Bad("请输入登录密码");
            }
            if (string.IsNullOrEmpty(param.Captcha))
            {
                return result.Bad("请输入图片验证码");
            }
            if (string.IsNullOrEmpty(param.CaptchaKey) || param.Captcha != _cache.GetString(param.CaptchaKey))
            {
                return result.Bad("图片验证码错误");
            }
            var isOpenSmsLogin = System.Configuration.ConfigurationManager.AppSettings["isOpenSmsLogin"] == "1";
            if (isOpenSmsLogin && string.IsNullOrEmpty(param.SmsCode))
            {
                return result.Bad("请输入短信验证码");
            }
            var sysUser = await _repository.GetFirstAsync(a => a.UserName == param.UserName);
            if (sysUser == null)
            {
                _ = _sysLogService.AddLoginLog(userType, param.UserName, "登录失败，用户名不存在");
                return result.Bad("登录帐号或密码错误，请确认");
            }
            var pwd = _encryptionService.CreatePasswordHash(param.Password, sysUser.PasswordSalt);
            if (sysUser.Password != pwd)
            {
                _ = _sysLogService.AddLoginLog(userType, param.UserName, "登录失败，密码错误");
                return result.Bad("登录帐号或密码错误，请确认");
            }

            if (isOpenSmsLogin)
            {
                if (string.IsNullOrEmpty(sysUser.Tel))
                {
                    _ = _sysLogService.AddLoginLog(userType, param.UserName, "登录失败，未关联手机号");
                    return result.Bad("该账号未关联手机号，请联系管理员");
                }
                var checkResult = await _smsService.CheckSms(sysUser.Tel, param.SmsCode, Domain.Enums.SmsTypeEnum.登录验证码);
                if (!checkResult.OK)
                {
                    _ = _sysLogService.AddLoginLog(userType, param.UserName, "登录失败，短信验证码错误");
                    return result.Bad("短信验证码错误");
                }
            }
            if (sysUser.Active != ActiveEnum.启用)
            {
                _ = _sysLogService.AddLoginLog(userType, param.UserName, "登录失败，账户已禁用");
                return result.Bad("该账户已禁用，请联系管理员");
            }
            _ = _sysLogService.AddLoginLog(userType, param.UserName, "登录成功");
            return result.Ok(sysUser);
        }
        #endregion

        #region 获取用户角色
        /// <summary>
        /// 获取用户所属角色（从缓存中）
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int[] GetRolesByUserId(int userId)
        {
            //var key = string.Format(CacheKeys.SysUserRoles, userId);
            //var result = _cache.GetString(key);
            //if (result == null)
            //{
               var result = _repository.GetById(userId)?.RoleIds ?? string.Empty;
            //    _cache.SetString(key, result, TimeSpan.FromDays(1));
            //}
            return result.ToIntArr();
        }

        /// <summary>
        /// 获取用户所属角色名称（从缓存中）
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<string> GetRoleNamesByUserId(int userId)
        {
            var key = string.Format(CacheKeys.SysUserRoleNames, userId);
            var result = _cache.GetString(key);
            if (result == null)
            {
                var ids = _repository.GetById(userId)?.RoleIds?.ToIntArr();
                if (ids?.Length>0)
                {
                    result = _sysRoleRepository.GetWhere(m => ids.Contains(m.Id)).Select(m => m.RoleName).ToJoinStr();
                }

                _cache.SetString(key, result, TimeSpan.FromDays(1));
            }
            return result.ToArr().ToList();
        }
        public void ClearRolesCache(int userId)
        {
            var key = string.Format(CacheKeys.SysUserRoles, userId);
            _cache.Remove(key);
            key = string.Format(CacheKeys.SysUserRoleNames, userId);
            _cache.Remove(key);
        }
        #endregion

        #region 获取用户菜单
        /// <summary>
        /// 获取用户菜单
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public virtual async Task<List<SysMenu>> GetMenuList(int userId)
        {
            var user = await _repository.GetByIdAsync(userId);
            var list = new List<SysMenu>();
            if (user.UserName.ToLower() == "admin")
            {
                list = await _sysMenuRepository.GetWhereAsync(m => m.MenuType == SysMenuTypeEnum.菜单 && m.Status == SysMenuStatusEnum.显示);
            }
            else
            {
                var userRoleIds = user.RoleIds.ToIntArr();
                var permissionList = await _permissionRepository.GetWhereAsync(m => userRoleIds.Contains(m.RoleId));
                var menuIds = permissionList.Select(m => m.MenuId).Distinct();
                list = menuIds.Any() ? await _sysMenuRepository.GetWhereAsync(m => menuIds.Contains(m.Id) && m.Status == SysMenuStatusEnum.显示 && m.MenuType == SysMenuTypeEnum.菜单) : new List<SysMenu>();
            }
            return list.OrderBy(m => m.SortId).ThenBy(m => m.Id).ToList();
        }
        #endregion

        #region 获取登录授权二维码

        public virtual async Task<Result<SysUser>> WorkWeixinLogin(WorkWeixinSsoCallbackRequest param)
        {
            var result = ResultHelper.Bad<SysUser>(string.Empty);
            if (string.IsNullOrEmpty(param?.Code))
            {
                return result.Bad("参数错误");
            }
            if (param?.AgentId <= 0)
            {
                return result.Bad("参数错误");
            }
            var userType = UserTypeEnum.管理员;
            if (string.IsNullOrEmpty(_cache.GetString(param.State)))
            {
                _ = _sysLogService.AddLoginLog(userType, param.Code, "无效State");
                return result.Bad("非法操作");
            }
            var apiResult = await SDK.Weixin.Work.WorkWeixinApi.GetAccessUserAsync(param.AgentId, param.Code);
            if (!apiResult.Success || string.IsNullOrEmpty(apiResult.UserId))
            {
                return result.Bad(apiResult.ErrMsg);
            }
            var userName = apiResult.UserId;
            var userInfo = await _repository.GetFirstAsync(m => m.UserName == userName);
            if (userInfo != null)
            {
                if (userInfo.Active != ActiveEnum.启用)
                {
                    _ = _sysLogService.AddLoginLog(userType, userInfo.UserName, "登录失败，账户已禁用");
                    return result.Bad("该账户已禁用，请联系管理员");
                }
                _ = _sysLogService.AddLoginLog(userType, userName, "登录成功");
                return result.Ok(userInfo);
            }
            var userApiResult = await SDK.Weixin.Work.WorkWeixinApi.GetUserInfoAsync(param.AgentId, userName);
            if (!userApiResult.Success)
            {
                return result.Bad(apiResult.ErrMsg);
            }
            var deptApiResult = await SDK.Weixin.Work.WorkWeixinApi.GetDepartmentInfo(userApiResult.MainDepartment);
            var addResult = await Edit(new EditSysUserRequest()
            {
                UserName = userName,
                RealName = userApiResult.Name,
                Department = deptApiResult.Department?.Name,
                Position = userApiResult.Position,
                Tel = userApiResult.Mobile.IsNull(userApiResult.Telephone),
                Avatar = userApiResult.Avatar,
                Password = Guid.NewGuid().ToString(),
            });
            if (!addResult.OK)
            {
                return result.Bad(addResult.Msg);
            }
            _ = _sysLogService.AddLoginLog(userType, userName, "登录成功");
            return result.Ok(addResult.Data);
        }
        #endregion
    }
}
