﻿using Youlian.Common.Helpers;
using Youlian.Domain.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Youlian.Services.Abstractions
{
    /// <summary>
    /// 
    /// </summary>
    public interface IEncryptionService
    {
        /// <summary>
        /// 创建加密盐键
        /// </summary>
        /// <param name="size"></param>
        /// <returns></returns>
        string CreateSaltKey(int size);

        /// <summary>
        /// 创建密码哈希值
        /// </summary>
        /// <param name="password"></param>
        /// <param name="saltkey"></param>
        /// <param name="passwordFormat"></param>
        /// <returns></returns>
        string CreatePasswordHash(string password, string saltkey, string passwordFormat = "SHA1");

        /// <summary>
        /// 加密文本
        /// </summary>
        /// <param name="plainText"></param>
        /// <param name="encryptionPrivateKey"></param>
        /// <returns></returns>
        string EncryptText(string plainText, string encryptionPrivateKey = "");

        /// <summary>
        /// 解密文本
        /// </summary>
        /// <param name="cipherText"></param>
        /// <param name="encryptionPrivateKey"></param>
        /// <returns></returns>
        string DecryptText(string cipherText, string encryptionPrivateKey = "");
    }
}
