﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Youlian.Domain.Models;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authentication;
using Youlian.Common.Cache;

namespace Youlian.Services.Implements
{
    public class TokenAuthenticationService : IAuthenticateService
    {
        private readonly JwtOptions _tokenSetting;
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly ICacheManager _cacheManager;
        public TokenAuthenticationService(IOptions<JwtOptions> tokenSetting, IHttpContextAccessor contextAccessor, ICacheManager cacheManager)
        {
            _tokenSetting = tokenSetting.Value;
            _contextAccessor = contextAccessor;
            _cacheManager = cacheManager;
        }

        /// <summary>
        /// 登录验证，生成token
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>

        public Task<Result<string>> SignInAsync<T>(T param) where T : BaseAuthenticationData
        {
            var result = new Result<string>();
            var claims = new[]
            {
                new Claim(ClaimTypes.PrimarySid, param.Id.ToString()),//PrimarySid保存用户ID
                new Claim(ClaimTypes.Name, param.UserName),
                new Claim(ClaimTypes.UserData,  param.ToJson()),
            };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_tokenSetting.SecurityKey));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var jwtToken = new JwtSecurityToken(_tokenSetting.Issuer, _tokenSetting.Audience, claims, expires: DateTime.Now.AddMinutes(_tokenSetting.AccessExpiration), signingCredentials: credentials);
            var data = new JwtSecurityTokenHandler().WriteToken(jwtToken);

            //var cacheKey=string.Format(CacheKeys.LoginToken,param.Id.ToString());
            //_cacheManager.SetString(cacheKey, data.ToMd5());
            return Task.FromResult(result.Ok(data));
        }

        public async Task<Result<int>> SignOutAsync()
        {
            //await _contextAccessor.HttpContext.SignOutAsync(AppSettings.CookieAuthenticationScheme);
            return ResultHelper.Ok();
        }
    }
}
