﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Response;
using Youlian.Domain.Response.Basics;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;

namespace Youlian.Services.Abstractions
{
    public interface IMessageSendRecordService : IBaseService
    {
        /// <summary>
        /// 添加记录
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<bool> Add(MessageSendRecord model);

        /// <summary>
        /// 判断是否存在
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        Task<bool> Exist(MessageTypeEnum type, string messageId);
    }
}
