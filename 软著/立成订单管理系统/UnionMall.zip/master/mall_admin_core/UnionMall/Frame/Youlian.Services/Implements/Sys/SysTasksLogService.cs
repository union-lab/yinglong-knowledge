﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;
using System.Collections.Generic;

namespace Youlian.Services.Implements
{
    public class SysTasksLogService : BaseService, ISysTasksLogService
    {
        private readonly IRepository<SysTasksLog> _repository;
        private ISysTasksQzService _tasksQzService;
        public SysTasksLogService(IRepository<SysTasksLog> repository, ISysTasksQzService tasksQzService)
        {
            _repository = repository;
            _tasksQzService = tasksQzService;
        }

        #region 添加记录
        /// <summary>
        /// 添加记录
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="logModel"></param>
        /// <returns></returns>

        public async Task<SysTasksLog> AddTaskLog(int jobId, SysTasksLog logModel)
        {
            //获取任务信息
            var model = await _tasksQzService.GetInfo(jobId);
            if (model != null)
            {
                logModel.JobId = jobId;
                logModel.JobName = model.Name;
                logModel.JobGroup = model.JobGroup;
                logModel.AddTime = DateTime.Now;
            }
            await _repository.InsertAsync(logModel);
            return logModel;
        }
        #endregion

        #region 查询日志
        /// <summary>
        /// 查询日志
        /// </summary>
        public async Task<PageResponse<SysTasksLog>> GetList(SysTasksLogPageRequest param)
        {
            Expression<Func<SysTasksLog, bool>> lambda = m => true;
            if (!string.IsNullOrEmpty(param.JobName)) lambda = lambda.And(m => m.JobName.Contains(param.JobName));
            if (!string.IsNullOrEmpty(param.JobGroup)) lambda = lambda.And(m => m.JobGroup==param.JobGroup);
            if (param.JobId.HasValue) lambda = lambda.And(m => m.JobId == param.JobId);
            if(param.StartTime.HasValue) lambda = lambda.And(m => m.AddTime >= param.StartTime);
            if(param.EndTime.HasValue) lambda = lambda.And(m => m.AddTime <= param.EndTime);
            var result = await _repository.GetPagesAsync(lambda, param);
            return result;
        }
        #endregion

        /// <summary>
        /// 删除定时任务调用日志
        /// </summary>
        /// <param name="jobIds"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Delete(int[] ids)
        {
            var result = await _repository.DeleteAsync(ids)>0;
            return result ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }

        /// <summary>
        /// 清空日志
        /// </summary>
        /// <returns></returns>
        public async Task<Result<int>> Clean()
        {
            await _repository.DeleteAsync(m=>true);
            return ResultHelper.Ok();
        }
    }
}
