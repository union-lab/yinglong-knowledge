﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Response;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Request;
using Youlian.SDK.Weixin.Work.Models;

namespace Youlian.Services.Abstractions
{
    /// <summary>
    /// 
    /// </summary>
    public interface IWorkWeixinService : IBaseService
    {
        #region 授权回调中心
        /// <summary>
        /// 授权回调中心
        /// </summary>
        Result<string> AuthorizeCallback(WorkWeixinSsoCallbackRequest param);

        /// <summary>
        /// 获取授权信息
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Result<WorkWeixinLoginResponse> GetAuthorizeInfo(WorkWeixinSsoQrConnectRequest param);
        #endregion

        #region 通知回调
        /// <summary>
        /// 验证URL
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        string VerifyUrl(NotifyVerifyParam param);

        /// <summary>
        /// 通知回调
        /// </summary>
        /// <param name="param">通知参数</param>
        /// <param name="data">请求数据</param>
        /// <returns></returns>
        Task<Result<string>> Notify(NotifyParam param, NotifyPostParam data);

        /// <summary>
        /// 重新执行通知回调
        /// </summary>
        /// <returns></returns>
        Task ReExcuteNotify();
        #endregion



    }
}