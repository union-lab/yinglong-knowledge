﻿using Youlian.Domain.Models;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;

namespace Youlian.Services.Abstractions
{
    public interface IAuthenticateService
    {
        Task<Result<string>> SignInAsync<T>(T param) where T: BaseAuthenticationData;
        Task<Result<int>> SignOutAsync();
    }
}