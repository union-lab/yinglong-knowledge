﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Response;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Request;
using Youlian.SDK.Weixin.Work.Models;

namespace Youlian.Services.Abstractions
{
    /// <summary>
    /// 企业微信通讯录服务
    /// </summary>
    public interface IWorkContactService : IBaseService
    {
        #region 通讯录变动事件
        /// <summary>
        /// 通讯录变动事件
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        Task<Result<string>> ChangeEvent(string data);
        #endregion

        #region 微信通讯录缓存
        /// <summary>
        /// 获取部门列表缓存
        /// </summary>
        /// <returns></returns>
        Task<DepartmentListResult> GetDepartmentListCacheAsync();
        /// <summary>
        /// 清除部门列表缓存
        /// </summary>
        void ClearDepartmentListCache();
        /// <summary>
        /// 获取员工列表缓存
        /// </summary>
        /// <returns></returns>
        Task<UserListResult> GetEmployeeListCacheAsync();
        /// <summary>
        /// 清除员工列表缓存
        /// </summary>
        void ClearEmployeeListCache();

        /// <summary>
        /// 获取员工信息缓存
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        Task<UserInfoResult> GetEmployeeInfoCacheAsync(string userId);
        /// <summary>
        /// 清除员工信息缓存
        /// </summary>
        void ClearEmployeeInfoCache(string userId);
        #endregion

        
    }
}