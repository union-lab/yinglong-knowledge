﻿using Mapster;
using Youlian.Common.Cache;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    public class NoticeService : BaseService, INoticeService
    {
        private readonly IRepository<Notice> _repository;
        public NoticeService(IRepository<Notice> repository)
        {
            _repository = repository;
        }

        #region 获取公告信息
        /// <summary>
        /// 获取公告信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<Notice> GetInfo(int id)
        {
            return await _repository.GetByIdAsync(id);
        }
        #endregion

        #region 获取公告列表
        /// <summary>
        /// 获取公告列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<List<Notice>> GetList(SystemClientEnum? client, bool? isTopShow = null)
        {
            Expression<Func<Notice, bool>> lambda = m => true;
            if (client.HasValue) lambda = lambda.And(m => m.Client == client);

            if (isTopShow.HasValue)
            {
                int istopshow = isTopShow.Value ? 1 : 0;
                lambda = lambda.And(m => m.IsTopShow == istopshow);
            }
            var list = await _repository.GetWhereAsync(lambda, p => p.AddTime);
            return list;
        }
        /// <summary>
        /// 获取公告列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<Notice>> GetPageList(NoticePageRequest param)
        {
            Expression<Func<Notice, bool>> lambda = m => true;
            if (!string.IsNullOrEmpty(param.Title)) lambda = lambda.And(m => m.Title.Contains(param.Title));
            if (param.Client.HasValue) lambda = lambda.And(m => m.Client == param.Client);
            if (param.IsTopShow.HasValue)
            {
                int istopshow = param.IsTopShow.Value ? 1 : 0;
                lambda = lambda.And(m => m.IsTopShow == istopshow);
            }
            var list = await _repository.GetPagesAsync(lambda, param, p => new { p.IsTop, p.AddTime });
            return list;
        }
        #endregion

        #region 添加修改公告
        /// <summary>
        /// 添加修改公告
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Edit(EditNoticeRequest param)
        {
            if (!param.Client.HasValue) return ResultHelper.Bad("公告分类不能为空");
            if (string.IsNullOrEmpty(param.Title)) return ResultHelper.Bad("公告标题不能为空");
            if (string.IsNullOrEmpty(param.Content)) return ResultHelper.Bad("公告内容不能为空");
            var userId = CurrentUser.Id;
            var result = new Result<int>();

            Notice entity;
            if (param.Id > 0)
            {
                entity = await _repository.GetByIdAsync(param.Id);
                if (entity == null)
                {
                    return result.Bad("ID不存在");
                }
                if (entity.UserId != userId)
                {
                    return result.Bad("无权操作");
                }
                entity = param.Adapt(entity);
                entity.ModifyTime = DateTime.Now;
                await _repository.UpdateAsync(entity);
            }
            else
            {
                entity = param.Adapt<Notice>();
                entity.UserId = userId;
                await _repository.InsertAsync(entity);
            }
            return result.Ok();
        }
        #endregion

        #region 删除公告
        /// <summary>
        /// 删除公告
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Delete(int id)
        {
            var result = await _repository.DeleteAsync(id) > 0;
            return result ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion
    }
}
