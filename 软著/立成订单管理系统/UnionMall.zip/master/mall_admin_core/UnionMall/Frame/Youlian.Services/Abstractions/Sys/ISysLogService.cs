﻿using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using System.Threading.Tasks;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;

namespace Youlian.Services.Abstractions
{
    public interface ISysLogService : IBaseService
    {
        /// <summary>
        /// 获取列表
        /// </summary>
        Task<PageResponse<SysLog>> GetPageList(SysLogPageRequest param);

        /// <summary>
        /// 添加登录日志
        /// </summary>
        Task AddLoginLog(UserTypeEnum userType, string userName, string logContent, bool success = false);

        /// <summary>
        /// 添加日志
        /// </summary>
        Task AddLog(UserTypeEnum userType, string userName, string logContent, SysLogTypeEnum logType);

        /// <summary>
        /// 保存系统日志
        /// </summary>
        Task AddSystemLog(SysLogTypeEnum logType, string title, string content, bool isNotifyAdmin = false);
    }
}