﻿using Youlian.Domain.Models;
using Youlian.Domain.Entities;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    public class BaseService : IBaseService
    {
        private AuthenticationDataManager _authenticationDataManager;
        private AuthenticationDataManager AuthenticationDataManager
        {
            get
            {
                if (_authenticationDataManager != null)
                    return _authenticationDataManager;
                return _authenticationDataManager = AppSettings.GetScopeServices().GetService<AuthenticationDataManager>();
            }
        }
        public ApiAuthenticationData CurrentUser => AuthenticationDataManager.CurrentUser;

        public BaseService()
        {

        }

    }

    public class BaseService<TEntity> : BaseService, IBaseService<TEntity> where TEntity : BaseEntity, new()
    {
        public IRepository<TEntity> Repository { get; }
        public BaseService(IRepository<TEntity> repository)
        {
            Repository = repository;
        }
    }
}
