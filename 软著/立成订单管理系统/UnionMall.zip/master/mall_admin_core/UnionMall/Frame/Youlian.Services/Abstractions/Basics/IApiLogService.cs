﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Models;
using Youlian.Domain.Models.Basics;
using Youlian.Domain.Response;
using Youlian.Domain.Response.Basics;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;

namespace Youlian.Services.Abstractions
{
    public interface IApiLogService : IBaseService
    {

    }
}
