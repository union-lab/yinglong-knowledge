﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Response;
using System.Threading.Tasks;
using Youlian.Common.Helpers;

namespace Youlian.Services.Abstractions
{
    /// <summary>
    /// 短信服务
    /// </summary>
    public interface ISmsService : IBaseService
    {
        #region 获取最后一条短信
        /// <summary>
        /// 获取最后一条短信
        /// </summary>
        /// <param name="phone"></param>
        /// <param name="smsType"></param>
        /// <returns></returns>
        Task<QueuedSms> GetLastInfoAsync(string phone, SmsTypeEnum smsType);
        #endregion

        #region 使用验证码校验
        /// <summary>
        /// 使用验证码校验
        /// </summary>
        /// <param name="phone"></param>
        /// <param name="code"></param>
        /// <param name="smsType"></param>
        /// <returns></returns>
        Task<Result<QueuedSms>> CheckSms(string phone, string code, SmsTypeEnum smsType);
        #endregion

        #region 发送短信
        /// <summary>
        /// 发送短信
        /// </summary>
        /// <param name="phone"></param>
        /// <param name="smsType"></param>
        /// <returns></returns>
        Task<Result<string>> SendSms(string phone, SmsTypeEnum smsType, string[] templateParam = null);
        #endregion
    }
}