﻿using Mapster;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Request.GoodsCategory;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;

namespace Youlian.Services.Implements
{
    public class GoodsCategoryService : BaseService, IGoodsCategoryService
    {
        private readonly IRepository<GoodsCategory> _repository;
        public GoodsCategoryService(
            IRepository<GoodsCategory> repository)
        {
            _repository = repository;
        }
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<GoodsCategoryPageResponse>> GetResponseList(GoodsCategoryPageRequest param)
        {
            Expression<Func<GoodsCategory, bool>> lambda = m => true;
            if (!string.IsNullOrEmpty(param.CategoryName))
                lambda = lambda.And(w => w.CategoryName.Contains(param.CategoryName));
            var list = await _repository.GetPagesAsync(lambda, param);
            var newList = list.Adapt<PageResponse<GoodsCategoryPageResponse>>();
            return newList;
        }
        public virtual async Task<List<GoodsCategory>> GetGoodsCategoryList()
        {
            return await _repository.GetAllAsync();
        }

        #region 新增编辑
        public virtual async Task<Result<GoodsCategory>> AddOrEdit(GoodsCategoryRequest param)
        {
            var result = ResultHelper.Bad<GoodsCategory>(string.Empty);
            if (param.Id <= 0 && string.IsNullOrEmpty(param.CategoryName)) return result.Bad("分类名称不能为空");
            try
            {
                if (await _repository.AnyAsync(m => m.CategoryName == param.CategoryName && m.Id != param.Id))
                {
                    return result.Bad("分类名称已存在");
                }
                GoodsCategory entity;
                var isSuccess = false;
                using (var scope = new TransactionScope())
                {
                    if (param.Id > 0)
                    {
                        entity = await _repository.GetByIdAsync(param.Id);
                        if (entity == null)
                        {
                            return result.Bad("ID不存在");
                        }
                        entity = param.Adapt(entity);
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.UpdateAsync(entity) > 0;
                    }
                    else
                    {
                        entity = param.Adapt<GoodsCategory>();
                        entity.AddTime = DateTime.Now;
                        entity.ModifyTime = DateTime.Now;
                        isSuccess = await _repository.InsertAsync(entity);
                    }
                    if (isSuccess)
                    {
                        scope.Complete();
                    }
                }
                return isSuccess ? result.Ok(entity) : result.Bad("提交失败");

            }
            catch
            {

            }
            return result.Bad("提交失败");
        }
        #endregion

        #region 更新展示状态
        public async Task<Result<string>> UpdataStatus(UpdataCategoryStatusRequest param)
        {
            var result = ResultHelper.Bad<string>(string.Empty);
            var model = await _repository.GetByIdAsync(param.Id);
            if (model == null)
            {
                return result.Bad("找不到对应消息");
            }
            switch (param.Type)
            {
                case Domain.Enums.UpdataGoodsCategoryStatusTypeEnum.是否展示:
                    model.IsShow = param.Status;
                    break;
                case Domain.Enums.UpdataGoodsCategoryStatusTypeEnum.是否首页展示:
                    model.IsShowHomePage = param.Status;
                    break;
            }
            model.ModifyTime = DateTime.Now;
            return await _repository.UpdateAsync(model) > 0 ? result.Ok("更改成功") : result.Bad("更改失败");
        }
        #endregion

        #region 删除记录
        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Deletes(int id)
        {
            var isSuccess = false;
            try
            {
                var hasChildren = await _repository.GetWhereAsync(w => w.ParentId == id);
                if (hasChildren.Any())
                    return ResultHelper.Bad("删除失败,该分类存在子类");
                isSuccess = await _repository.DeleteAsync(id) > 0;
            }
            catch (Exception e)
            {
                isSuccess = false;
            }
            return isSuccess ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion


        #region 获取分类组件数据
        /// <summary>
        /// 获取区域组件数据
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<List<GoodsCategoryComponentResponse>> GetComponentData(GoodsCategoryComponentRequest param)
        {
            if (!param.ParentId.HasValue) return new List<GoodsCategoryComponentResponse>();
            List<GoodsCategory> list = null;
            list = await _repository.GetWhereAsync(w=>w.ParentId==param.ParentId);
            var newList = list.Select(m => new GoodsCategoryComponentResponse()
            {
                value = m.Id,
                label = m.CategoryName.IsNull(m.CategoryName),
                Children=GetChildren(m.Id)
            }).ToList();
            return newList;
        }
        #endregion
        public virtual  List<GoodsCategoryComponentResponse> GetChildren(int parentId)
        {
            var list=  _repository.GetWhere(w=>w.ParentId==parentId);
            var newList=list.Select(m => new GoodsCategoryComponentResponse()
            {
                value = m.Id,
                label = m.CategoryName.IsNull(m.CategoryName),
                Children = GetChildren(m.Id)
            }).ToList();
            return newList;
        }
    }
}
