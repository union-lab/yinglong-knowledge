﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Request;
using Youlian.Domain.Response.MallSetting;
using Youlian.Domain.Response;
using Youlian.Domain.Entities;

namespace Youlian.Services.Abstractions
{
    public interface IShopService : IBaseService
    {
        Task<PageResponse<ShopPageResponse>> GetResponseList(ShopPageRequest param);
        Task<Result<Shop>> AddOrEdit(ShopRequest param);
        Task<Result<int>> Delete(int id);
    }
}
