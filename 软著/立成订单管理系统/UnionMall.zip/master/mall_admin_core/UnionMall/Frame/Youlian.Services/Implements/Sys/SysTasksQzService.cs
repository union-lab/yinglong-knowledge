﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using Youlian.Tasks;
using System;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Response;
using Youlian.Domain.Request.Sys;
using Quartz;
using Mapster;

namespace Youlian.Services.Implements
{
    public class SysTasksQzService : BaseService, ISysTasksQzService
    {
        private readonly IRepository<SysTasksQz> _repository;
        private readonly ITaskSchedulerServer _schedulerServer;
        public SysTasksQzService(
            IRepository<SysTasksQz> repository,
            ITaskSchedulerServer schedulerServer)
        {
            _repository = repository;
            _schedulerServer = schedulerServer;
        }

        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual async Task<SysTasksQz> GetInfo(int id)
        {
            return await _repository.GetByIdAsync(id);
        }
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<SysTasksQz>> GetPageList(SysTasksPageRequest param)
        {
            Expression<Func<SysTasksQz, bool>> lambda = m => true;
            if (!string.IsNullOrEmpty(param.KeyWord)) lambda = lambda.And(m => m.Name.Contains(param.KeyWord));
            var list = await _repository.GetPagesAsync(lambda, param);
            return list;
        }
        #endregion

        #region 添加任务
        /// <summary>
        /// 添加任务
        /// </summary>
        /// <returns></returns>
        public async Task<Result<int>> Create(SysTasksQz param)
        {
            var result = new Result<int>();
            //判断是否已经存在
            if (_repository.Any(m => m.Name == param.Name))
            {
                return result.Bad($"添加 {param.Name} 失败，该用任务存在，不能重复！");
            }
            if (!string.IsNullOrEmpty(param.Cron) && !CronExpression.IsValidExpression(param.Cron))
            {
                return result.Bad($"cron表达式不正确");
            }
            if (param.TaskType == 2)
            {
                return result.Bad($"暂不支持添加网络请求");
            }
            if (string.IsNullOrEmpty(param.ApiUrl) && param.TaskType == 2)
            {
                return result.Bad($"地址不能为空");
            }
            if (param.TaskType == 1 && (string.IsNullOrEmpty(param.AssemblyName) || string.IsNullOrEmpty(param.ClassName)))
            {
                return result.Bad($"程序集或者类名不能为空");
            }
            var tasksQz = param.Adapt<SysTasksQz>();
            param.IsStart = false;

            if (!string.IsNullOrEmpty(tasksQz.ApiUrl) && tasksQz.TaskType == 2)
            {
                param.AssemblyName = "Youlian.Services";
                param.ClassName = "TaskScheduler.Job_HttpRequest";
            }
            await _repository.InsertAsync(tasksQz);
            return ResultHelper.Ok();
        }
        #endregion

        #region 更新任务
        /// <summary>
        /// 更新任务
        /// </summary>
        /// <returns></returns>
        public async Task<Result<int>> Update(SysTasksQz param)
        {
            var result = new Result<int>();
            //判断是否已经存在
            if (_repository.Any(m => m.Name == param.Name && m.Id != param.Id))
            {
                return result.Bad($"更新 {param.Name} 失败，该用任务存在，不能重复！");
            }
            if (string.IsNullOrEmpty(param.Cron) && param.TriggerType == 1)
            {
                return result.Bad($"触发器 Corn 模式下，运行时间表达式必须填写");
            }
            if (!string.IsNullOrEmpty(param.Cron) && !CronExpression.IsValidExpression(param.Cron))
            {
                return result.Bad($"cron表达式不正确");
            }
            var tasksQz = _repository.GetFirst(m => m.Id == param.Id);
            if (string.IsNullOrEmpty(param.ApiUrl) && param.TaskType == 2)
            {
                return result.Bad($"api地址不能为空");
            }
            if (!string.IsNullOrEmpty(param.ApiUrl) && param.TaskType == 2)
            {
                param.AssemblyName = "Tasks";
                param.ClassName = "TaskScheduler.Job_HttpRequest";
            }
            if (tasksQz.IsStart)
            {
                return result.Bad($"该任务正在运行中，请先停止在更新");
            }
            var model = param.Adapt<SysTasksQz>();
            model.ModifyTime = DateTime.Now;
            var isSuccess= await _repository.UpdateAsync(model)>0;
            if (isSuccess)
            {
                return await _schedulerServer.UpdateTaskAsync(tasksQz);
            }
            return ResultHelper.Ok();
        }
        #endregion

        #region 删除任务
        /// <summary>
        /// 删除任务
        /// </summary>
        /// <returns></returns>
        public async Task<Result<int>> Delete(int? id)
        {
            var result = new Result<int>();
            if (!id.HasValue)
            {
                return result.Bad("删除任务 Id 不能为空");
            }

            if (!_repository.Any(m => m.Id == id))
            {
                return result.Bad("任务不存在");
            }

            var tasksQz = _repository.GetFirst(m => m.Id == id);
            var taskResult = await _schedulerServer.DeleteTaskAsync(tasksQz);

            if (taskResult.OK)
            {
                _repository.Delete(id.Value);
            }
            return result.Ok();
        }
        #endregion

        #region 启动任务
        /// <summary>
        /// 启动任务
        /// </summary>
        /// <returns></returns>
        public async Task<Result<int>> Start(int? id)
        {
            var result = new Result<int>();
            if (!id.HasValue)
            {
                return result.Bad("启动任务 Id 不能为空");
            }

            if (!_repository.Any(m => m.Id == id))
            {
                return result.Bad("任务不存在");
            }

            var tasksQz = _repository.GetFirst(m => m.Id == id);
            var taskResult = await _schedulerServer.AddTaskAsync(tasksQz);

            if (taskResult.OK)
            {
                tasksQz.IsStart = true;
                _repository.Update(tasksQz);
            }

            return taskResult;
        }
        #endregion

        #region 停止任务
        /// <summary>
        /// 停止任务
        /// </summary>
        /// <returns></returns>
        public async Task<Result<int>> Stop(int? id)
        {
            var result = new Result<int>();
            if (!id.HasValue)
            {
                return result.Bad("停止任务 Id 不能为空");
            }

            if (!_repository.Any(m => m.Id == id))
            {
                return result.Bad("任务不存在");
            }

            var tasksQz = _repository.GetFirst(m => m.Id == id);
            var taskResult = await _schedulerServer.DeleteTaskAsync(tasksQz);

            if (taskResult.OK)
            {
                tasksQz.IsStart = false;
                _repository.Update(tasksQz);
            }

            return taskResult;
        }
        #endregion

        #region 定时任务立即执行一次
        /// <summary>
        /// 定时任务立即执行一次
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<Result<int>> Run(int? id)
        {
            var result = new Result<int>();
            if (!_repository.Any(m => m.Id == id))
            {
                return result.Bad("任务不存在");
            }
            var tasksQz = _repository.GetFirst(m => m.Id == id);
            var taskResult = await _schedulerServer.RunTaskScheduleAsync(tasksQz);

            return taskResult;
        }
        #endregion

        #region 更新时间
        /// <summary>
        /// 更新时间
        /// </summary>
        /// <returns></returns>
        public async Task<bool> UpdateRunInfo(int id)
        {
            return await _repository.Updateable.SetColumns(it => it.RunTimes == it.RunTimes + 1).SetColumns(it => it.LastRunTime == DateTime.Now).Where(it => it.Id == id).ExecuteCommandAsync() > 0;
        }
        #endregion
    }
}
