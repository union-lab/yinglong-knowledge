﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Domain.Response;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;

namespace Youlian.Services.Abstractions
{
    public interface INoticeService : IBaseService
    {
        #region 获取公告信息
        /// <summary>
        /// 获取公告信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Notice> GetInfo(int id);
        #endregion

        #region 获取公告列表
        /// <summary>
        /// 获取公告列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<List<Notice>> GetList(SystemClientEnum? client, bool? isTopShow = null);
        /// <summary>
        /// 获取公告列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<PageResponse<Notice>> GetPageList(NoticePageRequest param);
        #endregion

        #region 添加修改公告
        /// <summary>
        /// 添加修改公告
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<int>> Edit(EditNoticeRequest param);
        #endregion

        #region 删除公告
        /// <summary>
        /// 删除公告
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Result<int>> Delete(int id);
        #endregion
    }
}