﻿using Mapster;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Domain.Request.GoodsCategory;
using Youlian.Domain.Request.GoodsComment;
using Youlian.Domain.Response;
using Youlian.Repository;
using Youlian.Services.Abstractions;

namespace Youlian.Services.Implements
{
    public class GoodsCommentService : BaseService, IGoodsCommentService
    {
        private readonly IRepository<GoodsComment> _repository;
        private readonly IRepository<User> _userRepository;
        public GoodsCommentService(IRepository<GoodsComment> repository,
            IRepository<User> userRepository)
        {
            _repository = repository;
            _userRepository = userRepository;
        }
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<PageResponse<GoodsCommentPageResponse>> GetResponseList(GoodsCommentPageRequest param)
        {
            Expression<Func<GoodsComment, bool>> lambda = m => true;
            if (param.Score.HasValue)
            {
                lambda = lambda.And(w => w.Score == param.Score);
            }
            if (!string.IsNullOrEmpty(param.GoodsName))
            {
                //根据商品名称获取商品id
                var goodsId = 0;
                lambda = lambda.And(w => w.GoodsId == goodsId);
            }
            if (param.IsDisplay.HasValue)
            {
                lambda = lambda.And(w => w.IsDisplay == param.IsDisplay);
            }
            var list = await _repository.GetPagesAsync(lambda, param);
            var newList = list.Adapt<PageResponse<GoodsCommentPageResponse>>();
            //var goodsList=
            var userInfoList = await _userRepository.GetWhereAsync(w => w.Deleted == 0);
            foreach (var item in newList.Data)
            {
                var userInfo = userInfoList.Where(w => w.Id == item.UserId).FirstOrDefault();
                item.UserImage = userInfo.Avatar;
                item.UserNick = userInfo.NickName;
                item.UserPhone = userInfo.UserName;
                item.GoodsName = "";
            }
            return newList;
            //if (!string.IsNullOrEmpty(param.SkuName))
            //    lambda = lambda.And(w => w.SkuName.Contains(param.SkuName));
            //var list = await _repository.GetPagesAsync(lambda, param);
            //var newList = list.Adapt<PageResponse<GoodsSkuModelPageResponse>>();
            //var GoodsSkuModelValueList = await _GoodsSkuModelValueRepository.GetAllAsync();
            //foreach (var item in newList.Data)
            //{
            //    item.GoodsSkuModelValues = GoodsSkuModelValueList.Where(w => w.SpecId == item.Id).ToList().Adapt<List<GoodsSkuModelValueResponse>>();
            //}
            //return null;
        }


        #region 更新展示状态
        public async Task<Result<string>> UpdataStatus(UpdataGoodsCommentStatusRequest param)
        {
            var result = ResultHelper.Bad<string>(string.Empty);
            var model = await _repository.GetByIdAsync(param.Id);
            if (model == null)
            {
                return result.Bad("找不到对应消息");
            }
            model.IsDisplay = param.IsDisplay.Value;
            model.ModifyTime = DateTime.Now;
            return await _repository.UpdateAsync(model) > 0 ? result.Ok("更改成功") : result.Bad("更改失败");
        }
        #endregion

        #region 商家回复
        public async Task<Result<string>> EditSellerContent(UpdataGoodsCommentSellerContentRequest param)
        {
            var result = ResultHelper.Bad<string>(string.Empty);
            var model = await _repository.GetByIdAsync(param.Id);
            if (model == null)
            {
                return result.Bad("找不到对应消息");
            }
            model.SellerContent = param.SellerContent;
            model.ModifyTime = DateTime.Now;
            return await _repository.UpdateAsync(model) > 0 ? result.Ok("更改成功") : result.Bad("更改失败");
        }
        #endregion
        #region 删除记录
        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public virtual async Task<Result<int>> Deletes(int id)
        {
            var isSuccess = false;
            try
            {
                isSuccess = await _repository.DeleteAsync(id) > 0;
            }
            catch (Exception e)
            {
                isSuccess = false;
            }
            return isSuccess ? ResultHelper.Ok() : ResultHelper.Bad("删除失败");
        }
        #endregion

    }
}
