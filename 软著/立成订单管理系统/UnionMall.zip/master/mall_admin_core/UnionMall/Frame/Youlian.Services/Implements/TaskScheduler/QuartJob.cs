﻿using log4net;
using Quartz;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Youlian.Common.Helpers;

namespace Youlian.Services.Implements
{
    #region 数据同步
    [DisallowConcurrentExecution]
    public class SystemDataSyncJob : BaseJob
    {
        private readonly IWorkWeixinService _workWeixinService;
        public SystemDataSyncJob(IWorkWeixinService workWeixinService)
        {
            _workWeixinService = workWeixinService;
        }
        protected override Task ExecuteJob(IJobExecutionContext context)
        {
            if (!AppSettings.IsDevelopment)
            {
                _workWeixinService.ReExcuteNotify();
            }
            return Task.CompletedTask;
        }
    }
    #endregion
    //#region 发送问卷调查
    //[DisallowConcurrentExecution]
    //public class SendQuestionJob : BaseJob
    //{
    //    private readonly IQuestionService _questionService;
    //    public SendQuestionJob(
    //        IQuestionService questionService)
    //    {
    //        _questionService = questionService;
    //    }
    //    protected override async Task ExecuteJob(IJobExecutionContext context)
    //   {
    //        if (!AppSettings.IsDevelopment)
    //        {
    //            await _questionService.SendMsg();
    //        }
    //        else
    //        {
    //            await _questionService.SendMsg();
    //        }
    //    }
    //}
    //#endregion
}
