﻿using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using System.Threading.Tasks;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;

namespace Youlian.Services.Abstractions
{
    public interface ISysTasksQzService : IBaseService
    {
        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<SysTasksQz> GetInfo(int id);
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<PageResponse<SysTasksQz>> GetPageList(SysTasksPageRequest param);
        #endregion

        #region 添加任务
        /// <summary>
        /// 添加任务
        /// </summary>
        /// <returns></returns>
        Task<Result<int>> Create(SysTasksQz param);
        #endregion

        #region 更新任务
        /// <summary>
        /// 更新任务
        /// </summary>
        /// <returns></returns>
        Task<Result<int>> Update(SysTasksQz param);
        #endregion

        #region 删除任务
        /// <summary>
        /// 删除任务
        /// </summary>
        /// <returns></returns>
        Task<Result<int>> Delete(int? id);
        #endregion

        #region 启动任务
        /// <summary>
        /// 启动任务
        /// </summary>
        /// <returns></returns>
        Task<Result<int>> Start(int? id);
        #endregion

        #region 停止任务
        /// <summary>
        /// 停止任务
        /// </summary>
        /// <returns></returns>
        Task<Result<int>> Stop(int? id);
        #endregion

        #region 定时任务立即执行一次
        /// <summary>
        /// 定时任务立即执行一次
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Result<int>> Run(int? id);
        #endregion

        #region 更新时间
        /// <summary>
        /// 更新时间
        /// </summary>
        /// <returns></returns>
        Task<bool> UpdateRunInfo(int id);
        #endregion
    }
}