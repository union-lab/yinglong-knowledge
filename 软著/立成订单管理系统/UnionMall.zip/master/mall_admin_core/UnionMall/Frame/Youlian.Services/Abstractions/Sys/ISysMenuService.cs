﻿using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Youlian.Services.Abstractions
{
    public interface ISysMenuService : IBaseService
    {
        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<SysMenu> GetInfo(int id);
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<List<SysMenu>> GetList(SysMenuListRequest param);
        #endregion

        #region 编辑菜单
        /// <summary>
        /// 编辑菜单
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<int>> Edit(EditSysMenuRequest param);
        #endregion

        #region 删除菜单
        /// <summary>
        /// 删除菜单
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Result<int>> Delete(int id);
        #endregion

        #region 权限
        /// <summary>
        /// 根据权限标识获取菜单id（从缓存中）
        /// </summary>
        /// <param name="permissions"></param>
        /// <returns></returns>
        Task<int[]> GetMenuIdsByPermission(string permissions);
        #endregion

        #region 根据角色列表获取权限
        /// <summary>
        /// 根据角色列表获取权限
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<List<SysMenuListResponse>> GetMenuList(List<int> roleIds);
        #endregion
    }
}