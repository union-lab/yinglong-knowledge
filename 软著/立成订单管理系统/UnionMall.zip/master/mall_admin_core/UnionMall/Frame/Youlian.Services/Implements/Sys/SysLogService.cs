﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Domain.Response;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Models.Basics;
using Youlian.SDK.Weixin.Work;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;

namespace Youlian.Services.Implements
{
    public class SysLogService : BaseService, ISysLogService
    {
        private readonly ICacheManager _cache;
        private readonly IRepository<SysLog> _repository;
        private readonly IConfigService _configService;
        public SysLogService(ICacheManager cache, 
            IRepository<SysLog> repository,
            IConfigService configService)
        {
            _cache = cache;
            _repository = repository;
            _configService = configService;
        }

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public async Task<PageResponse<SysLog>> GetPageList(SysLogPageRequest param)
        {
            Expression<Func<SysLog, bool>> lambda = n => true;
            if (!string.IsNullOrEmpty(param.UserName))
            {
                lambda = lambda.And(n => n.UserName.Contains(param.UserName));
            }
            if (param.LogType.HasValue)
            {
                lambda = lambda.And(n => n.LogType == param.LogType);
            }
            if (param.StartTime != null)
            {
                lambda = lambda.And(n => n.AddTime >= param.StartTime);
            }
            if (param.EndTime != null)
            {
                lambda = lambda.And(n => n.AddTime <= param.EndTime);
            }
            var pageList = await _repository.GetPagesAsync(lambda, param);
            return pageList;
        }
        #endregion

        #region 添加登录日志
        /// <summary>
        /// 添加登录日志
        /// </summary>
        /// <param name="userTYpe"></param>
        /// <param name="userName"></param>
        /// <param name="logContent"></param>
        /// <param name="success"></param>
        /// <returns></returns>
        public async Task AddLoginLog(UserTypeEnum userType, string userName, string logContent, bool success = false)
        {
            await AddLog(userType ,userName, logContent, SysLogTypeEnum.用户登录);
            if (!success)
            {
                if (GetLoginFailTimes(userName) > 5)
                {
                    //禁用账户操作。。。
                }
            }
        }
        #endregion

        #region 登录失败次数
        /// <summary>
        /// 获取登录失败次数
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        private int GetLoginFailTimes(string userName)
        {
            var ip = IpHelper.GetLocalIp();
            string key = string.Format(CacheKeys.LoginFailTimes, userName, ip);
            var times = _cache.Get<int>(key);
            _cache.Set(key, times, TimeSpan.FromHours(1));
            return times;
        }

        /// <summary>
        /// 添加失败次数
        /// </summary>
        /// <param name="userName"></param>
        private void AddLoginFailTimes(string userName)
        {
            var ip = IpHelper.GetLocalIp();
            string key = string.Format(CacheKeys.LoginFailTimes, userName, ip);
            var times = _cache.Get<int>(key);
            _cache.Set(key, times + 1, TimeSpan.FromHours(1));
        }
        #endregion

        #region 添加日志
        /// <summary>
        /// 添加日志
        /// </summary>
        /// <param name="userType"></param>
        /// <param name="userName"></param>
        /// <param name="logContent"></param>
        /// <param name="logType"></param>
        /// <returns></returns>
        public async Task AddLog(UserTypeEnum userType, string userName, string logContent, SysLogTypeEnum logType)
        {
            await _repository.InsertAsync(new SysLog()
            {
                UserType = userType,
                LogType = logType,
                UserName = userName,
                IpAddress = IpHelper.GetLocalIp(),
                Content = logContent
            });
        }

        /// <summary>
        /// 保存系统日志
        /// </summary>
        public async Task AddSystemLog(SysLogTypeEnum logType, string title, string content, bool isNotifyAdmin = false)
        {
            var logContent = $"{title}:{content}";
            try
            {
                await _repository.InsertAsync(new SysLog()
                {
                    UserType = 0,
                    LogType = logType,
                    UserName = "System",
                    IpAddress = IpHelper.GetLocalIp(),
                    Content = logContent
                });
            }
            catch
            {

            }
            if (isNotifyAdmin)
            {
                var userName = (await _configService.GetConfig<SystemSetting>()).Manager;
                if (!string.IsNullOrEmpty(userName))
                {
                    _ = WorkWeixinApi.SendTextMessage(AppTypeEnum.友联APP, new List<string>() { userName }, logContent);
                }
            }
        }
        #endregion
    }
}
