﻿using Youlian.Common.Extention;
using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Repository;
using Youlian.Services.Abstractions;
using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Request;
using Youlian.Common.Cache;
using Youlian.Domain.Response;
using Microsoft.AspNetCore.Http;
using Youlian.SDK.Weixin.Work.Models;
using Microsoft.Extensions.Logging;
using Youlian.SDK.Weixin.Work;
using Mapster;
using Youlian.SDK;
using Youlian.Domain.Models.Basics;
using System.Linq.Expressions;
using System.Collections.Generic;
using System.Linq;

namespace Youlian.Services.Implements
{
    /// <summary>
    /// 企业微信通讯录服务
    /// </summary>
    public class WorkContactService : BaseService, IWorkContactService
    {
        private readonly ILogger<IWorkContactService> _logger;
        private readonly ICacheManager _cache;
        private readonly IConfigService _configService;
        private readonly IUserService _userService;

        public WorkContactService(ILogger<IWorkContactService> logger,
            ICacheManager cache,
            IConfigService configService,
            IUserService userService
            )
        {
            _logger = logger;
            _cache = cache;
            _configService = configService;
        }


        


        #region 微信通讯录缓存
        /// <summary>
        /// 获取部门列表缓存
        /// </summary>
        /// <returns></returns>
        public virtual async Task<DepartmentListResult> GetDepartmentListCacheAsync()
        {
            var key = CacheKeys.WorkWeixinDepartment;
            var result = _cache.Get<DepartmentListResult>(key);
            if (result != null)
            {
                return result;
            }
            result = await SDK.Weixin.Work.WorkWeixinApi.GetDepartmentListAsync();
            if (result.Success)
            {
                _cache.Set(key, result, TimeSpan.FromDays(1));
            }
            return result;
        }
        /// <summary>
        /// 清除部门列表缓存
        /// </summary>
        public virtual void ClearDepartmentListCache()
        {
            var key = CacheKeys.WorkWeixinDepartment;
            _cache.Remove(key);
        }
        /// <summary>
        /// 获取员工列表缓存
        /// </summary>
        /// <returns></returns>
        public virtual async Task<UserListResult> GetEmployeeListCacheAsync()
        {
            var key = CacheKeys.WorkWeixinUserList;
            var result = _cache.Get<UserListResult>(key);
            if (result != null)
            {
                return result;
            }
            result = await SDK.Weixin.Work.WorkWeixinApi.GetUserListAsync(AppTypeEnum.通讯录);
            if (result.Success)
            {
                _cache.Set(key, result, TimeSpan.FromDays(1));
            }
            return result;
        }
        /// <summary>
        /// 清除员工列表缓存
        /// </summary>
        public virtual void ClearEmployeeListCache()
        {
            var key = CacheKeys.WorkWeixinUserList;
            _cache.Remove(key);
        }

        /// <summary>
        /// 获取员工信息缓存
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public virtual async Task<UserInfoResult> GetEmployeeInfoCacheAsync(string userId)
        {
            var key = string.Format(CacheKeys.WorkWeixinUserInfo, userId);
            var result = _cache.Get<UserInfoResult>(key);
            if (result != null)
            {
                return result;
            }
            result = await SDK.Weixin.Work.WorkWeixinApi.GetUserInfoAsync(0, userId);
            if (result.Success)
            {
                _cache.Set(key, result, TimeSpan.FromMinutes(30));
            }
            return result;
        }
        /// <summary>
        /// 清除员工信息缓存
        /// </summary>
        public virtual void ClearEmployeeInfoCache(string userId)
        {
            var key = string.Format(CacheKeys.WorkWeixinUserInfo, userId);
            _cache.Remove(key);
        }

        public Task<Result<string>> ChangeEvent(string data)
        {
            throw new NotImplementedException();
        }
        #endregion


    }
}
