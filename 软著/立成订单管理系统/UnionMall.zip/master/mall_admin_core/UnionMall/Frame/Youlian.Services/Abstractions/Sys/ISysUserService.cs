﻿using Youlian.Domain.Entities;
using Youlian.Domain.Enums;
using Youlian.Domain.Request;
using Youlian.Domain.Request.Sys;
using Youlian.Domain.Response;
using System.Collections.Generic;
using System.Threading.Tasks;
using Youlian.Common.Helpers;

namespace Youlian.Services.Abstractions
{
    public interface ISysUserService : IBaseService
    {
        #region 获取信息
        /// <summary>
        /// 获取信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<SysUser> GetInfo(int id);
        #endregion

        #region 获取列表
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<PageResponse<SysUser>> GetPageList(SysUserPageRequest param);
        #endregion

        #region 编辑用户
        /// <summary>
        /// 编辑用户
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<SysUser>> Edit(EditSysUserRequest param);
        #endregion

        #region 删除用户
        /// <summary>
        /// 删除用户
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Result<int>> Delete(int id);
        #endregion

        #region 启用禁用
        /// <summary>
        /// 启用禁用
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Result<int>> SetActive(int id, ActiveEnum active);
        #endregion

        #region 修改密码
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Result<int>> UpdatePassword(UpdateSysUserPasswordRequest param);
        #endregion

        #region 系统用户登录
        /// <summary>
        /// 系统用户登录
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        Task<Result<SysUser>> Login(SysUserLoginRequest param);
        #endregion

        #region 获取用户角色
        /// <summary>
        /// 获取用户所属角色（从缓存中）
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        int[] GetRolesByUserId(int userId);

        /// <summary>
        /// 获取用户所属角色名称（从缓存中）
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        List<string> GetRoleNamesByUserId(int userId);

        void ClearRolesCache(int userId);
        #endregion

        #region 获取用户菜单
        /// <summary>
        /// 获取用户菜单
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        Task<List<SysMenu>> GetMenuList(int userId);
        #endregion

        Task<Result<SysUser>> WorkWeixinLogin(WorkWeixinSsoCallbackRequest param);
    }
}