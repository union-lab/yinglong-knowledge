﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;
using Youlian.Domain.Request;
using Youlian.Domain.Response;

namespace Youlian.Services.Abstractions
{
    public interface IGoodsServiceModelService : IBaseService
    {
        Task<Result<GoodsServiceModel>> AddOrEdit(GoodsServiceModelRequest param);
        Task<Result<int>> Deletes(List<int> ids);
        Task<PageResponse<GoodsServiceModelPageResponse>> GetResponseList(GoodsServiceModelPageRequest param);
    }
}