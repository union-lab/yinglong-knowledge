﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Helpers;
using Youlian.Domain.Entities;

namespace Youlian.Tasks
{
	/// <summary>
	/// 服务调度接口
	/// </summary>
	public interface ITaskSchedulerServer
	{
		/// <summary>
		/// 开启计划任务
		/// </summary>
		/// <returns></returns>
		Task<Result<int>> StartAsync();

		/// <summary>
		/// 停止计划任务
		/// </summary>
		/// <returns></returns>
		Task<Result<int>> StopAsync();

		/// <summary>
		/// 添加一个计划任务
		/// </summary>
		/// <param name="tasksQz"></param>
		/// <returns></returns>
		Task<Result<int>> AddTaskAsync(SysTasksQz tasksQz);

		/// <summary>
		/// 暂停指定的计划任务
		/// </summary>
		/// <param name="tasksQz"></param>
		/// <returns></returns>
		Task<Result<int>> PauseTaskAsync(SysTasksQz tasksQz);

		/// <summary>
		/// 恢复指定计划任务
		/// </summary>
		/// <param name="tasksQz"></param>
		/// <returns></returns>
		Task<Result<int>> ResumeTaskAsync(SysTasksQz tasksQz);

		/// <summary>
		/// 删除指定计划任务
		/// </summary>
		/// <param name="tasksQz"></param>
		/// <returns></returns>
		Task<Result<int>> DeleteTaskAsync(SysTasksQz tasksQz);

		/// <summary>
		/// 立即运行
		/// </summary>
		/// <param name="tasksQz"></param>
		/// <returns></returns>
		Task<Result<int>> RunTaskScheduleAsync(SysTasksQz tasksQz);

		/// <summary>
		/// 更新计划任务
		/// </summary>
		/// <param name="tasksQz"></param>
		/// <returns></returns>
		Task<Result<int>> UpdateTaskAsync(SysTasksQz tasksQz);
	}
}
