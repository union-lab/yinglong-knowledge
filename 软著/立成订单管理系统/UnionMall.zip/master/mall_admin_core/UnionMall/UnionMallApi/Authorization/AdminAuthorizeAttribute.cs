﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using Microsoft.AspNetCore.Http;
using Youlian.Common.Extention;
using Youlian.Domain.Enums;
using Youlian.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;

namespace UnionMallApi
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class AdminAuthorizeAttribute : AuthorizeAttribute
    {
        const string POLICY_PREFIX = PermissionPolicyProvider.POLICY_PREFIX;

        public AdminAuthorizeAttribute(string permissionName = null, params ActionEnum[] actions)
        {
            PermissionName = permissionName;
            Actions = actions?.Length > 0 ? actions : new[] { ActionEnum.View };
        }
        private string _PermissionName { get; set; }
        public string PermissionName
        {
            get
            {
                return _PermissionName;
            }
            set
            {
                _PermissionName = value;
                SetPolicyValue();
            }
        }
        private ActionEnum[] _Actions { get; set; }

        public ActionEnum[] Actions
        {
            get
            {
                return _Actions;
            }
            set
            {
                _Actions = value;
                SetPolicyValue();
            }
        }

        public void SetPolicyValue()
        {
            Policy = $"{POLICY_PREFIX}{PermissionName}:{_Actions?.Select(m => (int)m).ToJoinStr()}";
        }
    }
}
