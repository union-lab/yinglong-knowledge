﻿using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Youlian.Common.Extention;
using Youlian.Services.Abstractions;
using Youlian.Services.Implements;

namespace UnionMallApi
{
    /// <summary>
    /// 授权策略处理类
    /// </summary>
    public class PermissionRequirementHandler : AuthorizationHandler<PermissionRequirement>
    {
        private readonly IPermissionService _permissionService;
        private readonly AuthenticationDataManager _authenticationDataManager;
        public PermissionRequirementHandler(IPermissionService permissionService, AuthenticationDataManager authenticationDataManager)
        {
            _permissionService = permissionService;
            _authenticationDataManager = authenticationDataManager;
        }
        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionRequirement requirement)
        {
            var user = _authenticationDataManager.CurrentUser;
            if (user == null || user.UserType != Youlian.Domain.Enums.UserTypeEnum.管理员)
            {
                return;
            }
            if (string.IsNullOrEmpty(requirement.PermissionName))
            {
                if (context.User.Identity.IsAuthenticated)
                {
                    context.Succeed(requirement);
                }
                return;
            }
            if (user.UserName.ToLower() == "admin")
            {
                context.Succeed(requirement);
                return;
            }
            if (!await _permissionService.HasPermission(user.Id, requirement.PermissionName, requirement.Actions.ToArray()))
            {
                return;
            }
            context.Succeed(requirement);
        }
    }
}
