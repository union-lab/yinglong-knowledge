﻿using Microsoft.AspNetCore.Authorization;

namespace UnionMallApi
{
    /// <summary>
    /// 
    /// </summary>
    public class PermissionRequirement : IAuthorizationRequirement
    {
        public string PermissionName { get; }
        public List<int> Actions { get; set; }

        public PermissionRequirement(string PermissionName, List<int> Actions = null)
        {
            this.PermissionName = PermissionName;
            this.Actions = Actions;
        }
    }
}
