﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using Microsoft.AspNetCore.Mvc.Controllers;
using System.Net;
using System.Security.Claims;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Services.Abstractions;

namespace UnionMallApi
{
    /// <summary>
    /// 授权策略
    /// </summary>
    internal class PermissionPolicyProvider : IAuthorizationPolicyProvider
    {
        public const string POLICY_PREFIX = "Permission.";
        public Task<AuthorizationPolicy> GetDefaultPolicyAsync()
        {
            return Task.FromResult(new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build());
        }

        public Task<AuthorizationPolicy> GetPolicyAsync(string policyName)
        {
            if (policyName.StartsWith(POLICY_PREFIX, System.StringComparison.OrdinalIgnoreCase))
            {
                var policy = new AuthorizationPolicyBuilder();
                var arr = policyName.Substring(POLICY_PREFIX.Length).Split(':');
                policy.AddRequirements(new PermissionRequirement(arr[0], arr[1].ToIntArr().ToList()));
                return Task.FromResult(policy.Build());
            }
            return Task.FromResult<AuthorizationPolicy>(null);
        }

        public Task<AuthorizationPolicy> GetFallbackPolicyAsync()
        {
            return Task.FromResult(new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build());
        }
    }
}
