﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;

namespace UnionMallApi
{
    /// <summary>
    /// 自定义授权结果中间件
    /// </summary>
    public class CustomAuthorizationMiddlewareResultHandler : IAuthorizationMiddlewareResultHandler
    {
        private readonly AuthorizationMiddlewareResultHandler defaultHandler = new();
        public async Task HandleAsync(RequestDelegate next, HttpContext context, AuthorizationPolicy policy, PolicyAuthorizationResult authorizeResult)
        {
            if (authorizeResult.Forbidden && authorizeResult.AuthorizationFailure!.FailedRequirements.OfType<PermissionRequirement>().Any())
            {
                var failedItem = authorizeResult.AuthorizationFailure!.FailedRequirements.OfType<PermissionRequirement>().FirstOrDefault();
                await context.Response.WriteAsJsonAsync(ResultHelper.Ret(StatusCodeEnum.Forbidden, $"无权操作：{failedItem.PermissionName}:{failedItem.Actions.ToJoinStr()}"));
                return;
            }

            await defaultHandler.HandleAsync(next, context, policy, authorizeResult);
        }
    }
}
