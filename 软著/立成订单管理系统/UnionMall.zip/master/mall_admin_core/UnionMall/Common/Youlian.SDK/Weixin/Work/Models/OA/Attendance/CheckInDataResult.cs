﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;

namespace Youlian.SDK.Weixin.Work.Models.OA.Attendance
{
    /// <summary>
    /// 考勤机打卡记录
    /// </summary>
    public class CheckInDataResult : BaseResult
    {
        /// <summary>
        /// 
        /// </summary>
        public List<CheckInDataInfo>? CheckInData { get; set; }
    }

    /// <summary>
    /// 打卡记录
    /// </summary>
    public class CheckInDataInfo
    {
        public DateTime Time => Extention.ConvertToDateTime(CheckInTime);
        /// <summary>
        /// 用户id
        /// </summary>
        public string? UserId { get; set; }
        /// <summary>
        /// 打卡规则名称
        /// </summary>
        public string? GroupName { get; set; }
        /// <summary>
        /// 打卡类型。字符串，目前有：上班打卡，下班打卡，外出打卡
        /// </summary>
        [JsonProperty("checkin_type")]
        public string? CheckInType { get; set; }
        /// <summary>
        /// 异常类型，字符串，包括：时间异常，地点异常，未打卡，wifi异常，非常用设备。如果有多个异常，以分号间隔
        /// </summary>
        [JsonProperty("exception_type")]
        public string? ExceptionType { get; set; }
        /// <summary>
        /// 打卡时间。Unix时间戳
        /// </summary>
        [JsonProperty("checkin_time")]
        public int CheckInTime { get; set; }
        /// <summary>
        /// 打卡地点title
        /// </summary>
        [JsonProperty("location_title")]
        public string? LocationTitle { get; set; }
        /// <summary>
        /// 打卡地点详情
        /// </summary>
        [JsonProperty("location_detail")]
        public string? LocationDetail { get; set; }
        /// <summary>
        /// 打卡wifi名称
        /// </summary>
        public string? WifiName { get; set; }
        /// <summary>
        /// 打卡备注
        /// </summary>
        public string? Notes { get; set; }
        /// <summary>
        /// 打卡的MAC地址/bssid
        /// </summary>
        public string? WifiMac { get; set; }
        /// <summary>
        /// 打卡的附件media_id，可使用media/get获取附件
        /// </summary>
        public List<string>? MediaIds { get; set; }
        /// <summary>
        /// 位置打卡地点纬度，是实际纬度的1000000倍，与腾讯地图一致采用GCJ-02坐标系统标准
        /// </summary>
        public int Lat { get; set; }
        /// <summary>
        /// 位置打卡地点经度，是实际纬度的1000000倍，与腾讯地图一致采用GCJ-02坐标系统标准
        /// </summary>
        public int Lng { get; set; }
        /// <summary>
        /// 打卡设备id
        /// </summary>
        public string? DeviceId { get; set; }
        /// <summary>
        /// 标准打卡时间，指此次打卡时间对应的标准上班时间或标准下班时间
        /// </summary>
        [JsonProperty("sch_checkin_time")]
        public int SchCheckInTime { get; set; }
        /// <summary>
        /// 规则id，表示打卡记录所属规则的id
        /// </summary>
        public int GroupId { get; set; }
        /// <summary>
        /// 班次id，表示打卡记录所属规则中，所属班次的id
        /// </summary>
        [JsonProperty("schedule_id")]
        public int ScheduleId { get; set; }
        /// <summary>
        /// 时段id，表示打卡记录所属规则中，某一班次中的某一时段的id，如上下班时间为9:00-12:00、13:00-18:00的班次中，9:00-12:00为其中一组时段
        /// </summary>
        [JsonProperty("timeline_id")]
        public int TimeLineId { get; set; }
    }

}
