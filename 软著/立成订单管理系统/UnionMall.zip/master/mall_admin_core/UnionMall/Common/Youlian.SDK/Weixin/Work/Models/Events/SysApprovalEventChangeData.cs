﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.SDK.Weixin.Work.Models.Approval;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 审批事件回调数据
    /// </summary>
    public class SysApprovalEventChangeData: EventChangeData
    {
        /// <summary>
        /// 
        /// </summary>
        public string? AgentID { get; set; }
        /// <summary>
        /// ApprovalInfo
        /// </summary>
        public ApprovalEventInfo? ApprovalInfo { get; set; }

    }
    public class ApprovalEventInfo : ApprovalDetail
    {
        /// <summary>
        /// 
        /// </summary>
        public string? StatuChangeEvent { get; set; }

    }
}
