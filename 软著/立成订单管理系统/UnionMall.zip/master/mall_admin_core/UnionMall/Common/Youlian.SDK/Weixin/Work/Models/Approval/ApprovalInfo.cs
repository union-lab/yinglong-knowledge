﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 审批内容
    /// </summary>
    public class ApprovalInfo : BaseResult
    {
        /// <summary>
        /// 
        /// </summary>
        public ApprovalDetail? Info { get; set; }
    }

    public class ApprovalDetail
    {
        /// <summary>
        /// 审批编号
        /// </summary>
        [JsonProperty("sp_no")]
        public string? SpNo { get; set; }
        /// <summary>
        /// 审批申请类型名称（审批模板名称）
        /// </summary>
        [JsonProperty("sp_name")]
        public string? SpName { get; set; }
        /// <summary>
        /// 申请单状态：1-审批中；2-已通过；3-已驳回；4-已撤销；6-通过后撤销；7-已删除；10-已支付
        /// </summary>
        [JsonProperty("sp_status")]
        public int SpStatus { get; set; }
        /// <summary>
        /// 审批模板id
        /// </summary>
        [JsonProperty("template_id")]
        public string? TemplateId { get; set; }
        /// <summary>
        /// 审批申请提交时间,Unix时间戳
        /// </summary>
        [JsonProperty("apply_time")]
        public long ApplyTime { get; set; }
        /// <summary>
        /// 申请人信息
        /// </summary>
        public Applyer? Applyer { get; set; }
        /// <summary>
        /// 审批流程信息
        /// </summary>
        [JsonProperty("sp_record")]
        public List<SpRecordItem>? SpRecord { get; set; }
        /// <summary>
        /// 抄送信息
        /// </summary>
        public List<SpNotifyer>? Notifyer { get; set; }
        /// <summary>
        /// 审批申请数据
        /// </summary>
        [JsonProperty("apply_data")]
        public ApplyData? ApplyData { get; set; }
        /// <summary>
        /// 审批申请备注信息
        /// </summary>
        public List<CommentsItem>? Comments { get; set; }
    }

    public class ApplyData
    {
        /// <summary>
        /// 审批申请详情
        /// </summary>
        public List<ContentsControl>? Contents { get; set; }
    }
}
