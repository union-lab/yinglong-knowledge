﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 成员控件
    /// </summary>
    public class MemberControlValue
    {
        public string UserId { get; set; }
        public string Name { get; set; }
    }
}
