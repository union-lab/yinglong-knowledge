﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 分支审批人
    /// </summary>
    public class Approver
    {
        /// <summary>
        /// 分支审批人userid
        /// </summary>
        public string UserId { get; set; }
    }
}
