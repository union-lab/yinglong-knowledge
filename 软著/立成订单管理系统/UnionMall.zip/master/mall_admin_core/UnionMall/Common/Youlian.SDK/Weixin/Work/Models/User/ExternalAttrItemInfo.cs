﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.User
{
    public class ExternalAttrItemInfo
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("type")]
        public int Type { get; set; }
        /// <summary>
        /// 文本名称
        /// </summary>
        [JsonProperty("name")]
        public string? Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("text")]
        public ExternalAttrItemTextInfo? Text { get; set; }
    }
}
