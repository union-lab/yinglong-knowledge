﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    public class SpRecordDetail
    {
        /// <summary>
        /// 分支审批人
        /// </summary>
        public Approver Approver { get; set; }
        /// <summary>
        /// 审批意见
        /// </summary>
        public string Speech { get; set; }
        /// <summary>
        /// 分支审批人审批状态：1-审批中；2-已同意；3-已驳回；4-已转审；11-已退回
        /// </summary>
        [JsonProperty("sp_status")]
        public int SpStatus { get; set; }
        /// <summary>
        /// 节点分支审批人审批操作时间戳，0表示未操作
        /// </summary>
        public int SpTime { get; set; }
        /// <summary>
        /// 节点分支审批人审批意见附件
        /// </summary>
        [JsonProperty("media_id")]
        public List<string> media_id { get; set; }
    }
}
