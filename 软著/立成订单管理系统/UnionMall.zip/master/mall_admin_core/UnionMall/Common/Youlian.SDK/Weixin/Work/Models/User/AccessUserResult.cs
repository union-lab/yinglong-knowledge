﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 访问用户授权信息
    /// </summary>
    public class AccessUserResult:BaseResult
    {
        /// <summary>
        /// 成员UserID
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 非企业成员的标识，对当前企业唯一
        /// </summary>
        public string OpenId { get; set; }
    }
}
