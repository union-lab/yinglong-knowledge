﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 日期组件
    /// </summary>
    public class DateControlValue
    {
        public string? Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("s_timestamp")]
        public int Timestamp { get; set; }

        public DateTime? Value => Type == "day" ? Extention.ConvertToDateTime(Timestamp) : null;
    }
}
