﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models.OA
{
    /// <summary>
    /// 成员假期余额
    /// </summary>
    public class VacationConfigResult : BaseResult
    {
        /// <summary>
        /// 假期列表
        /// </summary>
        public List<VacationConfigInfo>? Lists { get; set; }
    }
    public class VacationConfigQuotaAttr
    {
        /// <summary>
        /// 假期发放类型：0-不限额；1-自动发放；2-手动发放
        /// </summary>
        public int Type { get; set; }
        /// <summary>
        /// 自动发放时间戳，若假期发放为自动发放，此参数代表自动发放日期。注：返回时间戳的年份是无意义的，请只使用返回时间的月和日
        /// </summary>
        public int AutoresetTime { get; set; }
        /// <summary>
        /// 自动发放时长，单位为秒
        /// </summary>
        [JsonProperty("autoreset_duration")]
        public int AutoresetDuration { get; set; }
    }

    public class VacationConfigInfo
    {
        /// <summary>
        /// 假期id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 假期名称
        /// </summary>
        public string? Name { get; set; }
        /// <summary>
        /// 假期时间刻度：0-按天请假；1-按小时请假
        /// </summary>
        [JsonProperty("time_attr")]
        public int TimeAttr { get; set; }
        /// <summary>
        /// 时长计算类型：0-自然日；1-工作日
        /// </summary>
        [JsonProperty("duration_type")]
        public int DurationType { get; set; }
        /// <summary>
        /// 假期发放相关配置
        /// </summary>
        [JsonProperty("quota_attr")]
        public VacationConfigQuotaAttr? QuotaAttr { get; set; }
        /// <summary>
        /// 单位换算值，即1天对应的秒数，可将此值除以3600得到一天对应的小时。
        /// </summary>
        [JsonProperty("perday_duration")]
        public int PerdayDuration { get; set; }
    }

}
