﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.SDK.Weixin.Work.Models.User;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 更新部门事件回调数据
    /// </summary>
    public class ContactPartyEventChangeData : ContactEventChangeData
    {
        /// <summary>
        /// 部门Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 部门名称;代开发自建应用需要管理员授权才返回
        /// </summary>
        public string? Name { get; set; }

        /// <summary>
        /// 父部门id
        /// </summary>
        public int? ParentId { get; set; }

        /// <summary>
        /// 部门排序
        /// </summary>
        public int? Order { get; set; }
    }
}
