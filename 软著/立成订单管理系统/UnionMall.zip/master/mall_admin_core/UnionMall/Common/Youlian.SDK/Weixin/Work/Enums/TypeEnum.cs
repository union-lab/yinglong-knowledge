﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work
{
    public enum AppTypeEnum
    {
        通讯录 = 1,
        审批=2,
        考勤打卡=3,
        友联APP = 100
    }

    public enum UserStatusEnum
    {
        /// <summary>
        /// 已激活代表已激活企业微信或已关注微信插件（原企业号）
        /// </summary>
        已激活 = 1,
        禁用 = 2,
        /// <summary>
        /// 未激活代表既未激活企业微信又未关注微信插件（原企业号）。
        /// </summary>
        未激活 = 4,
        退出企业 = 5
    }

    /// <summary>
    /// 回调消息类型
    /// </summary>
    public enum MsgTypeEnum
    {
        Ohter,
        Event,
    }

    /// <summary>
    /// 事件类型
    /// </summary>
    public enum EventTypeEnum
    {
        Ohter,
        /// <summary>
        /// 审批回调
        /// </summary>
        sys_approval_change,
        /// <summary>
        /// 通讯录回调
        /// </summary>
        change_contact
    }


    /// <summary>
    /// 审批状态
    /// </summary>
    public enum SysApprovalStatusEnum
    {
        审批中 = 1,
        已通过 = 2,
        已驳回 = 3,
        已撤销 = 4,
        通过后撤销 = 6,
        已删除 = 7,
        已支付 = 10
    }
}
