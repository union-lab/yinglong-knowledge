﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 部门信息
    /// </summary>
    public class DepartmentInfo
    {
        /// <summary>
        /// ID
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 部门名称
        /// </summary>
        public string? Name { get; set; }
        /// <summary>
        /// 英文名称
        /// </summary>
        [JsonProperty("name_en")]
        public string? NameEn { get; set; }
        /// <summary>
        /// 部门负责人的UserID；第三方仅通讯录应用可获取
        /// </summary>
        [JsonProperty("department_leader")]
        public List<string>? DepartmentLeader { get;set; }
        /// <summary>
        /// 父部门id。根部门为1
        /// </summary>
        public int ParentId { get; set; }
        /// <summary>
        /// 在父部门中的次序值。order值大的排序靠前。值范围是[0, 2^32)
        /// </summary>
        public int Order { get; set; }

    }

    /// <summary>
    /// 部门列表获取结果
    /// </summary>
    public class DepartmentListResult : BaseResult
    {
        public List<DepartmentInfo>? Department { get; set; }
    }

    /// <summary>
    /// 部门详情获取结果
    /// </summary>
    public class DepartmentInfoResult : BaseResult
    {
        public DepartmentInfo Department { get; set; } = new DepartmentInfo();
    }
}
