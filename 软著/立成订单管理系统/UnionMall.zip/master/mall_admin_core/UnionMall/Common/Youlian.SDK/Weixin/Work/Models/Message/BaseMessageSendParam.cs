﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 消息参数
    /// </summary>
    public class BaseMessageSendParam
    {
        /// <summary>
        /// 成员ID列表（消息接收者，多个接收者用‘|’分隔，最多支持1000个）。特殊情况：指定为@all，则向关注该企业应用的全部成员发送
        /// </summary>
        [JsonProperty("touser")]
        public string? ToUser { get; set; }
        /// <summary>
        /// 部门ID列表，多个接收者用‘|’分隔，最多支持100个。当touser为@all时忽略本参数
        /// </summary>
        [JsonProperty("toparty")]
        public string? ToParty { get; set; }
        /// <summary>
        /// 标签ID列表，多个接收者用‘|’分隔，最多支持100个。当touser为@all时忽略本参数
        /// </summary>
        [JsonProperty("totag")]
        public string? ToTag { get; set; }
        /// <summary>
        /// 消息类型
        /// </summary>
        [JsonProperty("msgtype")]
        public string? MsgType { get; set; }
        /// <summary>
        /// 企业应用的id，整型。企业内部开发，可在应用的设置页面查看；第三方服务商，可通过接口 获取企业授权信息 获取该参数值
        /// </summary>
        [JsonProperty("agentid")]
        public int AgentId { get; set; }
        /// <summary>
        /// 表示是否开启id转译，0表示否，1表示是，默认0
        /// </summary>
        [JsonProperty("enable_id_trans")]
        public int EnableIdTrans { get; set; }
        /// <summary>
        /// 表示是否开启重复消息检查，0表示否，1表示是，默认0
        /// </summary>
        [JsonProperty("enable_duplicate_check")]
        public int EnableDuplicateCheck { get; set; }
        /// <summary>
        /// 表示是否重复消息检查的时间间隔，默认1800s，最大不超过4小时
        /// </summary>
        [JsonProperty("duplicate_check_interval")]
        public int DuplicateCheckInterval { get; set; }
    }}
