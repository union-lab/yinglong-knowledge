﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Youlian.SDK.Weixin.Work.Models.User;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 创建成员参数
    /// </summary>
    public class CreateUserParam
    {
        /// <summary>
        /// 成员UserID。对应管理端的帐号，企业内必须唯一。长度为1~64个字节。只能由数字、字母和“_-@.”四种字符组成，且第一个字符必须是数字或字母。系统进行唯一性检查时会忽略大小写。
        /// </summary>
        [JsonProperty("userid")]
        public string UserId { get; set; } = string.Empty;
        /// <summary>
        /// 成员名称。长度为1~64个utf8字符
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }=   string.Empty;
        /// <summary>
        /// 成员别名。长度1~64个utf8字符
        /// </summary>
        [JsonProperty("alias")]
        public string? Alias { get; set; }
        /// <summary>
        /// 手机号码。企业内必须唯一，mobile/email二者不能同时为空
        /// </summary>
        [JsonProperty("mobile")]
        public string Mobile { get; set; }=string.Empty;
        /// <summary>
        /// 成员所属部门id列表，不超过100个
        /// </summary>
        [JsonProperty("department")]
        public List<int> Department { get; set; }=new List<int>();
        /// <summary>
        /// 部门内的排序值，默认为0，成员次序以创建时间从小到大排列。个数必须和参数department的个数一致，数值越大排序越前面。有效的值范围是[0, 2^32)
        /// </summary>
        [JsonProperty("order")]
        public List<int>? Order { get; set; }
        /// <summary>
        /// 职务信息
        /// </summary>
        [JsonProperty("position")]
        public string? Position { get; set; }
        /// <summary>
        /// 性别。1表示男性，2表示女性
        /// </summary>
        [JsonProperty("gender")]
        public int? Gender { get; set; }
        /// <summary>
        /// Email
        /// </summary>
        [JsonProperty("email")]
        public string? Email { get; set; }
        /// <summary>
        /// 企业邮箱
        /// </summary>
        [JsonProperty("biz_mail")]
        public string? BizMail { get; set; }
        /// <summary>
        /// 个数必须和参数department的个数一致，表示在所在的部门内是否为部门负责人。1表示为部门负责人，0表示非部门负责人。在审批(自建、第三方)等应用里可以用来标识上级审批人
        /// </summary>
        [JsonProperty("is_leader_in_dept")]
        public List<int>? IsLeaderInDept { get; set; }
        /// <summary>
        /// 直属上级UserID，设置范围为企业内成员，可以设置最多5个上级
        /// </summary>
        [JsonProperty("direct_leader")]
        public List<string>? DirectLeader { get; set; }
        /// <summary>
        /// 启用/禁用成员。1表示启用成员，0表示禁用成员
        /// </summary>
        [JsonProperty("enable")]
        public int Enable { get; set; } = 1;
        /// <summary>
        /// 成员头像的mediaid
        /// </summary>
        [JsonProperty("avatar_mediaid")]
        public string? AvatarMediaid { get; set; }
        /// <summary>
        /// 座机
        /// </summary>
        [JsonProperty("telephone")]
        public string? Telephone { get; set; }
        /// <summary>
        /// 地址
        /// </summary>
        [JsonProperty("address")]
        public string? Address { get; set; }
        /// <summary>
        /// 主部门
        /// </summary>
        [JsonProperty("main_department")]
        public int MainDepartment { get; set; }
        /// <summary>
        /// 自定义字段
        /// </summary>
        [JsonProperty("extattr")]
        public ExtAttrInfo? ExtAttr { get; set; }
        /// <summary>
        /// 是否邀请该成员使用企业微信（将通过微信服务通知或短信或邮件下发邀请，每天自动下发一次，最多持续3个工作日），默认值为true。
        /// </summary>
        [JsonProperty("to_invite")]
        public bool ToInvite { get; set; } = true;
        /// <summary>
        /// 对外职务，如果设置了该值，则以此作为对外展示的职务，否则以position来展示。长度12个汉字内
        /// </summary>
        [JsonProperty("external_position")]
        public string? ExternalPosition { get; set; }
        /// <summary>
        /// 成员对外属性
        /// </summary>
        [JsonProperty("external_profile")]
        public ExternalProfileInfo? ExternalProfile { get; set; }
    }
}
