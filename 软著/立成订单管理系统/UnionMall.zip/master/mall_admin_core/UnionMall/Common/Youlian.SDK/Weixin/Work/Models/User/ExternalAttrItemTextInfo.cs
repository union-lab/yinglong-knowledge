﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.User
{
    public class ExternalAttrItemTextInfo
    {
        /// <summary>
        /// 文本
        /// </summary>
        [JsonProperty("value")]
        public string? Value { get; set; }
    }
}
