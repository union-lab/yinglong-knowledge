﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    public class ControlDateRang
    {
        /// <summary>
        /// 时间展示类型：halfday-日期；hour-日期+时间
        /// </summary>
        public string Type { get; set; }
        /// <summary>
        /// 开始时间
        /// </summary>
        [JsonProperty("new_begin")]
        public int NewBegin { get; set; }
        /// <summary>
        /// 结束时间
        /// </summary>
        [JsonProperty("new_end")]
        public int NewEnd { get; set; }
        /// <summary>
        /// 请假时长/出差/外出/加时长，单位秒
        /// </summary>
        [JsonProperty("new_duration")]
        public int NewDuration { get; set; }
    }
}
