﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    public class MessageSendResult:BaseResult
    {
        /// <summary>
        /// 不合法的userid，不区分大小写，统一转为小写，分割符“|”
        /// </summary>
        public string? InvalidUser { get; set; }
        /// <summary>
        /// 不合法的partyid
        /// </summary>
        public string? InvalidParty { get; set; }
        /// <summary>
        /// 不合法的标签id
        /// </summary>
        public string? InvalidTag { get; set; }
        /// <summary>
        /// 消息id，用于撤回应用消息
        /// </summary>
        public string? MsgId { get; set; }
        /// <summary>
        /// 仅消息类型为“按钮交互型”，“投票选择型”和“多项选择型”的模板卡片消息返回，应用可使用response_code调用更新模版卡片消息接口，24小时内有效，且只能使用一次
        /// </summary>
        [JsonProperty("response_code")]
        public string? ResponseCode { get; set; }

        /// <summary>
        /// 获取不合法UserId数量
        /// </summary>
        /// <returns></returns>
        public int GetInvalidUserCount()
        {
            return GetInvalidUserIds().Count;
        }
        /// <summary>
        /// 获取不合法UserId
        /// </summary>
        /// <returns></returns>
        public List<string> GetInvalidUserIds()
        {
            return InvalidUser?.Split('|').ToList() ?? new List<string>();
        }
    }
}
