﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.User
{
    public class ExternalProfileInfo
    {
        /// <summary>
        /// 企业简称
        /// </summary>
        [JsonProperty("external_corp_name")]
        public string? ExternalCorpName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("wechat_channels")]
        public WechatChannelsInfo? WechatChannels { get; set; }
        /// <summary>
        /// 成员对外属性，字段详情见对外属性；代开发自建应用需要管理员授权才返回；第三方仅通讯录应用可获取；对于非第三方创建的成员，第三方通讯录应用也不可获取；上游企业不可获取下游企业成员该字段
        /// </summary>
        [JsonProperty("external_attr")]
        public List<ExternalAttrItemInfo>? ExternalAttr { get; set; }
    }
}
