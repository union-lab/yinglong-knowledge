﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 获取登录Session
    /// </summary>
    public class Code2SessionResult : BaseResult
    {
        /// <summary>
        /// 用户在企业内的UserID，对应管理端的帐号，企业内唯一。注意：如果该企业没有关联该小程序，则此处返回加密的userid
        /// </summary>
        public string? UserId { get; set; }

        /// <summary>
        /// 用户所属企业的corpid
        /// </summary>
        public string? CorpId { get; set; }

        /// <summary>
        /// 会话密钥
        /// </summary>
        [JsonProperty("session_key")]
        public string? SessionKey { get; set; }
    }
}
