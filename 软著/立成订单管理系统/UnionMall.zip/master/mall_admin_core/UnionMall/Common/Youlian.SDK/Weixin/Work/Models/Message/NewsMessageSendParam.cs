﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 图文消息
    /// </summary>
    public class NewsMessageSendParam: BaseMessageSendParam
    {
        /// <summary>
        /// 消息
        /// </summary>
        [JsonProperty("news")]
        public NewsInfo News { get; set; } = new NewsInfo();
    }
    /// <summary>
    /// 图文消息
    /// </summary>
    public class NewsInfo
    {
        /// <summary>
        /// 图文消息，一个图文消息支持1到8条图文
        /// </summary>
        [JsonProperty("articles")]
        public List<ArticleInfo> Articles { get; set; } = new List<ArticleInfo>();
    }
    /// <summary>
    /// 图文消息
    /// </summary>
    public class ArticleInfo
    {
        /// <summary>
        /// 标题，不超过128个字节，超过会自动截断（支持id转译）
        /// </summary>
        [JsonProperty("title")]
        public string? Title { get; set; }
        /// <summary>
        /// 描述，不超过512个字节，超过会自动截断（支持id转译）
        /// </summary>
        [JsonProperty("description")]
        public string? Description { get; set; }
        /// <summary>
        /// 点击后跳转的链接。 最长2048字节，请确保包含了协议头(http/https)，小程序或者url必须填写一个
        /// </summary>
        [JsonProperty("url")]
        public string? Url { get; set; }
        /// <summary>
        /// 图文消息的图片链接，支持JPG、PNG格式，较好的效果为大图 1068*455，小图150*150。
        /// </summary>
        [JsonProperty("picurl")]
        public string? PicUrl { get; set; }
        /// <summary>
        /// 小程序appid，必须是与当前应用关联的小程序，appid和pagepath必须同时填写，填写后会忽略url字段
        /// </summary>
        [JsonProperty("appid")]
        public string? AppId { get; set; }
        /// <summary>
        /// 点击消息卡片后的小程序页面，仅限本小程序内的页面。appid和pagepath必须同时填写，填写后会忽略url字段
        /// </summary>
        [JsonProperty("pagepath")]
        public string? PagePath { get; set; }
    }
}
