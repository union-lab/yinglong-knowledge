﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;

namespace Youlian.SDK.Weixin.Work.Models.OA.Attendance
{
    public class CheckInDayDataResult : BaseResult
    {
        /// <summary>
        /// 
        /// </summary>
        public List<CheckInDayDataItem> datas { get; set; }
    }
    public class CheckInDayDataItem
    {
        /// <summary>
        /// 基础信息
        /// </summary>
        public Base_info base_info { get; set; }
        /// <summary>
        /// 汇总信息
        /// </summary>
        public Summary_info summary_info { get; set; }
        /// <summary>
        /// 假勤相关信息
        /// </summary>
        public List<Holiday_infosItem> holiday_infos { get; set; }
        /// <summary>
        /// 校准状态信息
        /// </summary>
        public List<Exception_infosItem> exception_infos { get; set; }
        /// <summary>
        /// 加班信息
        /// </summary>
        public Ot_info ot_info { get; set; }
        /// <summary>
        /// 假勤统计信息
        /// </summary>
        public List<Sp_itemsItem> sp_items { get; set; }
    }
    /// <summary>
    /// 假勤统计信息
    /// </summary>
    public class Sp_itemsItem
    {
        /// <summary>
        /// 当日假勤次数
        /// </summary>
        public int count { get; set; }
        /// <summary>
        /// 当日假勤时长秒数，时长单位为天直接除以86400即为天数，单位为小时直接除以3600即为小时数
        /// </summary>
        public int duration { get; set; }
        /// <summary>
        /// 时长单位：0-按天 1-按小时
        /// </summary>
        public int time_type { get; set; }
        /// <summary>
        /// 类型：1-请假；2-补卡；3-出差；4-外出；100-外勤
        /// </summary>
        public int type { get; set; }
        /// <summary>
        /// 具体请假类型，当type为1请假时，具体的请假类型id，可通过审批相关接口获取假期详情
        /// </summary>
        public int vacation_id { get; set; }
        /// <summary>
        /// 统计项名称
        /// </summary>
        public string name { get; set; }
    }
    /// <summary>
    /// 加班信息
    /// </summary>
    public class Ot_info
    {
        /// <summary>
        /// 状态：0-无加班；1-正常；2-缺时长
        /// </summary>
        public int ot_status { get; set; }
        /// <summary>
        /// 加班时长
        /// </summary>
        public int ot_duration { get; set; }
        /// <summary>
        /// ot_status为2下，加班不足的时长
        /// </summary>
        public List<string> exception_duration { get; set; }
    }
    /// <summary>
    /// 校准状态信息
    /// </summary>
    public class Exception_infosItem
    {
        /// <summary>
        /// 当日此异常的次数
        /// </summary>
        public int count { get; set; }
        /// <summary>
        /// 当日此异常的时长（迟到/早退/旷工才有值）
        /// </summary>
        public int duration { get; set; }
        /// <summary>
        /// 校准状态类型：1-迟到；2-早退；3-缺卡；4-旷工；5-地点异常；6-设备异常
        /// </summary>
        public int exception { get; set; }
    }

    /// <summary>
    /// 假勤相关信息
    /// </summary>
    public class Holiday_infosItem
    {
        /// <summary>
        /// 假勤信息摘要-描述信息
        /// </summary>
        public Sp_description sp_description { get; set; }
        /// <summary>
        /// 假勤申请id，即当日关联的假勤审批单id
        /// </summary>
        public string sp_number { get; set; }
        /// <summary>
        /// 假勤信息摘要-标题信息
        /// </summary>
        public Sp_title sp_title { get; set; }
    }
    /// <summary>
    /// 假勤信息摘要-标题信息
    /// </summary>
    public class Sp_title
    {
        /// <summary>
        /// 
        /// </summary>
        public List<DataItem> data { get; set; }
    }

    public class CheckintimeItem
    {
        /// <summary>
        /// 上班时间，为距离0点的时间差
        /// </summary>
        public int work_sec { get; set; }
        /// <summary>
        /// 下班时间，为距离0点的时间差
        /// </summary>
        public int off_work_sec { get; set; }
    }
    /// <summary>
    /// 打卡人员所属规则信息
    /// </summary>
    public class Rule_info
    {
        /// <summary>
        /// 所属规则的id
        /// </summary>
        public int groupid { get; set; }
        /// <summary>
        /// 打卡规则名
        /// </summary>
        public string groupname { get; set; }
        /// <summary>
        /// 当日所属班次id，仅按班次上下班才有值，显示在打卡日报-班次列
        /// </summary>
        public int scheduleid { get; set; }
        /// <summary>
        /// 当日所属班次名称，仅按班次上下班才有值，显示在打卡日报-班次列
        /// </summary>
        public string schedulename { get; set; }
        /// <summary>
        /// 当日打卡时间，仅固定上下班规则有值，显示在打卡日报-班次列
        /// </summary>
        public List<CheckintimeItem> checkintime { get; set; }
    }

    /// <summary>
    /// 基础信息
    /// </summary>
    public class Base_info
    {
        /// <summary>
        /// 日报日期
        /// </summary>
        public int date { get; set; }

        public DateTime Time => Extention.ConvertToDateTime(date);
        /// <summary>
        /// 记录类型：1-固定上下班；2-外出（此报表中不会出现外出打卡数据）；3-按班次上下班；4-自由签到；5-加班；7-无规则
        /// </summary>
        public int record_type { get; set; }
        /// <summary>
        /// 打卡人员姓名
        /// </summary>
        public string name { get; set; }
        /// <summary>
        /// 打卡人员别名
        /// </summary>
        public string name_ex { get; set; }
        /// <summary>
        /// 打卡人员所在部门，会显示所有所在部门
        /// </summary>
        public string departs_name { get; set; }
        /// <summary>
        /// 打卡人员帐号，即userid
        /// </summary>
        public string acctid { get; set; }
        /// <summary>
        /// 打卡人员所属规则信息
        /// </summary>
        public Rule_info rule_info { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int day_type { get; set; }
    }
    /// <summary>
    /// 汇总信息
    /// </summary>
    public class Summary_info
    {
        /// <summary>
        /// 当日打卡次数
        /// </summary>
        public int checkin_count { get; set; }
        /// <summary>
        /// 当日实际工作时长，单位：秒
        /// </summary>
        public int regular_work_sec { get; set; }
        /// <summary>
        /// 当日标准工作时长，单位：秒
        /// </summary>
        public int standard_work_sec { get; set; }
        /// <summary>
        /// 当日最早打卡时间
        /// </summary>
        public int earliest_time { get; set; }
        /// <summary>
        /// 当日最晚打卡时间
        /// </summary>
        public int lastest_time { get; set; }
    }

    /// <summary>
    /// 假勤信息摘要-描述信息
    /// </summary>
    public class Sp_description
    {
        /// <summary>
        /// 
        /// </summary>
        public List<DataItem> data { get; set; }
    }

    /// <summary>
    /// 多种语言描述，目前只有中文一种
    /// </summary>
    public class DataItem
    {
        /// <summary>
        /// 语言类型："zh_CN"
        /// </summary>
        public string lang { get; set; } = "zh_CN";
        /// <summary>
        /// 假勤信息摘要-标题文本
        /// </summary>
        public string text { get; set; }
    }
}