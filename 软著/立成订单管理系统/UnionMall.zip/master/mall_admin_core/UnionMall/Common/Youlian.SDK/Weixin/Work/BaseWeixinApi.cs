﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Common.Service.Http;
using Youlian.SDK.Weixin.Work.Models;

namespace Youlian.SDK.Weixin.Work
{
    public class BaseWeixinApi : BaseHttpRequest
    {
        public const string HOST = "https://qyapi.weixin.qq.com";
        /// <summary>
        /// 企业应用ID
        /// </summary>
        public static string CorpId => AppSettings.Configuration.GetSection("WorkWeixin:CorpId").Value;
        protected static ICacheManager _cache => AppSettings.Services.GetService<ICacheManager>();
        private static readonly object lockObj = new();

        #region 获取token
        /// <summary>
        /// 获取token
        /// </summary>
        /// <param name="appType"></param>
        /// <param name="secret"></param>
        /// <returns></returns>
        public static string GetToken(string secret)
        {
            string key = string.Format(CacheKeys.WorkWeixinAppAccessToken, secret);
            var value = _cache.GetString(key);
            if (string.IsNullOrEmpty(value))
            {
                lock (lockObj)
                {
                    value = _cache.GetString(key);
                    if (string.IsNullOrEmpty(value))
                    {
                        var result = GetAccessTokenAsync(secret).Result;
                        if (result != null)
                        {
                            _cache.SetString(key, result.access_token, TimeSpan.FromSeconds(result.expires_in - 100));//提前100秒失效token
                            return result.access_token;
                        }
                    }

                }
            }
            return value;
        }
        #endregion

        #region 获取访问token
        /// <summary>
        /// 获取访问token
        /// </summary>
        /// <returns></returns>
        private static async Task<TokenResult> GetAccessTokenAsync(string secret)
        {
            string url = $"{HOST}/cgi-bin/gettoken";
            var param = new Dictionary<string, string>()
            {
                { "corpid",CorpId },
                { "corpsecret",secret }
            };
            return await GetAsync<TokenResult>(url, param);
        }
        #endregion
    }
}
