﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Common.Service.Http;
using Youlian.SDK.Weixin.Models;

namespace Youlian.SDK.Weixin
{
    /// <summary>
    /// 通用API
    /// </summary>
    public class WeixinApi: BaseWeixinApi
    {
        #region 获取小程序登录Session
        /// <summary>
        /// 获取小程序登录Session
        /// </summary>
        /// <returns></returns>
        public static async Task<Code2SessionResult> Code2Session(string appId, string js_code)
        {
            var secret = AppSettings.Configuration.GetSection($"Weixin:App:{appId}:Secret").Value;
            string url = $"https://api.weixin.qq.com/sns/jscode2session?appid={appId}&secret={secret}&js_code={js_code}&grant_type=authorization_code";
            return await GetAsync<Code2SessionResult>(url);
        }
        #endregion
    }
}
