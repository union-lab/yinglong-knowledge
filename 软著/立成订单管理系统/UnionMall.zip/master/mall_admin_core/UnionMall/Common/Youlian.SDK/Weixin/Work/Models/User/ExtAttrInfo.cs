﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.User
{
    /// <summary>
    /// 扩展属性
    /// </summary>
    public class ExtAttrInfo
    {
        /// <summary>
        /// 扩展属性
        /// </summary>
        [JsonProperty("attrs")]
        public List<ExternalAttrItemInfo>? Attrs { get; set; }
    }
}
