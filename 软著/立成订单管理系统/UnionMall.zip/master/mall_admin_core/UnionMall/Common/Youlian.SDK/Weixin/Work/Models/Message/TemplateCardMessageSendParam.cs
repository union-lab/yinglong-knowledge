﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 模板卡片消息
    /// </summary>
    public class TemplateCardMessageSendParam : BaseMessageSendParam
    {
        /// <summary>
        /// 文本卡片
        /// </summary>
        [JsonProperty("template_card", NullValueHandling = NullValueHandling.Ignore)]
        public TemplateCardInfo TemplateCard { get; set; } = new TemplateCardInfo();
    }
    /// <summary>
    /// 模板卡片消息
    /// </summary>
    public class TemplateCardInfo
    {
        /// <summary>
        /// 模板卡片类型
        /// </summary>
        [JsonProperty("card_type", NullValueHandling = NullValueHandling.Ignore)]
        public string CardType { get; set; } = string.Empty;
        /// <summary>
        /// 卡片来源样式信息，不需要来源样式可不填写
        /// </summary>
        [JsonProperty("source", NullValueHandling = NullValueHandling.Ignore)]
        public TemplateCardSource? Source { get; set; }
        /// <summary>
        /// 卡片右上角更多操作按钮
        /// </summary>
        [JsonProperty("action_menu", NullValueHandling = NullValueHandling.Ignore)]
        public TemplateCardActionMenu? ActionMenu { get; set; }
        /// <summary>
        /// 任务id，同一个应用任务id不能重复，只能由数字、字母和“_-@”组成，最长128字节，填了action_menu字段的话本字段必填
        /// </summary>
        [JsonProperty("task_id", NullValueHandling = NullValueHandling.Ignore)]
        public string? TaskId { get; set; }
        /// <summary>
        /// 一级标题
        /// </summary>
        [JsonProperty("main_title", NullValueHandling = NullValueHandling.Ignore)]
        public TemplateCardMainTitle? MainTitle { get; set; }
        /// <summary>
        /// 引用文献样式
        /// </summary>
        [JsonProperty("quote_area", NullValueHandling = NullValueHandling.Ignore)]
        public TemplateCardQuoteArea? QuoteArea { get; set; }
        /// <summary>
        /// 左图右文样式，news_notice类型的卡片，card_image和image_text_area两者必填一个字段，不可都不填
        /// </summary>
        [JsonProperty("image_text_area", NullValueHandling = NullValueHandling.Ignore)]
        public TemplateCardImageTextArea? ImageTextArea { get; set; }
        /// <summary>
        /// 图片样式，news_notice类型的卡片，card_image和image_text_area两者必填一个字段，不可都不填
        /// </summary>
        [JsonProperty("card_image", NullValueHandling = NullValueHandling.Ignore)]
        public TemplateCardCardImage? CardImage { get; set; }
        /// <summary>
        /// 卡片二级垂直内容，该字段可为空数组，但有数据的话需确认对应字段是否必填，列表长度不超过4
        /// </summary>
        [JsonProperty("vertical_content_list", NullValueHandling = NullValueHandling.Ignore)]
        public List<TemplateCardVerticalContentListItem>? VerticalContentList { get; set; }
        /// <summary>
        /// 二级标题+文本列表，该字段可为空数组，但有数据的话需确认对应字段是否必填，列表长度不超过6
        /// </summary>
        [JsonProperty("horizontal_content_list", NullValueHandling = NullValueHandling.Ignore)]
        public List<TemplateCardHorizontalContentListItem>? HorizontalContentList { get; set; }
        /// <summary>
        /// 跳转指引样式的列表，该字段可为空数组，但有数据的话需确认对应字段是否必填，列表长度不超过3
        /// </summary>
        [JsonProperty("jump_list", NullValueHandling = NullValueHandling.Ignore)]
        public List<TemplateCardBaseArea>? JumpList { get; set; }
        /// <summary>
        /// 整体卡片的点击跳转事件，news_notice必填本字段
        /// </summary>
        [JsonProperty("card_action", NullValueHandling = NullValueHandling.Ignore)]
        public TemplateCardBaseArea? CardAction { get; set; }
    }
    /// <summary>
    /// 卡片来源样式信息，不需要来源样式可不填写
    /// </summary>
    public class TemplateCardSource
    {
        /// <summary>
        /// 来源图片的url，来源图片的尺寸建议为72*72
        /// </summary>
        [JsonProperty("icon_url", NullValueHandling = NullValueHandling.Ignore)]
        public string? IconUrl { get; set; }
        /// <summary>
        /// 来源图片的描述，建议不超过20个字，（支持id转译）
        /// </summary>
        [JsonProperty("desc", NullValueHandling = NullValueHandling.Ignore)]
        public string? Desc { get; set; }
        /// <summary>
        /// 来源文字的颜色，目前支持：0(默认) 灰色，1 黑色，2 红色，3 绿色
        /// </summary>
        [JsonProperty("desc_color", NullValueHandling = NullValueHandling.Ignore)]
        public int DescColor { get; set; }
    }

    /// <summary>
    /// 卡片右上角更多操作按钮
    /// </summary>
    public class TemplateCardActionMenu
    {
        /// <summary>
        /// 更多操作界面的描述
        /// </summary>
        [JsonProperty("desc", NullValueHandling = NullValueHandling.Ignore)]
        public string? Desc { get; set; }
        /// <summary>
        /// 操作列表，列表长度取值范围为 [1, 3]
        /// </summary>
        [JsonProperty("action_list", NullValueHandling = NullValueHandling.Ignore)]
        public List<TemplateCardActionListItem> ActionList { get; set; } = new List<TemplateCardActionListItem>();
    }
    /// <summary>
    /// 操作列表，列表长度取值范围为 [1, 3]
    /// </summary>
    public class TemplateCardActionListItem
    {
        /// <summary>
        /// 操作的描述文案
        /// </summary>
        [JsonProperty("text", NullValueHandling = NullValueHandling.Ignore)]
        public string Text { get; set; } = string.Empty;
        /// <summary>
        /// 操作key值，用户点击后，会产生回调事件将本参数作为EventKey返回，回调事件会带上该key值，最长支持1024字节，不可重复
        /// </summary>
        [JsonProperty("key", NullValueHandling = NullValueHandling.Ignore)]
        public string Key { get; set; } = string.Empty;
    }

    /// <summary>
    /// 一级标题
    /// </summary>
    public class TemplateCardMainTitle
    {
        /// <summary>
        /// 一级标题，建议不超过36个字，文本通知型卡片本字段非必填，但不可本字段和sub_title_text都不填，（支持id转译）
        /// </summary>
        [JsonProperty("title", NullValueHandling = NullValueHandling.Ignore)]
        public string? Title { get; set; }
        /// <summary>
        /// 标题辅助信息，建议不超过44个字，（支持id转译）
        /// </summary>
        [JsonProperty("desc", NullValueHandling = NullValueHandling.Ignore)]
        public string? Desc { get; set; }
    }

    /// <summary>
    /// 模板卡片样式
    /// </summary>
    public class TemplateCardBaseArea
    {
        /// <summary>
        /// 样式区域点击事件，0或不填代表没有点击事件，1 代表跳转url，2 代表跳转小程序
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public int Type { get; set; }
        /// <summary>
        /// 样式的标题
        /// </summary>
        [JsonProperty("title", NullValueHandling = NullValueHandling.Ignore)]
        public string? Title { get; set; }
        /// <summary>
        /// 点击跳转的url，type是1时必填
        /// </summary>
        [JsonProperty("url", NullValueHandling = NullValueHandling.Ignore)]
        public string? Url { get; set; }
        /// <summary>
        /// 点击跳转的小程序的appid，必须是与当前应用关联的小程序，type是2时必填
        /// </summary>
        [JsonProperty("appid", NullValueHandling = NullValueHandling.Ignore)]
        public string? AppId { get; set; }
        /// <summary>
        /// 点击跳转的小程序的pagepath，type是2时选填
        /// </summary>
        [JsonProperty("pagepath", NullValueHandling = NullValueHandling.Ignore)]
        public string? PagePath { get; set; }
    }
    /// <summary>
    /// 引用文献样式
    /// </summary>
    public class TemplateCardQuoteArea : TemplateCardBaseArea
    {
        /// <summary>
        /// 引用文献样式的引用文案
        /// </summary>
        [JsonProperty("quote_text", NullValueHandling = NullValueHandling.Ignore)]
        public string? QuoteText { get; set; }
    }

    /// <summary>
    /// 左图右文样式，news_notice类型的卡片，card_image和image_text_area两者必填一个字段，不可都不填
    /// </summary>
    public class TemplateCardImageTextArea : TemplateCardBaseArea
    {
        /// <summary>
        /// 左图右文样式的图片url
        /// </summary>
        [JsonProperty("image_url", NullValueHandling = NullValueHandling.Ignore)]
        public string? ImageUrl { get; set; }
    }
    /// <summary>
    /// 图片样式，news_notice类型的卡片，card_image和image_text_area两者必填一个字段，不可都不填
    /// </summary>
    public class TemplateCardCardImage
    {
        /// <summary>
        /// 图片的url
        /// </summary>
        [JsonProperty("url", NullValueHandling = NullValueHandling.Ignore)]
        public string Url { get; set; } = string.Empty;
        /// <summary>
        /// 图片的宽高比，宽高比要小于2.25，大于1.3，不填该参数默认1.3
        /// </summary>
        [JsonProperty("aspect_ratio", NullValueHandling = NullValueHandling.Ignore)]
        public decimal AspectRatio { get; set; }
    }

    /// <summary>
    /// 卡片二级垂直内容，该字段可为空数组，但有数据的话需确认对应字段是否必填，列表长度不超过4
    /// </summary>
    public class TemplateCardVerticalContentListItem
    {
        /// <summary>
        /// 卡片二级标题，建议不超过38个字
        /// </summary>
        [JsonProperty("title", NullValueHandling = NullValueHandling.Ignore)]
        public string Title { get; set; } = string.Empty;
        /// <summary>
        /// 二级普通文本，建议不超过160个字！
        /// </summary>
        [JsonProperty("desc", NullValueHandling = NullValueHandling.Ignore)]
        public string? Desc { get; set; }
    }
    /// <summary>
    /// 二级标题+文本列表，该字段可为空数组，但有数据的话需确认对应字段是否必填，列表长度不超过6
    /// </summary>
    public class TemplateCardHorizontalContentListItem
    {
        /// <summary>
        /// 链接类型，0或不填代表不是链接，1 代表跳转url，2 代表下载附件，3 代表点击跳转成员详情
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public int Type { get; set; }
        /// <summary>
        /// 二级标题，建议不超过5个字
        /// </summary>
        [JsonProperty("keyname", NullValueHandling = NullValueHandling.Ignore)]
        public string KeyName { get; set; } = string.Empty;
        /// <summary>
        /// 二级文本，type是2，该字段代表文件名称（要包含文件类型），建议不超过30个字，（支持id转译）
        /// </summary>
        [JsonProperty("value", NullValueHandling = NullValueHandling.Ignore)]
        public string? Value { get; set; }
        /// <summary>
        /// 链接跳转的url，type是1时必填
        /// </summary>
        [JsonProperty("url", NullValueHandling = NullValueHandling.Ignore)]
        public string? Url { get; set; }
        /// <summary>
        /// 附件的media_id，type是2时必填
        /// </summary>
        [JsonProperty("media_id", NullValueHandling = NullValueHandling.Ignore)]
        public string? MediaId { get; set; }
        /// <summary>
        /// 成员详情的userid，type是3时必填
        /// </summary>
        [JsonProperty("userid", NullValueHandling = NullValueHandling.Ignore)]
        public string? UserId { get; set; }
    }
}