﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 控件值
    /// </summary>
    public class ControlValue
    {
        /// <summary>
        /// 文本控件
        /// </summary>
        public string? Text { get; set; }

        /// <summary>
        /// 数字控件
        /// </summary>
        [JsonProperty("new_number")]
        public string? NewNumber { get; set; }

        /// <summary>
        /// 日期控件
        /// </summary>
        public DateControlValue? Date { get; set; }

        /// <summary>
        /// 单选/多选控件
        /// </summary>
        public SelectorControlValue? Selector { get; set; }

        /// <summary>
        /// 成员控件
        /// </summary>
        public List<MemberControlValue>? Members { get; set; }
        /// <summary>
        /// 部门控件
        /// </summary>
        public List<DepartmentControlValue>? Departments { get; set; }
        /// <summary>
        /// 附件控件
        /// </summary>
        public List<FileControlValue>? Files { get; set; }

        /// <summary>
        /// 假勤组件-请假组件
        /// </summary>
        public VacationControlValue? Vacation { get; set; }

        /// <summary>
        /// 假勤组件-出差/外出/加班组件
        /// </summary>
        public AttendanceControlValue? Attendance { get; set; }

        /// <summary>
        /// 明细控件
        /// </summary>
        public List<TableControlValue>? Children { get; set; }

        /// <summary>
        /// 时长组件
        /// </summary>
        [JsonProperty("date_range")]
        public ControlDateRang? DateRange { get; set; }
    }
}
