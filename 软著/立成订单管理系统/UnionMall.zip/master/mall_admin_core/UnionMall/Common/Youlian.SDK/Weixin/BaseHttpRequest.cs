﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Common.Service.Http;

namespace Youlian.SDK.Weixin
{
    public class BaseHttpRequest
    {
        private static IHttpService _httpService => AppSettings.Services.GetService<IHttpService>();
        protected static log4net.ILog _logger => log4net.LogManager.GetLogger(typeof(BaseWeixinApi));

        #region Get Post 请求封装
        protected static async Task<TResult> GetAsync<TResult>(string url, Dictionary<string, string>? param = null) where TResult : new()
        {
            TResult? reuslt = default;
            var apiResult = await _httpService.GetApiAsync(url, param);
            if (apiResult.Success)
            {
                reuslt = JsonExtention.TryDeserialize<TResult>(apiResult.Message);
            }
            if (reuslt == null || !apiResult.Success)
            {
                WriteLog($"请求微信接口错误：url:{url},param:{param?.ToJson()},result:{apiResult.ToJson()}");
            }
            return reuslt ?? new TResult();
        }

        protected static async Task<TResult> PostAsync<TResult, T>(string url, T? param = null) where TResult : new() where T : class
        {
            TResult? reuslt = default;
            var apiResult = await _httpService.PostApiAsync(url, param, null);
            if (apiResult.Success)
            {
                reuslt = JsonExtention.TryDeserialize<TResult>(apiResult.Message);
            }
            if (reuslt == null || !apiResult.Success)
            {
                WriteLog($"请求微信接口错误：url:{url},param:{param?.ToJson()},result:{apiResult.ToJson()}");
            }
            return reuslt ?? new TResult();
        }
        #endregion

        #region 写入错误日志
        /// <summary>
        /// 写入错误日志
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="ex"></param>
        /// <returns></returns>
        private static void WriteLog(string msg, Exception? ex = null)
        {
            _logger.Error($"\r\n【自定义错误】：{msg} \r\n【异常类型】：{ex?.GetType().Name} \r\n【异常信息】：{ex?.Message} \r\n【堆栈调用】：{ex?.StackTrace}\r\n");
        }
        #endregion
    }
}
