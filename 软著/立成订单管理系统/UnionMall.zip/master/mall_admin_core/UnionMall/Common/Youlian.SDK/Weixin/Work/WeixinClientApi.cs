﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.SDK.Weixin.Work.Models;
using Youlian.SDK.Weixin.Work.Models.Client;

namespace Youlian.SDK.Weixin.Work
{
    public class WeixinClientApi : BaseWeixinApi
    {
        private static readonly object lockObj = new();

        #region 获取token
        /// <summary>
        /// 获取token
        /// </summary>
        /// <param name="appType"></param>
        /// <param name="secret"></param>
        /// <returns></returns>
        public static string GetJsApiTicket(int agentId)
        {
            string key = string.Format(CacheKeys.WorkWeixinAppJsApiTicket, agentId);
            var value = _cache.GetString(key);
            if (string.IsNullOrEmpty(value))
            {
                lock (lockObj)
                {
                    value = _cache.GetString(key);
                    if (string.IsNullOrEmpty(value))
                    {
                        var result = GetJsApiTicketAsync(agentId).Result;
                        if (result != null)
                        {
                            _cache.SetString(key, result.Ticket, TimeSpan.FromSeconds(result.ExpiresIn - 60));//提前60秒失效
                            return result.Ticket;
                        }
                    }

                }
            }
            return value;
        }
        #endregion

        #region 获取企业的jsapi_ticket
        /// <summary>
        /// 获取企业的jsapi_ticket
        /// </summary>
        /// <returns></returns>
        private static async Task<JsApiTicketResult> GetJsApiTicketAsync(int agentId)
        {
            string url = $"{HOST}/cgi-bin/ticket/get?access_token={ApiHelper.GetToken(agentId)}&type=agent_config";
            return await GetAsync<JsApiTicketResult>(url);
        }
        #endregion

        #region 获取签名
        /// <summary>
        /// 获取签名
        /// </summary>
        /// <param name="agentId"></param>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string GetSignature(int agentId, string noncestr, int timestamp, string url)
        {
            string jsapi_ticket = GetJsApiTicket(agentId);
            var str = $"jsapi_ticket={jsapi_ticket}&noncestr={noncestr}&timestamp={timestamp}&url={url?.Split('#')?.First()}";
            return str.ToSHA1String();
        }
        #endregion
    }
}
