﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 假勤组件-出差/外出/加班组件信息
    /// </summary>
    public class AttendanceControlValue
    {
        /// <summary>
        /// 假勤组件时间选择范围
        /// </summary>
        [JsonProperty("date_range")]
        public ControlDateRang? DateRange { get; set; }
        /// <summary>
        /// 假勤组件类型：1-请假；2-补卡；3-出差；4-外出；5-加班
        /// </summary>
        public int Type { get; set; }

        /// <summary>
        /// 时长支持按天分片信息， 2020/10/01之前的历史表单不支持时长分片
        /// </summary>
        [JsonProperty("slice_info")]
        public SliceInfo? SliceInfo { get; set; }
    }

    public class SliceInfo
    {
        /// <summary>
        /// 时长支持按天分片信息， 2020/10/01之前的历史表单不支持时长分片
        /// </summary>
        [JsonProperty("day_items")]
        public List<DayItemsItem>? DayItems { get; set; }
        /// <summary>
        /// 总时长，单位是秒
        /// </summary>
        public int Duration { get; set; }
        /// <summary>
        /// 时长计算来源类型: 1--系统自动计算;2--用户修改
        /// </summary>
        public int State { get; set; }
    }
    public class DayItemsItem
    {
        /// <summary>
        /// 日期的00:00:00时间戳，Unix时间
        /// </summary>
        public int DayTime { get; set; }
        /// <summary>
        /// 分隔当前日期的时长秒数
        /// </summary>
        public int Duration { get; set; }
    }
}
