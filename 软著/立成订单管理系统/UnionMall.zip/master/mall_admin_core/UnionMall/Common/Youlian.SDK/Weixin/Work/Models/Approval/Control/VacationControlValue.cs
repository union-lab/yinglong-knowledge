﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 请假内容
    /// </summary>
    public class VacationControlValue
    {
        /// <summary>
        /// 请假类型
        /// </summary>
        public VacationSelector? Selector { get; set; }
        /// <summary>
        /// 假勤组件
        /// </summary>
        public VacationAttendance? Attendance { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class VacationSelector:SelectorControlValue
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("exp_type")]
        public int ExpType { get; set; }
    }

    public class VacationAttendance
    {
        /// <summary>
        /// 假勤组件时间选择范围
        /// </summary>
        [JsonProperty("date_range")]
        public ControlDateRang? DateRange { get; set; }
        /// <summary>
        /// 假勤组件类型：1-请假；2-补卡；3-出差；4-外出；5-加班
        /// </summary>
        public int Type { get; set; }
    }


}
