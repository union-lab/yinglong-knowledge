﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    public class SpRecordItem
    {
        /// <summary>
        /// 审批节点状态：1-审批中；2-已同意；3-已驳回；4-已转审；11-已退回
        /// </summary>
        [JsonProperty("sp_status")]
        public int SpStatus { get; set; }
        /// <summary>
        /// 节点审批方式：1-或签；2-会签
        /// </summary>
        public int ApproverAttr { get; set; }
        /// <summary>
        /// 审批节点详情,一个审批节点有多个审批人
        /// </summary>
        public List<SpRecordDetail> Details { get; set; }
    }
}
