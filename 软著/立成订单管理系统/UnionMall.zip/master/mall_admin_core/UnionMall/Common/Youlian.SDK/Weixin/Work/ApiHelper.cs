﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;

namespace Youlian.SDK.Weixin.Work
{
    public class ApiHelper
    {
        /// <summary>
        /// 通讯录Secret
        /// </summary>
        private static string ContactsSecret => AppSettings.Configuration.GetSection("WorkWeixin:ContactsSecret").Value;
        private static string ApprovalSecret => AppSettings.Configuration.GetSection("WorkWeixin:Approval:Secret").Value;
        private static string AttendanceSecret => AppSettings.Configuration.GetSection("WorkWeixin:Attendance:Secret").Value;

        //友联APP Secret
        private static int YoulianAgentId => AppSettings.Configuration.GetSection("WorkWeixin:Youlian:AgentId").Value.ToInt();
        private static string YoulianSecret => AppSettings.Configuration.GetSection("WorkWeixin:Youlian:Secret").Value;

        /// <summary>
        /// 通知回调Token
        /// </summary>
        public static string NotifyToken => AppSettings.Configuration.GetSection("WorkWeixin:Notify:Token").Value;
        public static string NotifyEncodingAESKey => AppSettings.Configuration.GetSection("WorkWeixin:Notify:EncodingAESKey").Value;


        /// <summary>
        /// 获取AccessToken
        /// </summary>
        /// <param name="appType"></param>
        /// <returns></returns>
        public static string GetToken(AppTypeEnum appType)
        {
            string secret = string.Empty;
            switch (appType)
            {
                case AppTypeEnum.通讯录:
                    secret = ContactsSecret;
                    break;
                case AppTypeEnum.审批:
                    secret = ApprovalSecret;
                    break;
                case AppTypeEnum.友联APP:
                    secret = YoulianSecret;
                    break;
                case AppTypeEnum.考勤打卡:
                    secret = AttendanceSecret;
                    break;
                default:
                    break;
            }
            return BaseWeixinApi.GetToken(secret);
        }
        public static string GetToken(int agentId)
        {
            string secret = AppSettings.Configuration.GetSection($"WorkWeixin:Apps:{agentId}:Secret").Value;
            return BaseWeixinApi.GetToken(secret);
        }

        /// <summary>
        /// 获取AgentId
        /// </summary>
        /// <param name="appType"></param>
        /// <returns></returns>
        public static int GetAgentId(AppTypeEnum appType)
        {
            switch (appType)
            {
                case AppTypeEnum.友联APP:
                    return YoulianAgentId;
                default:
                    return 0;
            }
        }
    }
}
