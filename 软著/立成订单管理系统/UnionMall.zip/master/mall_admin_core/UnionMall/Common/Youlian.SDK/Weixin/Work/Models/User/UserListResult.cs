﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    public class UserListResult : BaseResult
    {
        /// <summary>
        /// 用户列表
        /// </summary>
        public List<UserInfo>? UserList { get; set; }
    }
}
