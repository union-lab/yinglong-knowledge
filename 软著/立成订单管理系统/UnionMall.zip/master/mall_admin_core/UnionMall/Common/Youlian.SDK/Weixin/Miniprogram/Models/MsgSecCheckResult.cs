﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Miniprogram.Models
{
    /// <summary>
    /// 验证结果
    /// </summary>
    public class MsgSecCheckResult:BaseResult
    {
        /// <summary>
        /// 唯一请求标识，标记单次请求
        /// </summary>
        [JsonProperty("trace_id")]
        public string? TraceId { get; set; }
        /// <summary>
        /// 综合结果
        /// </summary>
        public MsgSecCheckResultResult? Result { get; set; }
        /// <summary>
        /// 详细检测结果
        /// </summary>
        public MsgSecCheckResultDetail? Detail { get; set; }
    }
    public class MsgSecCheckResultResult
    {
        /// <summary>
        /// 建议，有risky、pass、review三种值
        /// </summary>
        public string? Suggest { get; set; }
        /// <summary>
        /// 命中标签枚举值，100 正常；10001 广告；20001 时政；20002 色情；20003 辱骂；20006 违法犯罪；20008 欺诈；20012 低俗；20013 版权；21000 其他
        /// </summary>
        public string? Label { get; set; }

    }

    public class MsgSecCheckResultDetail 
    {
        /// <summary>
        /// 策略类型
        /// </summary>
        public string? Strategy { get; set; }
        /// <summary>
        /// 错误码，仅当该值为0时，该项结果有效
        /// </summary>
        public string? ErrCode { get; set; }
        /// <summary>
        /// 建议，有risky、pass、review三种值
        /// </summary>
        public string? Suggest { get; set; }
        /// <summary>
        /// 命中标签枚举值，100 正常；10001 广告；20001 时政；20002 色情；20003 辱骂；20006 违法犯罪；20008 欺诈；20012 低俗；20013 版权；21000 其他
        /// </summary>
        public string? Label { get; set; }
        /// <summary>
        /// 0-100，代表置信度，越高代表越有可能属于当前返回的标签（label）
        /// </summary>
        public int Prob { get; set; }
        /// <summary>
        /// 命中的自定义关键词
        /// </summary>
        public string? Keyword { get; set; }
    }

}
