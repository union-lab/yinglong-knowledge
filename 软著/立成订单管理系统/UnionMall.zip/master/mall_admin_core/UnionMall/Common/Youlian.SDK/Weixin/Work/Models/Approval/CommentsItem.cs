﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    public class CommentsItem
    {
        /// <summary>
        /// 备注人信息
        /// </summary>
        public CommentUserInfo CommentUserInfo { get; set; }
        /// <summary>
        /// 备注提交时间戳，Unix时间戳
        /// </summary>
        public int CommentTime { get; set; }
        /// <summary>
        /// 备注信息
        /// </summary>
        public string CommentContent { get; set; }
        /// <summary>
        /// 备注id
        /// </summary>
        public string Commentid { get; set; }
        /// <summary>
        /// 备注附件id
        /// </summary>
        [JsonProperty("media_id")]
        public List<string> MediaId { get; set; }
    }
}
