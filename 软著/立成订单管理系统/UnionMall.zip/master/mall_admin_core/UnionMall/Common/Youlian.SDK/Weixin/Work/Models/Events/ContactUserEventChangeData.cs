﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.SDK.Weixin.Work.Models.User;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 更新成员事件回调数据
    /// </summary>
    public class ContactUserEventChangeData : ContactEventChangeData
    {
        /// <summary>
        /// 变更信息的成员UserID；
        /// 大小写敏感，不要修改大小写
        /// </summary>
        public string? UserID { get; set; }
        /// <summary>
        /// 新的UserID，变更时推送（userid由系统生成时可更改一次）；
        /// 大小写敏感，不要修改大小写
        /// </summary>
        public string? NewUserID { get; set; }
        /// <summary>
        /// 成员名称，变更时推送;代开发自建应用需要管理员授权才返回
        /// </summary>
        public string? Name { get; set; }
        /// <summary>
        /// 成员部门列表，变更时推送，仅返回该应用有查看权限的部门id
        /// </summary>
        //public List<int>? Departments { get; set; }

        public string Department { get; set; }
        /// <summary>
        /// 主部门
        /// </summary>
        public int? MainDepartment { get; set; }
        /// <summary>
        /// 表示所在部门是否为部门负责人，0-否，1-是，顺序与Department字段的部门逐一对应。上游共享的应用不返回该字段
        /// </summary>
        //public List<int>? IsLeaderInDept { get; set; }
        public string IsLeaderInDept { get; set; }
        /// <summary>
        /// 直属上级UserID，最多5个。代开发的自建应用和上游共享的应用不返回该字段
        /// </summary>
        public List<string>? DirectLeader { get; set; }
        /// <summary>
        /// 职位信息。长度为0~64个字节;代开发自建应用需要管理员授权才返回。上游共享的应用不返回该字段
        /// </summary>
        public string? Position { get; set; }
        /// <summary>
        /// 手机号码;代开发自建应用需要管理员授权才返回。上游共享的应用不返回该字段
        /// </summary>
        public string? Mobile { get; set; }
        /// <summary>
        /// 性别，1表示男性，2表示女性。上游共享的应用不返回该字段
        /// </summary>
        public int? Gender { get; set; }
        /// <summary>
        /// 邮箱;代开发自建应用需要管理员授权才返回。上游共享的应用不返回该字段
        /// </summary>
        public string? Email { get; set; }
        /// <summary>
        /// 企业邮箱;代开发自建应用不返回该字段。上游共享的应用不返回该字段
        /// </summary>
        public string? BizMail { get; set; }
        /// <summary>
        /// 激活状态：1=已激活 2=已禁用 4=未激活 已激活代表已激活企业微信或已关注微信插件（原企业号）5=成员退出
        /// </summary>
        public int? Status { get; set; }
        /// <summary>
        /// 头像url。注：如果要获取小图将url最后的”/0”改成”/100”即可。上游共享的应用不返回该字段
        /// </summary>
        public string? Avatar { get; set; }
        /// <summary>
        /// 成员别名。上游共享的应用不返回该字段
        /// </summary>
        public string? Alias { get; set; }
        /// <summary>
        /// 座机;代开发自建应用需要管理员授权才返回。上游共享的应用不返回该字段
        /// </summary>
        public string? Telephone { get; set; }
        /// <summary>
        /// 地址;代开发自建应用需要管理员授权才返回。上游共享的应用不返回该字段
        /// </summary>
        public string? Address { get; set; }
        /// <summary>
        /// 扩展属性;代开发自建应用需要管理员授权才返回。上游共享的应用不返回该字段
        /// </summary>
        public List<ExternalAttrItemInfo>? ExtAttr { get; set; }
    }
}
