﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models
{
    public class NotifyParam
    {
        /// <summary>
        /// 企业微信加密签名，msg_signature计算结合了企业填写的token、请求中的timestamp、nonce、加密的消息体。签名计算方法参考 消息体签名检验
        /// </summary>
        [FromQuery(Name = "msg_signature")]
        public string? MsgSignature { get; set; }

        /// <summary>
        /// 时间戳。与nonce结合使用，用于防止请求重放攻击。
        /// </summary>
        [FromQuery]
        public string Timestamp { get; set; }

        /// <summary>
        /// 随机数。与timestamp结合使用，用于防止请求重放攻击。
        /// </summary>
        [FromQuery]
        public string? Nonce { get; set; }
    }
}
