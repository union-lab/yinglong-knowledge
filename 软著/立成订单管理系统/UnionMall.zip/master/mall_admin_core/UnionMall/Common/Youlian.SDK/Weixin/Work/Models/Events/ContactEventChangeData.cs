﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.SDK.Weixin.Work.Models.User;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 更新通讯录事件回调数据
    /// </summary>
    public class ContactEventChangeData : EventChangeData
    {
        /// <summary>
        /// 更新通讯录类型
        /// create_user,update_user,delete_user,create_party,update_party,delete_party
        /// </summary>
        public string? ChangeType { get; set; }
    }
}
