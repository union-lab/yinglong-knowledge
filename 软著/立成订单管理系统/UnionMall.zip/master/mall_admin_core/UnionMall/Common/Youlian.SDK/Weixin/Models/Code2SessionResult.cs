﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Models
{
    /// <summary>
    /// 获取登录Session
    /// </summary>
    public class Code2SessionResult : BaseResult
    {
        /// <summary>
        /// 用户唯一标识
        /// </summary>
        public string? OpenId { get; set; }

        /// <summary>
        /// 会话密钥
        /// </summary>
        [JsonProperty("session_key")]
        public string? SessionKey { get; set; }

        /// <summary>
        /// 用户在开放平台的唯一标识符，若当前小程序已绑定到微信开放平台帐号下会返回<see cref="https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/union-id.html"/>
        /// </summary>
        public string? UnionId { get; set; }
    }
}
