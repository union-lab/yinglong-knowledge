﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 申请人信息
    /// </summary>
    public class Applyer
    {
        /// <summary>
        /// 申请人userid
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 申请人所在部门id
        /// </summary>
        public string PartyId { get; set; }
    }
}
