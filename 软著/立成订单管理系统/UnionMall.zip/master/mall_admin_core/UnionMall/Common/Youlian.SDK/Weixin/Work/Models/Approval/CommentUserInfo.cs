﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 备注人信息
    /// </summary>
    public class CommentUserInfo
    {
        /// <summary>
        /// 
        /// </summary>
        public string UserId { get; set; }
    }
}
