﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 内容控件
    /// </summary>
    public class ContentsControl
    {
        /// <summary>
        /// 控件类型：Text-文本；Textarea-多行文本；Number-数字；Money-金额；Date-日期/日期+时间；Selector-单选/多选；；Contact-成员/部门；Tips-说明文字；File-附件；Table-明细；Attendance-假勤；Vacation-请假；PunchCorrection-补卡;DateRange-时长
        /// </summary>
        public string? Control { get; set; }
        /// <summary>
        /// 控件id
        /// </summary>
        public string? Id { get; set; }
        /// <summary>
        /// 控件名称
        /// </summary>
        public List<ControlTitleItem>? Title { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public ControlValue? Value { get; set; }
    }

    /// <summary>
    /// 内容控件分类
    /// </summary>
    public static class ContentsControlType
    {
        /// <summary>
        /// 文本
        /// </summary>
        public const string Text = "Text";
        /// <summary>
        /// 多行文本
        /// </summary>
        public const string Textarea = "Textarea";
        /// <summary>
        /// 数字
        /// </summary>
        public const string Number = "Number";
        /// <summary>
        /// 金额
        /// </summary>
        public const string Money = "Money";
        /// <summary>
        /// 日期/日期+时间
        /// </summary>
        public const string Date = "Date";
        /// <summary>
        /// 单选/多选
        /// </summary>
        public const string Selector = "Selector";
        /// <summary>
        /// 成员/部门
        /// </summary>
        public const string Contact = "Contact";
        /// <summary>
        /// 说明文字
        /// </summary>
        public const string Tips = "Tips";
        /// <summary>
        /// 附件
        /// </summary>
        public const string File = "File";
        /// <summary>
        /// 明细
        /// </summary>
        public const string Table = "Table";
        /// <summary>
        /// 假勤
        /// </summary>
        public const string Attendance = "Attendance";
        /// <summary>
        /// 请假
        /// </summary>
        public const string Vacation = "Vacation";
        /// <summary>
        /// 时长
        /// </summary>
        public const string DateRange = "DateRange";
    }
}
