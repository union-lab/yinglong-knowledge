﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 单选/多选控件
    /// </summary>
    public class SelectorControlValue
    {
        /// <summary>
        /// 选择类型：single-单选；multi-多选，在假勤控件中固定为单选
        /// </summary>
        public string? Type { get; set; }
        /// <summary>
        /// 申请人所选择的选项，多选情况下可能有多个（仅包含申请人说选择的选项，并非所有选项，若需要了解所有选项，需使用“获取审批模板详情”接口）
        /// </summary>
        public List<SelectorControlOption> Options { get; set; } = new List<SelectorControlOption>();
    }
    /// <summary>
    /// 选项内容
    /// </summary>
    public class SelectorControlOption
    {
        /// <summary>
        /// 选项key，选项的唯一id，可通过“获取审批模板详情”接口获得
        /// </summary>
        public string? Key { get; set; }
        /// <summary>
        /// 选项值，若配置了多语言则会包含中英文的选项值
        /// </summary>
        public List<SelectorControlOptionValue>? Value { get; set; }
    }
    /// <summary>
    /// 选项值
    /// </summary>
    public class SelectorControlOptionValue
    {
        /// <summary>
        /// 病假
        /// </summary>
        public string? Text { get; set; }
        /// <summary>
        /// 语言
        /// </summary>
        public string? Lang { get; set; }
    }
}
