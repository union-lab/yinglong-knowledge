﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models.Client
{
    public class JsApiTicketResult:BaseResult
    {
        /// <summary>
        /// 生成签名所需的jsapi_ticket，最长为512字节
        /// </summary>
        public string? Ticket { get; set; }

        /// <summary>
        /// 凭证的有效时间（秒）
        /// </summary>
        [JsonProperty("expires_in")]
        public int ExpiresIn { get; set; }
    }
}
