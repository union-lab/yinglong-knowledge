﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 明细内容，一个明细控件可能包含多个子明细
    /// </summary>
    public class TableControlValue
    {
        /// <summary>
        /// 子明细列表，包含了申请人在子明细的所有子控件中填写的内容，子控件的数据接口同一般控件
        /// </summary>
        public List<ContentsControl>? List { get; set; }
    }
}
