﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    public class TextMessageSendParam : BaseMessageSendParam
    {
        /// <summary>
        /// 消息内容，最长不超过2048个字节，超过将截断（支持id转译）
        /// </summary>
        [JsonProperty("text")]
        public TextMessageTextInfo Text { get; set; } = new TextMessageTextInfo();
    }


    public class TextMessageTextInfo
    {
        /// <summary>
        /// 消息内容，最长不超过2048个字节，超过将截断（支持id转译）
        /// </summary>
        [JsonProperty("content")]
        public string Content { get; set; } = string.Empty;
    }
}
