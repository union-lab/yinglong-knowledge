﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 企业微信用户信息
    /// </summary>
    public class UserSimpleInfo
    {
        /// <summary>
        /// 成员UserID。对应管理端的帐号
        /// </summary>
        public string? UserId { get; set; }
        /// <summary>
        /// 成员名称，代开发自建应用需要管理员授权才返回；此字段从2019年12月30日起，对新创建第三方应用不再返回真实name，使用userid代替name，2020年6月30日起，对所有历史第三方应用不再返回真实name，使用userid代替name，后续第三方仅通讯录应用可获取，未返回名称的情况需要通过通讯录展示组件来展示名字
        /// </summary>
        public string? Name { get; set; }
        /// <summary>
        /// 成员所属部门列表。列表项为部门ID，32位整型
        /// </summary>
        public IList<int> Department { get; set; } = new List<int>();
        /// <summary>
        /// 全局唯一。对于同一个服务商，不同应用获取到企业内同一个成员的open_userid是相同的，最多64个字节。仅第三方应用可获取
        /// </summary>
        [JsonProperty("open_userid")]
        public string? OpenUserId { get; set; }
    }

    /// <summary>
    /// 企业微信部门成员列表
    /// </summary>
    public class UserSimpleListResult : BaseResult
    {
        /// <summary>
        /// 成员列表
        /// </summary>
        public IList<UserSimpleInfo> UserList { get; set; } = new List<UserSimpleInfo>();
    }
}