﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;

namespace Youlian.SDK.Weixin.Work.Models.OA.Attendance
{
    /// <summary>
    /// 考勤机打卡记录
    /// </summary>
    public class HardwareCheckInDataResult : BaseResult
    {
        /// <summary>
        /// 
        /// </summary>
        public List<HardwareCheckInDataInfo>? CheckInData { get; set; }
    }

    /// <summary>
    /// 考勤机打卡记录
    /// </summary>
    public class HardwareCheckInDataInfo
    {
        public string? UserId { get; set; }

        [JsonProperty("checkin_time")]
        public int CheckInTime { get; set; }

        [JsonProperty("device_sn")]
        public string? DeviceSn { get; set; }

        [JsonProperty("device_name")]
        public string? DeviceName { get; set; }

        public DateTime Time => Extention.ConvertToDateTime(CheckInTime);
    }
}
