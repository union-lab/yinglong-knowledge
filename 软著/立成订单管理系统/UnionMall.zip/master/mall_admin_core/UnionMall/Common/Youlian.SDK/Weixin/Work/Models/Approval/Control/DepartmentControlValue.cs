﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 部门控件
    /// </summary>
    public class DepartmentControlValue
    {
        /// <summary>
        /// 部门id
        /// </summary>
        [JsonProperty("openapi_id")]
        public string? OpenApiId { get; set; }
        /// <summary>
        /// 部门名
        /// </summary>
        public string? Name { get; set; }
    }
}
