﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    ///  事件回调数据
    /// </summary>
    public class EventChangeData
    {
        /// <summary>
        /// 
        /// </summary>
        public string? ToUserName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string? FromUserName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string? CreateTime { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string? MsgType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string? Event { get; set; }
    }
}
