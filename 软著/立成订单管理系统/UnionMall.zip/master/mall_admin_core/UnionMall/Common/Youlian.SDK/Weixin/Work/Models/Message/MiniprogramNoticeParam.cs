﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 小程序通知参数
    /// </summary>
    public class MiniprogramNoticeParam : BaseMessageSendParam
    {
        /// <summary>
        /// 小程序消息
        /// </summary>
        [JsonProperty("miniprogram_notice")]
        public MiniprogramNoticeInfo MiniprogramNotice { get; set; } = new MiniprogramNoticeInfo();
    }


    public class MiniprogramNoticeInfo
    {
        /// <summary>
        /// 小程序appid，必须是与当前应用关联的小程序
        /// </summary>
        [JsonProperty("appid")]
        public string AppId { get; set; }

        /// <summary>
        /// 点击消息卡片后的小程序页面，仅限本小程序内的页面。该字段不填则消息点击后不跳转。
        /// </summary>
        [JsonProperty("page")]
        public string Page { get; set; }

        /// <summary>
        /// 消息标题，长度限制4-12个汉字（支持id转译）
        /// </summary>
        [JsonProperty("title")]
        public string Title { get; set; }

        /// <summary>
        /// 消息描述，长度限制4-12个汉字（支持id转译）
        /// </summary>
        [JsonProperty("description")]
        public string Description { get; set; }

        /// <summary>
        /// 是否放大第一个content_item
        /// </summary>
        [JsonProperty("emphasis_first_item")]
        public bool emphasis_first_item { get; set; }

        /// <summary>
        /// 消息内容键值对，最多允许10个item
        /// Key:长度10个汉字以内
        /// Value:长度30个汉字以内（支持id转译）
        /// </summary>
        [JsonProperty("content_item")]
        public List<KeyValuePair<string, string>> content_item { get; set; }
    }
}
