﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 验证URL有效性参数
    /// </summary>
    public class NotifyVerifyParam : NotifyParam
    {
        /// <summary>
        /// 加密的字符串。需要解密得到消息内容明文，解密后有random、msg_len、msg、receiveid四个字段，其中msg即为消息内容明文
        /// </summary>
        public string? EchoStr { get; set; }
    }
}
