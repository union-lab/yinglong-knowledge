﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Common.Service.Http;
using Youlian.SDK.Weixin.Models;
using Youlian.SDK.Weixin.MP.Models;

namespace Youlian.SDK.Weixin.MP
{
    public class MPApi : BaseWeixinApi
    {
        /// <summary>
        /// 公众号ID
        /// </summary>
        public static string MPAppId => AppSettings.Configuration.GetSection("Weixin:MP:AppId").Value;
        public static string MPSecret => AppSettings.Configuration.GetSection("Weixin:MP:Secret").Value;
        private static readonly object lockObj = new();
        #region 网页授权
        #region 获取网页授权token
        /// <summary>
        /// 获取token
        /// </summary>
        /// <param name="appType"></param>
        /// <param name="secret"></param>
        /// <returns></returns>
        public static AccessTokenResult GetAuthAccessToken(string code)
        {
            string key = string.Format(CacheKeys.WeixinAuthAccessToken, code);
            var value = _cache.Get<AccessTokenResult>(key);
            if (value==null)
            {
                lock (lockObj)
                {
                    value = _cache.Get<AccessTokenResult>(key);
                    if (value == null)
                    {
                        var result = GetAuthAccessTokenAsync(code).Result;
                        if (result != null)
                        {
                            _cache.Set(key, result, TimeSpan.FromSeconds(result.expires_in - 100));//提前100秒失效token
                            return result;
                        }
                    }

                }
            }
            return value;
        }
        #endregion

        #region 获取网页授权访问token
        /// <summary>
        /// 获取网页授权访问token
        /// </summary>
        /// <returns></returns>
        private static async Task<AccessTokenResult> GetAuthAccessTokenAsync(string code)
        {
            string url = $"{HOST}/sns/oauth2/access_token?appid={MPAppId}&secret={MPSecret}&code={code}&grant_type=authorization_code";
            return await GetAsync<AccessTokenResult>(url);
        }
        #endregion
        #endregion

        #region 获取用户基本信息
        /// <summary>
        /// 获取用户基本信息
        /// </summary>
        /// <returns></returns>
        public static async Task<SubscribeUserInfo> GetSubscribeUserInfoByCodeAsync(string code)
        {
            var authAccessResult = GetAuthAccessToken(code);
            if (authAccessResult == null) return null;
            return await GetSubscribeUserInfoAsync(authAccessResult.openid);
        }
        public static async Task<SubscribeUserInfo> GetSubscribeUserInfoAsync(string openId)
        {
            var url = $"{HOST}/cgi-bin/user/info?access_token={GetToken(MPAppId, MPSecret)}&openid={openId}&lang=zh_CN";
            return await GetAsync<SubscribeUserInfo>(url);
        }
        #endregion
        #region 获取网页授权
        /// <summary>
        /// 获取网页授权
        /// </summary>
        /// <param name="needConfirm">是否需要确认</param>
        /// <param name="redirectUri"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public static string GetOauth2Authorize(bool needConfirm, string redirectUri, string state)
        {
            return $"https://open.weixin.qq.com/connect/oauth2/authorize?appid={MPAppId}&response_type=code&scope={(needConfirm ? "snsapi_userinfo" : "snsapi_base")}&redirect_uri={Uri.EscapeDataString(redirectUri)}&state={state}#wechat_redirect";
        }

        /// <summary>
        /// 获取网页授权用户信息
        /// </summary>
        /// <param name="needConfirm"></param>
        /// <param name="redirectUri"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public static async Task<UserInfo> GetUserInfoAsync(string code)
        {
            var authAccessResult = GetAuthAccessToken(code);
            if (authAccessResult == null) return null;
            var url = $"{HOST}/sns/userinfo?access_token={authAccessResult.access_token}&openid={authAccessResult.openid}&lang=zh_CN";
            return await GetAsync<UserInfo>(url);
        }
        #endregion
    }
}
