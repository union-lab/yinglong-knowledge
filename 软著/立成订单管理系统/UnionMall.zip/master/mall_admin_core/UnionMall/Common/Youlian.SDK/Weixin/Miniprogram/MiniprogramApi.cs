﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Common.Service.Http;
using Youlian.SDK.Weixin.Miniprogram.Models;
using Youlian.SDK.Weixin.Models;

namespace Youlian.SDK.Weixin.Miniprogram
{
    public class MiniprogramApi : BaseWeixinApi
    {

        #region 检查违规内容
        /// <summary>
        /// 检查一段文本是否含有违法违规内容
        /// </summary>
        /// <returns></returns>
        public static async Task<MsgSecCheckResult> MsgSecCheck(string appId, string openId, string content, int scene = 3)
        {
            var secret = AppSettings.Configuration.GetSection($"Weixin:App:{appId}:Secret").Value;
            string url = $"{HOST}/wxa/msg_sec_check?access_token={GetToken(appId, secret)}";
            var param = new Dictionary<string, string>()
            {
                { "version","2" },
                { "openid",openId },
                { "scene",scene.ToString()},
                { "content",content }
            };
            return await GetAsync<MsgSecCheckResult>(url, param);
        }
        #endregion
    }
}
