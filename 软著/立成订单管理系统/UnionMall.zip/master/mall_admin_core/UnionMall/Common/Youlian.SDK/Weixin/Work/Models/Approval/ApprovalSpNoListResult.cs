﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 审批单列表结果
    /// </summary>
    public class ApprovalSpNoListResult : BaseResult
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("sp_no_list")]
        public List<string> SpNoList { get; set; } = new List<string>();
    }
}
