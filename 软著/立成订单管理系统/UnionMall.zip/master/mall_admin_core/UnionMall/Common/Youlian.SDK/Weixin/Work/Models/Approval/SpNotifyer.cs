﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.Approval
{
    /// <summary>
    /// 通知人
    /// </summary>
    public class SpNotifyer
    {
        /// <summary>
        /// 
        /// </summary>
        public string UserId { get; set; }
    }
}
