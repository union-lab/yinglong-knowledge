﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Cache;
using Youlian.Common.Extention;
using Youlian.Common.Helpers;
using Youlian.Common.Service.Http;
using Youlian.SDK.Weixin.Work.Models;
using Youlian.SDK.Weixin.Work.Models.Approval;
using Youlian.SDK.Weixin.Work.Models.OA;
using Youlian.SDK.Weixin.Work.Models.OA.Attendance;

namespace Youlian.SDK.Weixin.Work
{
    /// <summary>
    /// 通用API
    /// </summary>
    public class WorkWeixinApi : BaseWeixinApi
    {
        #region 获取访问用户身份
        /// <summary>
        /// 获取访问用户身份
        /// </summary>
        /// <param name="appId"></param>
        /// <param name="code">通过成员授权获取到的code，最大为512字节。每次成员授权带上的code将不一样，code只能使用一次，5分钟未被使用自动过期。</param>
        /// <returns></returns>
        public static async Task<AccessUserResult?> GetAccessUserAsync(int agentId, string code)
        {
            string url = $"{HOST}/cgi-bin/user/getuserinfo";
            var param = new Dictionary<string, string>()
            {
                { "access_token",ApiHelper.GetToken(agentId) },
                { "code",code }
            };
            return await GetAsync<AccessUserResult>(url, param);
        }
        #endregion

        #region 读取成员
        /// <summary>
        /// 读取成员
        /// </summary>
        /// <param name="agentId">传0则使用通讯录获取</param>
        /// <param name="userId">成员UserID。对应管理端的帐号，企业内必须唯一。不区分大小写，长度为1~64个字节</param>
        /// <returns></returns>
        public static async Task<UserInfoResult> GetUserInfoAsync(int agentId, string userId)
        {
            string url = $"{HOST}/cgi-bin/user/get";
            var param = new Dictionary<string, string>()
            {
                { "access_token",agentId>0 ?ApiHelper.GetToken(agentId):ApiHelper.GetToken(AppTypeEnum.通讯录) },
                { "userid",userId }
            };
            return await GetAsync<UserInfoResult>(url, param);
        }
        #endregion

        #region 获取登录二维码
        /// <summary>
        /// 获取登录二维码
        /// </summary>
        /// <param name="redirectUri"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public static string GetSsoQrConnect(int agentId, string redirectUri, string state)
        {
            return $"https://open.work.weixin.qq.com/wwopen/sso/qrConnect?appid={CorpId}&agentid={agentId}&redirect_uri={Uri.EscapeDataString(redirectUri)}&state={state}";
        }
        #endregion

        #region 获取登录授权
        /// <summary>
        /// 获取登录授权
        /// </summary>
        /// <param name="redirectUri"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public static string GetOauth2Authorize(string redirectUri, string state)
        {
            return $"https://open.weixin.qq.com/connect/oauth2/authorize?appid={CorpId}&response_type=code&scope=snsapi_base&redirect_uri={Uri.EscapeDataString(redirectUri)}&state={state}##wechat_redirect";
        }
        /// <summary>
        /// 获取登录授权（用户确认）
        /// </summary>
        /// <param name="appId"></param>
        /// <param name="redirectUri"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public static string GetOauth2Authorize(string appId, string redirectUri, string state)
        {
            return $"https://open.weixin.qq.com/connect/oauth2/authorize?appid={appId}&response_type=code&scope=snsapi_userinfo&redirect_uri={Uri.EscapeDataString(redirectUri)}&state={state}##wechat_redirect";
        }
        #endregion

        #region 获取小程序登录Session
        /// <summary>
        /// 获取小程序登录Session
        /// </summary>
        /// <returns></returns>
        public static async Task<Code2SessionResult> Code2Session(int agentId, string js_code)
        {
            string url = $"{HOST}/cgi-bin/miniprogram/jscode2session?access_token={ApiHelper.GetToken(agentId)}&js_code={js_code}&grant_type=authorization_code";
            return await GetAsync<Code2SessionResult>(url);
        }
        #endregion

        #region openid转userid
        /// <summary>
        /// openid转userid
        /// </summary>
        /// <returns></returns>
        public static async Task<OpenIdToUserIdResult> GetUserIdByOpenId(string openId)
        {
            string url = $"{HOST}/cgi-bin/user/convert_to_userid?access_token={ApiHelper.GetToken(AppTypeEnum.通讯录)}";
            var param = new Dictionary<string, string>()
            {
                { "openid", openId},
            };
            return await PostAsync<OpenIdToUserIdResult, Dictionary<string, string>>(url, param);
        }
        #endregion

        #region 手机号转userid
        /// <summary>
        /// 手机号转userid
        /// </summary>
        /// <returns></returns>
        public static async Task<MobileToUserIdResult> GetUserIdByTel(string tel)
        {
            string url = $"{HOST}/cgi-bin/user/getuserid?access_token={ApiHelper.GetToken(AppTypeEnum.通讯录)}";
            var param = new Dictionary<string, string>()
            {
                { "mobile", tel},
            };
            return await PostAsync<MobileToUserIdResult, Dictionary<string, string>>(url, param);
        }
        #endregion

        #region 获取部门列表
        /// <summary>
        /// 获取部门列表
        /// </summary>
        /// <returns></returns>
        public static async Task<DepartmentListResult> GetDepartmentListAsync()
        {
            string url = $"{HOST}/cgi-bin/department/list";
            var param = new Dictionary<string, string>()
            {
                { "access_token", ApiHelper.GetToken(AppTypeEnum.通讯录) },
                { "department_id","1" },//整个部门
                { "fetch_child","1" },//1-递归获取，0-只获取本部门
            };
            return await GetAsync<DepartmentListResult>(url, param);
        }
        #endregion

        #region 获取部门详情
        /// <summary>
        /// 获取部门详情
        /// </summary>
        /// <returns></returns>
        public static async Task<DepartmentInfoResult> GetDepartmentInfo(int id)
        {
            string url = $"{HOST}/cgi-bin/department/get";
            var param = new Dictionary<string, string>()
            {
                { "access_token", ApiHelper.GetToken(AppTypeEnum.通讯录) },
                { "id",id.ToString() },//整个部门
            };
            return await GetAsync<DepartmentInfoResult>(url, param);
        }
        #endregion

        #region 获取成员简单列表
        /// <summary>
        /// 获取成员简单列表
        /// </summary>
        /// <returns></returns>
        public static async Task<UserSimpleListResult> GetUserSimpleListAsync()
        {
            string url = $"{HOST}/cgi-bin/user/simplelist";
            var param = new Dictionary<string, string>()
            {
                { "access_token", ApiHelper.GetToken(AppTypeEnum.通讯录) },
                //{ "id","1" },//整个部门
            };
            return await GetAsync<UserSimpleListResult>(url, param);
        }
        #endregion

        #region 获取成员列表
        /// <summary>
        /// 获取成员列表
        /// </summary>
        /// <returns></returns>
        public static async Task<UserListResult> GetUserListAsync(AppTypeEnum appType)
        {
            string url = $"{HOST}/cgi-bin/user/list";
            var param = new Dictionary<string, string>()
            {
                { "access_token", ApiHelper.GetToken(appType) },
                { "department_id","1" },//整个部门
                { "fetch_child","1" },//1-递归获取，0-只获取本部门
            };
            return await GetAsync<UserListResult>(url, param);
        }
        #endregion

        #region 创建成员
        /// <summary>
        /// 创建成员
        /// </summary>
        /// <returns></returns>
        public static async Task<BaseResult> CreateUser(CreateUserParam param)
        {
            string url = $"{HOST}/cgi-bin/user/create?access_token={ApiHelper.GetToken(AppTypeEnum.通讯录)}";
            return await PostAsync<BaseResult, CreateUserParam>(url, param);
        }
        #endregion

        #region 更新成员
        /// <summary>
        /// 更新成员
        /// </summary>
        /// <returns></returns>
        public static async Task<BaseResult> UpdateUserDepartmnet(string userId, string position)
        {
            string url = $"{HOST}/cgi-bin/user/update?access_token={ApiHelper.GetToken(AppTypeEnum.通讯录)}";
            var param = new Dictionary<string, string>()
            {
                { "userid",userId },
                { "position",position },//1-递归获取，0-只获取本部门
            };
            return await PostAsync<BaseResult, Dictionary<string, string>>(url, param);
        }
        #endregion

        #region 删除成员
        /// <summary>
        /// 删除成员
        /// </summary>
        /// <returns></returns>
        public static async Task<BaseResult> DeleteUser(string userId)
        {
            string url = $"{HOST}/cgi-bin/user/delete?access_token={ApiHelper.GetToken(AppTypeEnum.通讯录)}";
            var param = new Dictionary<string, string>()
            {
                { "userid",userId },
            };
            return await GetAsync<BaseResult>(url, param);
        }
        #endregion

        #region 获取审批模板
        /*/// <summary>
        /// 获取审批模板
        /// </summary>
        /// <returns></returns>
        public static async Task<ApprovalInfo> GetApprovalDetail(string templateId)
        {
            string url = $"{WeixinApi.HOST}/cgi-bin/oa/gettemplatedetail?access_token={ApiHelper.GetToken(AppTypeEnum.审批)}";
            var param = new Dictionary<string, string>()
            {
                { "template_id", templateId }
            };
            return await PostAsync<ApprovalInfo, Dictionary<string, string>>(url, param);
        }*/
        #endregion

        #region 获取审批申请详情
        /// <summary>
        /// 获取审批申请详情
        /// </summary>
        /// <returns></returns>
        public static async Task<ApprovalInfo> GetApprovalDetail(string spno)
        {
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/oa/getapprovaldetail?access_token={ApiHelper.GetToken(AppTypeEnum.审批)}";
            var param = new Dictionary<string, string>()
            {
                { "sp_no", spno }
            };
            return await PostAsync<ApprovalInfo, Dictionary<string, string>>(url, param);
        }
        #endregion

        #region 批量获取审批单号
        /// <summary>
        /// 批量获取审批单号
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <param name="cursor">分页查询游标，默认为0，后续使用返回的next_cursor进行分页拉取</param>
        /// <param name="templateId">模板类型/模板id</param>
        /// <param name="creator">申请人userid</param>
        /// <param name="departmentIds">审批单提单者所在部门</param>
        /// <param name="spStatu">审批状态:1-审批中；2-已通过；3-已驳回；4-已撤销；6-通过后撤销；7-已删除；10-已支付</param>
        /// <param name="recordType">审批单类型属性，1-请假；2-打卡补卡；3-出差；4-外出；5-加班； 6- 调班；7-会议室预定；8-退款审批；9-红包报销审批</param>
        /// <returns></returns>
        public static async Task<ApprovalSpNoListResult> GetApprovalSpNoList(DateTime startTime, DateTime endTime, int cursor, string? templateId = null, string? creator = null, List<int>? departmentIds = null, int? spStatu = null, int? recordType = null)
        {
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/oa/getapprovalinfo?access_token={ApiHelper.GetToken(AppTypeEnum.审批)}";
            var filters = new List<KeyValuePair<string, string>>();
            if (templateId != null)
                filters.Add(new KeyValuePair<string, string>("template_id", templateId));
            if (creator != null)
                filters.Add(new KeyValuePair<string, string>("creator", creator));
            if (spStatu != null)
                filters.Add(new KeyValuePair<string, string>("sp_status", spStatu.Value.ToString()));
            if (recordType != null)
                filters.Add(new KeyValuePair<string, string>("record_type", recordType.Value.ToString()));
            if (departmentIds != null)
            {
                foreach (var item in departmentIds)
                {
                    filters.Add(new KeyValuePair<string, string>("department", item.ToString()));
                }
            }
            var param = new Dictionary<string, object>()
            {
                { "starttime", startTime.ToUnixTimeStamp() },
                { "endtime", endTime.ToUnixTimeStamp() },
                { "cursor", cursor },
                { "filters", filters.ToCamelCaseJson().ToObject<dynamic>() }
            };

            return await PostAsync<ApprovalSpNoListResult, Dictionary<string, object>>(url, param);
        }
        #endregion

        #region 获取企业假期管理配置
        /// <summary>
        /// 获取企业假期管理配置
        /// </summary>
        /// <returns></returns>
        public static async Task<VacationConfigResult> GetVacationConfig()
        {
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/oa/vacation/getcorpconf?access_token={ApiHelper.GetToken(AppTypeEnum.审批)}";
            return await GetAsync<VacationConfigResult>(url);
        }
        #endregion

        #region 获取成员假期余额
        /// <summary>
        /// 获取成员假期余额
        /// </summary>
        /// <returns></returns>
        public static async Task<UserVacationQuotaResult> GetUserVacationQuota(string userId)
        {
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/oa/vacation/getuservacationquota?access_token={ApiHelper.GetToken(AppTypeEnum.审批)}";
            var param = new Dictionary<string, string>()
            {
                { "userid", userId },
            };
            return await PostAsync<UserVacationQuotaResult, Dictionary<string, string>>(url, param);
        }
        #endregion

        #region 设置成员假期余额
        /// <summary>
        /// 设置成员假期余额
        /// </summary>
        /// <param name="userId">需要修改假期余额的成员的userid</param>
        /// <param name="vacationId">假期id</param>
        /// <param name="leftduration">设置的假期余额,单位为秒,不能大于1000天或24000小时，当假期时间刻度为按小时请假时，必须为360整倍数，即0.1小时整倍数，按天请假时，必须为8640整倍数，即0.1天整倍数</param>
        /// <param name="timeAttr">假期时间刻度：0-按天请假；1-按小时请假,主要用于校验，必须等于企业假期管理配置中设置的假期时间刻度类型</param>
        /// <param name="remarks">修改备注，用于显示在假期余额的修改记录当中，可对修改行为作说明，不超过200字符</param>
        /// <returns></returns>
        public static async Task<BaseResult> SetOneUserQuota(string userId, int vacationId, int leftduration, int timeAttr, string remarks)
        {
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/oa/vacation/setoneuserquota?access_token={ApiHelper.GetToken(AppTypeEnum.审批)}";
            var param = new Dictionary<string, string>()
            {
                { "userid", userId },
                { "vacation_id", vacationId.ToString() },
                { "leftduration", leftduration.ToString() },
                { "time_attr", timeAttr.ToString() },
                { "remarks", remarks },
            };
            return await PostAsync<BaseResult, Dictionary<string, string>>(url, param);
        }
        #endregion

        #region 获取设备打卡记录
        /// <summary>
        /// 获取设备打卡记录
        /// </summary>
        /// <returns></returns>
        public static async Task<HardwareCheckInDataResult> GetHardwareCheckInData(DateTime startTime, DateTime endTime, List<string> userIdList)
        {
            string url = $"{HOST}/cgi-bin/hardware/get_hardware_checkin_data?access_token={ApiHelper.GetToken(AppTypeEnum.考勤打卡)}";
            var param = new Dictionary<string, object>()
            {
                { "filter_type", 1 },
                { "starttime", startTime.ToUnixTimeStamp() },
                { "endtime",endTime.ToUnixTimeStamp() },
                { "useridlist", userIdList}
            };
            return await PostAsync<HardwareCheckInDataResult, Dictionary<string, object>>(url, param);
        }
        #endregion

        #region 获取打卡日报
        /// <summary>
        /// 获取打卡日报
        /// </summary>
        /// <returns></returns>
        public static async Task<CheckInDayDataResult> GetCheckInDayData(DateTime startTime, DateTime endTime, List<string> userIdList)
        {
            string url = $"{HOST}/cgi-bin/checkin/getcheckin_daydata?access_token={ApiHelper.GetToken(AppTypeEnum.考勤打卡)}";
            var param = new Dictionary<string, object>()
            {
                { "starttime", startTime.ToUnixTimeStamp() },
                { "endtime",endTime.ToUnixTimeStamp() },
                { "useridlist", userIdList}
            };
            return await PostAsync<CheckInDayDataResult, Dictionary<string, object>>(url, param);
        }
        #endregion

        #region 获取打卡记录
        /// <summary>
        /// 获取打卡记录
        /// </summary>
        /// <param name="dataType">打卡类型。1：上下班打卡；2：外出打卡；3：全部打卡</param>
        /// <returns></returns>
        public static async Task<CheckInDataResult> GetCheckInData(int dataType,DateTime startTime, DateTime endTime, List<string> userIdList)
        {
            string url = $"{HOST}/cgi-bin/checkin/getcheckindata?access_token={ApiHelper.GetToken(AppTypeEnum.考勤打卡)}";
            var param = new Dictionary<string, object>()
            {
                { "opencheckindatatype", dataType},
                { "starttime", startTime.ToUnixTimeStamp() },
                { "endtime",endTime.ToUnixTimeStamp() },
                { "useridlist", userIdList}
            };
            return await PostAsync<CheckInDataResult, Dictionary<string, object>>(url, param);
        }
        #endregion

        #region 消息推送
        #region 发送文本消息
        /// <summary>
        /// 发送文本消息
        /// </summary>
        /// <returns></returns>
        public static async Task<MessageSendResult> SendTextMessage(AppTypeEnum appType, List<string> userIds, string content)
        {
            if (userIds?.Count > 1000) return new MessageSendResult() { ErrCode = -1000, ErrMsg = "接收者数量不能超过1000" };
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/message/send?access_token={ApiHelper.GetToken(appType)}";
            var param = new TextMessageSendParam()
            {
                ToUser = userIds.ToJoinStr("|"),
                MsgType = "text",
                AgentId = ApiHelper.GetAgentId(appType),
                Text = new TextMessageTextInfo()
                {
                    Content = content
                }
            };
            return await PostAsync<MessageSendResult, TextMessageSendParam>(url, param);
        }
        #endregion

        #region 发送文本卡片消息
        /// <summary>
        /// 发送文本卡片消息
        /// </summary>
        /// <returns></returns>
        public static async Task<MessageSendResult> SendTextCardMessage(AppTypeEnum appType, List<string> userIds, string title, string description, string cardUrl)
        {
            if (userIds?.Count > 1000) return new MessageSendResult() { ErrCode = -1000, ErrMsg = "接收者数量不能超过1000" };
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/message/send?access_token={ApiHelper.GetToken(appType)}";
            var param = new TextCardMessageSendParam()
            {
                ToUser = userIds.ToJoinStr("|"),
                MsgType = "textcard",
                AgentId = ApiHelper.GetAgentId(appType),
                TextCard = new TextCardInfo()
                {
                    Title = title,
                    Description = description,
                    Url = cardUrl
                }

            };
            return await PostAsync<MessageSendResult, TextCardMessageSendParam>(url, param);
        }
        #endregion

        #region 撤回文本卡片消息
        /// <summary>
        /// 撤回文本卡片消息
        /// </summary>
        /// <returns></returns>
        public static async Task<BaseResult> RecallTextCardMessage(AppTypeEnum appType, string msgId)
        {
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/message/recall?access_token={ApiHelper.GetToken(appType)}";
            var param = new Dictionary<string, string>()
            {
                { "msgid", msgId }
            };
            return await PostAsync<BaseResult, Dictionary<string, string>>(url, param);
        }
        #endregion

        #region 发送小程序消息
        /// <summary>
        /// 发送小程序消息
        /// </summary>
        /// <returns></returns>
        public static async Task<MessageSendResult> SendMiniprogramNotice(int agentId, string appId, List<string> userIds, string title, string description, string page)
        {
            if (userIds?.Count > 1000) return new MessageSendResult() { ErrCode = -1000, ErrMsg = "接收者数量不能超过1000" };
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/message/send?access_token={ApiHelper.GetToken(agentId)}";
            var param = new MiniprogramNoticeParam()
            {
                ToUser = userIds.ToJoinStr("|"),
                MsgType = "miniprogram_notice",
                MiniprogramNotice = new MiniprogramNoticeInfo()
                {
                    AppId = appId,
                    Page = page,
                    Title = title,
                    Description = description,
                }
            };
            return await PostAsync<MessageSendResult, MiniprogramNoticeParam>(url, param);
        }
        #endregion

        #region 发送模板卡片消息
        /// <summary>
        /// 发送模板卡片消息
        /// </summary>
        /// <returns></returns>
        public static async Task<MessageSendResult> SendTempleteCardTextMessage(AppTypeEnum appType, List<string> userIds, string title, string description)
        {
            if (userIds?.Count > 1000) return new MessageSendResult() { ErrCode = -1000, ErrMsg = "接收者数量不能超过1000" };
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/message/send?access_token={ApiHelper.GetToken(appType)}";
            var param = new TemplateCardMessageSendParam()
            {
                ToUser = userIds.ToJoinStr("|"),
                MsgType = "template_card",
                AgentId = ApiHelper.GetAgentId(appType),
                TemplateCard = new TemplateCardInfo()
                {
                    CardType = "text_notice",
                    MainTitle = new TemplateCardMainTitle()
                    {
                        Title = title,
                        Desc = description,
                    }
                }
            };
            return await PostAsync<MessageSendResult, TemplateCardMessageSendParam>(url, param);
        }
        #endregion
        #endregion

        #region 群聊机器人
        /// <summary>
        /// 发送群聊文本消息
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static async Task<BaseResult> SendChatGroupTextMessage(string message)
        {
            string url = $"{WorkWeixinApi.HOST}/cgi-bin/webhook/send?key={AppSettings.Configuration.GetSection("WorkWeixin:ChatGroupBotKey").Value}";
            var param = new ChatGroupTextMessageSendParam()
            {
                Text = new ChatGroupTextMessageTextInfo()
                {
                    Content = message
                }
            };
            return await PostAsync<BaseResult, ChatGroupTextMessageSendParam>(url, param);
        }
        #endregion
    }
}
