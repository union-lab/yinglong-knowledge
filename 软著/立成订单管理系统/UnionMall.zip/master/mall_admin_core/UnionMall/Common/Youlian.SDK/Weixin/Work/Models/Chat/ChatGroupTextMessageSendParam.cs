﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 发送机器人文本消息
    /// </summary>
    public class ChatGroupTextMessageSendParam
    {
        /// <summary>
        /// 消息类型，此时固定为text
        /// </summary>
        [JsonProperty("msgtype")]
        public string MsgType { get; set; } = "text";

        [JsonProperty("text")]
        public ChatGroupTextMessageTextInfo? Text { get; set; }
    }

    public class ChatGroupTextMessageTextInfo
    {
        /// <summary>
        /// 文本内容，最长不超过2048个字节，必须是utf8编码
        /// </summary>
        [JsonProperty("content")]
        public string? Content { get; set; }
        /// <summary>
        /// userid的列表，提醒群中的指定成员(@某个成员)，@all表示提醒所有人，如果开发者获取不到userid，可以使用mentioned_mobile_list
        /// </summary>
        [JsonProperty("mentioned_list")]
        public IList<string> MentionedList { get; set; } = new List<string>();
        /// <summary>
        /// 手机号列表，提醒手机号对应的群成员(@某个成员)，@all表示提醒所有人
        /// </summary>
        [JsonProperty("mentioned_mobile_list")]
        public IList<string> MentionedMobileList { get; set; } = new List<string>();
    }
}
