﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.User
{
    public class ExternalAttrItemWebInfo
    {
        /// <summary>
        /// 标题
        /// </summary>
        [JsonProperty("title")]
        public string? Titel { get; set; }

        /// <summary>
        /// 链接
        /// </summary>
        [JsonProperty("url")]
        public string? Url { get; set; }
    }
}
