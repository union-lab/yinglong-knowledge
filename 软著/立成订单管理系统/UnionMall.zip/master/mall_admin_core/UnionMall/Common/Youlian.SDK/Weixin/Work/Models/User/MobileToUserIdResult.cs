﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 手机号转UserId
    /// </summary>
    public class MobileToUserIdResult : BaseResult
    {
        /// <summary>
        /// 
        /// </summary>
        public string UserId { get; set; }
    }
}
