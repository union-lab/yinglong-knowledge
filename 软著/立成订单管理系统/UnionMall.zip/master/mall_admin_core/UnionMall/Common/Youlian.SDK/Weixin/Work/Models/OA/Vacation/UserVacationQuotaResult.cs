﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.OA
{
    /// <summary>
    /// 成员假期余额
    /// </summary>
    public class UserVacationQuotaResult : BaseResult
    {
        public List<UserVacationQuotaInfo>? Lists { get; set; }
    }
    /// <summary>
    /// 成员假期余额
    /// </summary>
    public class UserVacationQuotaInfo
    {
        /// <summary>
        /// 假期id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 发放时长，单位为秒
        /// </summary>
        public int AssignDuration { get; set; }
        /// <summary>
        /// 使用时长，单位为秒
        /// </summary>
        public int UsedDuration { get; set; }
        /// <summary>
        /// 剩余时长，单位为秒
        /// </summary>
        public int LeftDuration { get; set; }
        /// <summary>
        /// 假期名称
        /// </summary>
        public string? VacationName { get; set; }
    }

}
