﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models.User
{
    public class WechatChannelsInfo
    {
        /// <summary>
        /// 视频号名称
        /// </summary>
        [JsonProperty("nickname")]
        public string? NickName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Status { get; set; }
    }
}
