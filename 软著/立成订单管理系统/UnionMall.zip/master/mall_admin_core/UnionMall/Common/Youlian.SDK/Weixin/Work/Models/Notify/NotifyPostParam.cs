﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 接收业务数据
    /// </summary>
    [XmlRoot(ElementName = "xml")]
    public class NotifyPostParam
    {
        /// <summary>
        /// 企业微信的CorpID，当为第三方应用回调事件时，CorpID的内容为suiteid
        /// </summary>
        public string? ToUserName { get; set; }

        /// <summary>
        /// 接收的应用id，可在应用的设置页面获取。仅应用相关的回调会带该字段。
        /// </summary>
        public string? AgentID { get; set; }

        /// <summary>
        /// 消息结构体加密后的字符串
        /// </summary>
        public string? Encrypt { get; set; }
    }
}
