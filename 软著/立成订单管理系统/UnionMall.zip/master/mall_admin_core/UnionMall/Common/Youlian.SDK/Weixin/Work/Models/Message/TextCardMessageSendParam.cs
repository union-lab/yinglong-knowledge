﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Youlian.SDK.Weixin.Work.Models
{
    /// <summary>
    /// 卡片消息
    /// </summary>
    public class TextCardMessageSendParam : BaseMessageSendParam
    {
        /// <summary>
        /// 文本卡片
        /// </summary>
        [JsonProperty("textcard")]
        public TextCardInfo TextCard { get; set; } = new TextCardInfo();
    }

    /// <summary>
    /// 文本卡片消息
    /// </summary>
    public class TextCardInfo
    {
        /// <summary>
        /// 标题，不超过128个字节，超过会自动截断（支持id转译）
        /// </summary>
        [JsonProperty("title")]
        public string? Title { get; set; }
        /// <summary>
        /// 描述，不超过512个字节，超过会自动截断（支持id转译）
        /// </summary>
        [JsonProperty("description")]
        public string? Description { get; set; }
        /// <summary>
        /// 点击后跳转的链接。最长2048字节，请确保包含了协议头(http/https)
        /// </summary>
        [JsonProperty("url")]
        public string? Url { get; set; }
        /// <summary>
        /// 按钮文字。 默认为“详情”， 不超过4个文字，超过自动截断。
        /// </summary>
        [JsonProperty("btntxt")]
        public string? BtnTxt { get; set; }
    }
}