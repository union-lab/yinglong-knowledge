﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.SDK.Weixin.Work.Models
{
    public class UserInfoResult: UserInfo, IBaseResult
    {
        /// <summary>
        /// 返回码
        /// </summary>
        public int ErrCode { get; set; }
        /// <summary>
        /// 对返回码的文本描述内容
        /// </summary>
        public string? ErrMsg { get; set; }
        /// <summary>
        /// 是否调用成功
        /// </summary>
        public bool Success => ErrCode == 0;
    }
}
