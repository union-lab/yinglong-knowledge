﻿using Youlian.Common.Extention;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Common.Helpers
{

    /// <summary>
    /// 状态类型
    /// </summary>
    public enum StatusCodeEnum
    {
        /// <summary>
        /// 
        /// </summary>
        [Description("请求(或处理)成功")]
        OK = 200,


        /// <summary>
        /// 
        /// </summary>

        [Description("内部请求出错")]
        Except = 500,


        /// <summary>
        /// 
        /// </summary>

        [Description("访问请求未授权! 当前 SESSION 失效, 请重新登陆")]
        Unauthorized = 401,


        /// <summary>
        /// 
        /// </summary>

        [Description("请求参数不完整或不正确")]
        BadRequest = 400,


        /// <summary>
        /// 
        /// </summary>

        [Description("您无权进行此操作，请求执行已拒绝")]
        Forbidden = 403,


        /// <summary>
        /// 
        /// </summary>

        [Description("找不到与请求匹配的 HTTP 资源")]
        NotFound = 404,


        /// <summary>
        /// 
        /// </summary>

        [Description("HTTP请求类型不合法")]
        HttpMehtodError = 405,


        /// <summary>
        /// 
        /// </summary>

        [Description("HTTP请求不合法,请求参数可能被篡改")]
        HttpRequestError = 406,


        /// <summary>
        /// 
        /// </summary>

        [Description("该URL已经失效")]
        URLExpireError = 407
    }

    public class Result: Result<string>
    {

    }
    /// <summary>c
    /// 泛型对应
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class Result<T> : ActionResult, IActionResult
    {
        /// <summary>
        /// 实现接口
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override async Task ExecuteResultAsync(ActionContext context)
        {
            var setting = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                DateFormatString = "yyyy-MM-dd HH:mm:ss",
            };
            HttpResponse response = context.HttpContext.Response;
            response.ContentType = "application/json";
            response.StatusCode = 200;
            if (string.IsNullOrEmpty(Msg))
            {
                Msg = Code.Display();
            }
            string buf = JsonConvert.SerializeObject(this, setting);
            await response.WriteAsync(buf, Encoding.UTF8);
        }
        /// <summary>
        /// 请求状态
        /// </summary>
        public StatusCodeEnum Code { get; set; }

        /// <summary>
        /// 返回信息
        /// </summary>
        public string Msg { get; set; }

        /// <summary>
        /// 返回时间戳
        /// </summary>
        public string Timestamp { get; set; } = DateTimeOffset.Now.ToUnixTimeSeconds().ToString();
        /// <summary>
        /// 接口返回值
        /// </summary>
        public T Data;
        /// <summary>
        /// 成功
        /// </summary>
        /// <param name="data"></param>
        /// <param name="total"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public Result<T> Ok(T data = default, string msg = "")
        {
            if (data != null)
            {
                Data = data;
            }
            Code = StatusCodeEnum.OK;
            Msg = msg;
            return this;
        }

        /// <summary>
        /// 参数错误
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public Result<T> Bad(string msg)
        {
            Code = StatusCodeEnum.BadRequest;
            Msg = msg;
            return this;
        }
        /// <summary>
        /// 数据不存在
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public Result<T> NotFound(string msg = "")
        {
            Code = StatusCodeEnum.NotFound;
            Msg = string.IsNullOrEmpty(msg) ? "数据不存在!" : msg;
            return this;
        }
        /// <summary>
        /// 异常
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public Result<T> Except(string msg = "")
        {
            Code = StatusCodeEnum.Except;
            Msg = msg;
            return this;
        }
        /// <summary>
        /// 动态
        /// </summary>
        /// <param name="code"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public Result<T> Ret(StatusCodeEnum code, string msg = "")
        {
            Code = code;
            Msg = msg;
            return this;
        }
        public bool OK { get { return Code == StatusCodeEnum.OK; } }
    }
    public class ResultHelper
    {
        public static Result<T> Ok<T>(T data = default, string msg = "")
        {
            return new Result<T>()
            {
                Data = data,
                Code = StatusCodeEnum.OK,
                Msg = msg
            };
        }
        public static Result<int> Ok(int data = 0, string msg = "")
        {
            return new Result<int>()
            {
                Data = data,
                Code = StatusCodeEnum.OK,
                Msg = msg
            };
        }
        public static Result<T> Bad<T>(string msg)
        {
            return new Result<T>()
            {
                Code = StatusCodeEnum.BadRequest,
                Msg = msg
            };
        }
        public static Result<int> Bad(string msg)
        {
            return Bad<int>(msg);
        }
        public static Result<T> Except<T>(string msg)
        {
            return new Result<T>()
            {
                Code = StatusCodeEnum.Except,
                Msg = msg
            };
        }
        public static Result<int> Except(string msg)
        {
            return Except<int>(msg);
        }
        public static Result<T> NotFound<T>(string msg = "")
        {
            return new Result<T>()
            {
                Code = StatusCodeEnum.NotFound,
                Msg = string.IsNullOrEmpty(msg) ? "数据不存在!" : msg
            };
        }
        public static Result<int> NotFound(string msg = "")
        {
            return NotFound<int>(msg);
        }
        public static Result<T> Ret<T>(StatusCodeEnum code, string msg = "", T data = default)
        {
            return new Result<T>()
            {
                Code = code,
                Msg = msg,
                Data = data
            };
        }
        public static Result<int> Ret(StatusCodeEnum code, string msg = "")
        {
            return Ret(code, msg, 0);
        }
    }
}
