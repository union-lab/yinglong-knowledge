﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Common.Cache
{
    public interface ICacheManager
    {
        bool Add(string key, string value, TimeSpan? expiry = null);

        bool SetString(string key, string value, TimeSpan? expiry = null);

        bool Set<T>(string key, T value, TimeSpan? expiry = null);

        string GetString(string key);

        T Get<T>(string key);

        bool Remove(string key);

        bool Refresh(string key);
    }
}
