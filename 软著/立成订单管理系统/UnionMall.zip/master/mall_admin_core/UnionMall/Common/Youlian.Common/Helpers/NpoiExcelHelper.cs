﻿using Microsoft.AspNetCore.Http;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Youlian.Common.Helpers
{
    public class NpoiExcelHelper
    {
        #region 读取Excel数据到DataTable

        /// <summary>
        /// 读取Excel数据到DataTable
        /// </summary>
        /// <param name="excelFile"></param>
        /// <param name="cellHead"></param>
        /// <param name="headRowIndex"></param>
        /// <returns></returns>
        public static Result<DataTable> GetExcelToDataTable(IFormFile excelFile, Dictionary<string, string> cellHead, int headRowIndex = 0)
        {
            try
            {
                if (excelFile == null || excelFile.Length == 0)
                {
                    return ResultHelper.Bad<DataTable>("上传文件为空！");
                }

                string mimeType = excelFile.ContentType;
                var fileex = Path.GetExtension(excelFile.FileName); ;
                if (fileex == ".csv")
                {
                    return ResultHelper.Ok(ReadCSV(excelFile, cellHead));
                }

                MemoryStream ms = new MemoryStream();
                excelFile.CopyTo(ms);
                ms.Seek(0, SeekOrigin.Begin);
                IWorkbook workbook;
                if (mimeType == "application/vnd.ms-excel" || fileex == ".xls")
                {
                    workbook = new HSSFWorkbook(ms);
                }
                else if (mimeType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || fileex == ".xlsx")
                {
                    workbook = new XSSFWorkbook(ms);
                }
                else
                {
                    return ResultHelper.Bad<DataTable>("Excel文件格式不正确，需为：xls 或 xlsx!");
                }

                ISheet sheet = workbook.GetSheetAt(0);
                IRow headerRow = sheet.GetRow(headRowIndex);
                int rowCount = sheet.LastRowNum;
                int cellCount = headerRow.LastCellNum;
                foreach (var cell in cellHead)
                {
                    var isfind = false;
                    for (int j = 0; j < cellCount; j++)
                    {
                        if (cell.Value == headerRow.GetCell(j).ToString().Trim())
                        {
                            isfind = true;
                        }
                    }

                    if (!isfind)
                    {
                        return ResultHelper.Bad<DataTable>($"表格不存在必须列{cell.Value}");
                    }
                }

                DataTable dt = new DataTable();
                for (int j = 0; j < cellCount; j++)
                {
                    foreach (var cell in cellHead)
                    {
                        if (cell.Value == headerRow.GetCell(j).ToString().Trim())
                        {
                            dt.Columns.Add(cell.Key);
                            break;
                        }
                    }
                }

                for (int r = headRowIndex + 1; r <= rowCount; r++)
                {
                    IRow row = sheet.GetRow(r);  //读取当前行数据
                    if (row != null)
                    {
                        DataRow dr = dt.NewRow();
                        bool isCellNull = true;
                        for (int i = 0; i < cellCount; i++)
                        {
                            var columnName = headerRow.GetCell(i).ToString().Trim();
                            if (!cellHead.ContainsValue(columnName)) continue;
                            foreach (var header in cellHead)
                            {
                                if (header.Value == columnName)
                                {
                                    ICell cell = row.GetCell(i);
                                    if (cell == null)
                                    {
                                        dr[header.Key] = "";
                                    }
                                    else
                                    {
                                        cell.SetCellType(CellType.String);
                                        dr[header.Key] = cell.StringCellValue;
                                        if (isCellNull)
                                        {
                                            if (!string.IsNullOrWhiteSpace(cell.StringCellValue))
                                            {
                                                isCellNull = false;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if (!isCellNull)
                        {
                            dt.Rows.Add(dr);
                        }
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    return ResultHelper.Bad<DataTable>("Excel文件数据为空！");
                }

                return ResultHelper.Ok(dt);
            }
            catch (Exception ex)
            {
                return ResultHelper.Bad<DataTable>($"上传Excel失败:{ex.Message}");
            }
        }

        /// <summary>
        /// 无列名读取Excel数据到DataTable
        /// </summary>
        /// <param name="excelFile"></param>
        /// <param name="headRowIndex"></param>
        /// <returns></returns>
        public static Result<(DataTable, IWorkbook)> GetExcelToDataTable(IFormFile excelFile, int headRowIndex = 0)
        {
            var result = new Result<(DataTable, IWorkbook)>();
            try
            {
                if (excelFile == null || excelFile.Length == 0)
                {
                    return result.Bad("上传文件为空！");
                }

                string mimeType = excelFile.ContentType;
                if (!(mimeType == "application/vnd.ms-excel" || mimeType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                {
                    return result.Bad("Excel文件格式不正确，需为：xls 或 xlsx！");
                }

                IWorkbook workbook;
                using (var ms = new MemoryStream())
                {
                    excelFile.CopyTo(ms);
                    ms.Seek(0, SeekOrigin.Begin);
                    if (mimeType == "application/vnd.ms-excel")
                    {
                        workbook = new HSSFWorkbook(ms);
                    }
                    else
                    {
                        workbook = new XSSFWorkbook(ms);
                    }
                }

                ISheet sheet = workbook.GetSheetAt(0);
                IRow headerRow = sheet.GetRow(headRowIndex);
                int rowCount = sheet.LastRowNum;
                int cellCount = headerRow.LastCellNum;
                DataTable dt = new DataTable();
                for (int j = 0; j < cellCount; j++)
                {
                    dt.Columns.Add(headerRow.GetCell(j).ToString());
                }
                for (int r = headRowIndex + 1; r <= rowCount; r++)
                {
                    IRow row = sheet.GetRow(r);  //读取当前行数据
                    if (row != null)
                    {
                        DataRow dr = dt.NewRow();
                        bool isCellNull = true;
                        for (int i = 0; i < cellCount; i++)
                        {
                            var columnName = headerRow.GetCell(i).ToString();
                            ICell cell = row.GetCell(i);
                            if (cell == null)
                            {
                                dr[columnName] = "";
                            }
                            else
                            {
                                cell.SetCellType(CellType.String);
                                dr[columnName] = cell.StringCellValue;
                                if (isCellNull)
                                {
                                    if (!string.IsNullOrWhiteSpace(cell.StringCellValue))
                                    {
                                        isCellNull = false;
                                    }
                                }
                            }
                        }
                        if (!isCellNull)
                        {
                            dt.Rows.Add(dr);
                        }
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    return result.Bad("Excel文件数据为空！");
                }

                return result.Ok((dt, workbook));
            }
            catch (Exception ex)
            {
                return result.Bad($"上传Excel失败:{ex.Message}");
            }
        }

        /// <summary>
        /// 无表头表格读取Excel数据到DataTable
        /// </summary>
        /// <param name="excelFile"></param>
        /// <returns></returns>
        public static Result<DataTable> GetExcelToDataTableWithNoHead(IFormFile excelFile)
        {
            try
            {
                if (excelFile == null || excelFile.Length == 0)
                {
                    return ResultHelper.Bad<DataTable>("上传文件为空！");
                }

                string mimeType = excelFile.ContentType;
                if (!(mimeType == "application/vnd.ms-excel" || mimeType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                {
                    return ResultHelper.Bad<DataTable>("Excel文件格式不正确，需为：xls 或 xlsx！");
                }

                MemoryStream ms = new MemoryStream();
                excelFile.CopyTo(ms);
                ms.Seek(0, SeekOrigin.Begin);
                IWorkbook workbook;
                if (mimeType == "application/vnd.ms-excel")
                {
                    workbook = new HSSFWorkbook(ms);
                }
                else
                {
                    workbook = new XSSFWorkbook(ms);
                }

                ISheet sheet = workbook.GetSheetAt(0);
                IRow headerRow = sheet.GetRow(0);
                int rowCount = sheet.LastRowNum;
                int cellCount = headerRow.LastCellNum;
                DataTable dt = new DataTable();
                for (int j = 0; j < cellCount; j++)
                {
                    dt.Columns.Add(headerRow.GetCell(j).ToString());
                }
                for (int r = 0; r <= rowCount; r++)
                {
                    IRow row = sheet.GetRow(r);  //读取当前行数据
                    if (row != null)
                    {
                        DataRow dr = dt.NewRow();
                        bool isCellNull = true;
                        for (int i = 0; i < cellCount; i++)
                        {
                            var columnName = headerRow.GetCell(i).ToString();
                            ICell cell = row.GetCell(i);
                            if (cell == null)
                            {
                                dr[columnName] = "";
                            }
                            else
                            {
                                cell.SetCellType(CellType.String);
                                dr[columnName] = cell.StringCellValue;
                                if (isCellNull)
                                {
                                    if (!string.IsNullOrWhiteSpace(cell.StringCellValue))
                                    {
                                        isCellNull = false;
                                    }
                                }
                            }
                        }
                        if (!isCellNull)
                        {
                            dt.Rows.Add(dr);
                        }
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    return ResultHelper.Bad<DataTable>("Excel文件数据为空！");
                }

                return ResultHelper.Ok(dt);
            }
            catch (Exception ex)
            {
                return ResultHelper.Bad<DataTable>($"上传Excel失败:{ex.Message}");
            }
        }

        /// <summary>
        /// 读取Excel文件流数据到DataTable
        /// </summary>
        /// <param name="file"></param>
        /// <param name="cellheader"></param>
        /// <returns></returns>
        public static Result<DataTable> GetExcelStreamToDataTable(Stream file, Dictionary<string, string> cellheader)
        {
            try
            {
                IWorkbook hssworkbook = new HSSFWorkbook(file);
                ISheet sheet = hssworkbook.GetSheetAt(0);
                IRow headerRow = sheet.GetRow(0);
                int rowCount = sheet.LastRowNum;
                int cellCount = headerRow.LastCellNum;
                DataTable dt = new DataTable();
                for (int j = 0; j < cellCount; j++)
                {
                    foreach (var cell in cellheader)
                    {
                        if (cell.Value == headerRow.GetCell(j).ToString())
                        {
                            dt.Columns.Add(cell.Key);
                            break;
                        }
                    }
                }

                for (int r = sheet.FirstRowNum + 1; r <= rowCount; r++)
                {
                    IRow row = sheet.GetRow(r);  //读取当前行数据
                    if (row != null)
                    {
                        DataRow dr = dt.NewRow();
                        bool isCellNull = true;
                        for (int i = 0; i < cellCount; i++)
                        {
                            var columnName = headerRow.GetCell(i).ToString();
                            if (!cellheader.ContainsValue(columnName)) continue;
                            foreach (var header in cellheader)
                            {
                                if (header.Value == columnName)
                                {
                                    ICell cell = row.GetCell(i);
                                    if (cell == null)
                                    {
                                        dr[header.Key] = "";
                                    }
                                    else
                                    {
                                        cell.SetCellType(CellType.String);
                                        dr[header.Key] = cell.StringCellValue;
                                        if (isCellNull)
                                        {
                                            if (!string.IsNullOrWhiteSpace(cell.StringCellValue))
                                            {
                                                isCellNull = false;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if (!isCellNull)
                        {
                            dt.Rows.Add(dr);
                        }
                    }
                }

                return ResultHelper.Ok(dt);
            }
            catch (Exception ex)
            {
                return ResultHelper.Bad<DataTable>($"上传Excel失败:{ex.Message}");
            }

        }
        #endregion

        #region 读取CSV数据到DataTable
        /// <summary>
        /// 读取CSV文件
        /// </summary>
        /// <param name="csvFile"></param>
        /// <param name="cellHead"></param>
        /// <returns></returns>
        public static DataTable ReadCSV(IFormFile csvFile, Dictionary<string, string> cellHead)
        {
            DataTable dttemp = new DataTable();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            StreamReader sr = new StreamReader(csvFile.OpenReadStream(), Encoding.GetEncoding("GB2312"));
            //记录每次读取的一行记录
            string strLine = null;
            //记录每行记录中的各字段内容
            string[] arrayLine = null;
            //分隔符
            string[] separators = { "," };
            //判断，若是第一次，建立表头
            bool isFirst = true;

            //逐行读取CSV文件
            while ((strLine = sr.ReadLine()) != null)
            {
                strLine = strLine.Trim();//去除头尾空格
                arrayLine = strLine.Split(separators, StringSplitOptions.RemoveEmptyEntries);//分隔字符串，返回数组
                int dtColumns = arrayLine.Length;//列的个数
                if (isFirst)  //建立表头
                {
                    for (int i = 0; i < dtColumns; i++)
                    {
                        dttemp.Columns.Add(arrayLine[i].Trim());//每一列名称
                    }

                    isFirst = false;
                }
                else   //表内容
                {
                    DataRow dataRow = dttemp.NewRow();//新建一行
                    for (int j = 0; j < dtColumns; j++)
                    {
                        dataRow[j] = arrayLine[j].Trim();
                    }

                    dttemp.Rows.Add(dataRow);//添加一行
                }
            }

            sr.Close();
            var dt = new DataTable();
            var dic = new Dictionary<string, string>();
            foreach (var dc in dttemp.Columns)
            {
                foreach (var cell in cellHead)
                {
                    if (cell.Value == dc.ToString().Trim())
                    {
                        dt.Columns.Add(cell.Key);
                        dic.Add(cell.Key, dc.ToString());
                        break;
                    }
                }
            }

            foreach (DataRow dr in dttemp.Rows)
            {
                var tempDr = dt.NewRow();
                foreach (var dc in dttemp.Columns)
                {
                    foreach (var cell in dic)
                    {
                        if (cell.Value == dc.ToString().Trim())
                        {
                            tempDr[cell.Key] = dr[cell.Value];
                        }
                    }
                }

                dt.Rows.Add(tempDr);
            }

            return dt;
        }
        #endregion

        #region List导出到EXCLE
        /// <summary>
        /// List导出到EXCLE
        /// </summary>
        /// <param name="cellHead">单元头的Key和Value" { {"ResellerName", "分销商名称"}, { "Mobile", "手机号码"}};</param>
        /// <param name="enList">数据源</param>
        /// <param name="fileName"></param>
        /// <param name="tipMsg">首行提示信息</param>
        /// <param name="showCellHead">显示标题行</param>
        /// <returns>文件的GUID</returns>
        public static string ListToExcelFile<T>(Dictionary<string, string> cellHead, IList<T> enList, string fileName = "导出数据", string tipMsg = null, bool showCellHead = true)
        {
            XSSFWorkbook workbook = ListToExcelByNPOI(cellHead, enList, tipMsg, showCellHead);
            return WorkbookToExcelFile(workbook, fileName);
        }
        public static string WorkbookToExcelFile(XSSFWorkbook workbook, string fileName = "导出数据")
        {
            fileName = string.Format("{0}_{1}.xlsx", fileName, DateTime.Now.ToString("yyyyMMddHHmmssfff"));
            string filePath = "/DownFiles/ExcelFiles/" + fileName;
            string directoryName = Path.GetDirectoryName(AppSettings.WebRootPath + filePath);
            if (!Directory.Exists(directoryName) && directoryName != null)
            {
                Directory.CreateDirectory(directoryName);
            }
            using (FileStream file = new FileStream(AppSettings.WebRootPath + filePath, FileMode.Create))
            {
                workbook.Write(file);
                file.Close();
            }
            return filePath;
        }
        public static XSSFWorkbook ListToExcelByNPOI<T>(Dictionary<string, string> cellHead, IList<T> enList, string tipMsg = null, bool showCellHead = true)
        {
            var keys = cellHead.Keys.ToList();
            var workbook = new XSSFWorkbook();
            var sheet = workbook.CreateSheet("Sheet1");

            var rowIndex = 0;

            #region 创建提示行
            if (!string.IsNullOrEmpty(tipMsg))
            {
                ICellStyle tipStyle = workbook.CreateCellStyle();
                tipStyle.Alignment = HorizontalAlignment.Center;
                tipStyle.VerticalAlignment = VerticalAlignment.Center;

                IFont tipFont = workbook.CreateFont();
                tipFont.FontName = "微软雅黑";
                tipFont.FontHeightInPoints = 11;
                tipFont.Color = NPOI.HSSF.Util.HSSFColor.Red.Index;
                tipStyle.SetFont(tipFont);

                IRow tipRowRow = sheet.CreateRow(rowIndex++);
                int lastCol = keys.Count - 1 < 0 ? 0 : keys.Count - 1;
                sheet.AddMergedRegion(new NPOI.SS.Util.CellRangeAddress(0, 0, 0, lastCol));
                ICell tipCell = tipRowRow.CreateCell(0);
                tipCell.CellStyle = tipStyle;
                tipCell.SetCellValue(tipMsg);
            }
            #endregion

            #region 字体
            IFont cellfont = workbook.CreateFont();
            cellfont.FontName = "微软雅黑";
            cellfont.FontHeightInPoints = 11;
            #endregion

            #region 创建Excel标题行
            if (showCellHead)
            {
                ICellStyle headStyle = workbook.CreateCellStyle();
                headStyle.Alignment = HorizontalAlignment.Center;
                headStyle.VerticalAlignment = VerticalAlignment.Center;
                headStyle.SetFont(cellfont);

                IRow headRow = sheet.CreateRow(rowIndex++);
                headRow.HeightInPoints = 24;
                for (int i = 0; i < keys.Count; i++)
                {
                    ICell cell = headRow.CreateCell(i);
                    cell.CellStyle = headStyle;
                    cell.SetCellValue(cellHead[keys[i]]);
                }
            }
            #endregion

            #region 创建Excel数据行
            // 一般单元格样式
            ICellStyle cellStyle = workbook.CreateCellStyle();
            cellStyle.SetFont(cellfont);

            IDataFormat format = workbook.CreateDataFormat();
            //日期单元格样式
            ICellStyle dateStyle = workbook.CreateCellStyle();
            dateStyle.SetFont(cellfont);
            dateStyle.DataFormat = format.GetFormat("yyyy-MM-dd");

            //时间单元格样式
            ICellStyle dateTimeStyle = workbook.CreateCellStyle();
            dateTimeStyle.SetFont(cellfont);
            dateTimeStyle.DataFormat = format.GetFormat("yyyy-MM-dd HH:mm:ss");

            //浮点值单元格样式
            ICellStyle doubleStyle = workbook.CreateCellStyle();
            doubleStyle.SetFont(cellfont);
            doubleStyle.DataFormat = format.GetFormat("0.00");

            foreach (var en in enList)
            {
                IRow dataRow = sheet.CreateRow(rowIndex++);
                for (int i = 0; i < keys.Count; i++)
                {
                    string cellValue = "";
                    string propertyType = null;

                    #region 获取单元格值
                    string[] keysArray = keys[i].Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var key in keysArray)
                    {
                        object properotyValue = null;
                        PropertyInfo properotyInfo = null;
                        if (key.IndexOf(".", StringComparison.Ordinal) >= 0)
                        {
                            string[] properotyArray = key.Split(new string[] { "." }, StringSplitOptions.RemoveEmptyEntries);
                            string subClassName = properotyArray[0];
                            string subClassProperotyName = properotyArray[1];
                            PropertyInfo subClassInfo = en.GetType().GetProperty(subClassName);
                            if (subClassInfo != null)
                            {
                                var subClassEn = subClassInfo.GetValue(en, null);
                                properotyInfo = subClassInfo.PropertyType.GetProperty(subClassProperotyName);
                                if (properotyInfo != null && subClassEn != null)
                                {
                                    properotyValue = properotyInfo.GetValue(subClassEn, null);
                                }
                            }
                        }
                        else
                        {
                            properotyInfo = en.GetType().GetProperty(key);
                            if (properotyInfo != null)
                            {
                                properotyValue = properotyInfo.GetValue(en, null);
                            }
                        }
                        if (properotyValue != null)
                        {
                            propertyType = properotyInfo.PropertyType.Name;
                            propertyType = propertyType.ToLower();
                            cellValue += properotyValue + "|";
                        }
                        else if (en.GetType().Name == "ExpandoObject")
                        {
                            foreach (var property in (IDictionary<string, object>)en)
                            {
                                if (property.Key == key)
                                {
                                    if (property.Value != null)
                                    {
                                        propertyType = property.Value?.GetType().Name.ToString().ToLower();
                                        cellValue = property.Value?.ToString();
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    if (keysArray.Count() > 1) { propertyType = "string"; }
                    cellValue = string.IsNullOrEmpty(cellValue.TrimEnd('|')) ? "" : cellValue.TrimEnd('|');
                    #endregion

                    ICell newCell = dataRow.CreateCell(i);
                    newCell.CellStyle = cellStyle;
                    switch (propertyType)
                    {
                        case "int32":
                        case "int64":
                            int intValue = 0;
                            int.TryParse(cellValue, out intValue);
                            if (intValue == int.MinValue)
                            {
                                newCell.SetCellValue("");
                            }
                            else
                            {
                                newCell.SetCellValue(intValue);
                            }
                            break;
                        case "decimal":
                            decimal decimalValue = 0.00m;
                            decimal.TryParse(cellValue, out decimalValue);
                            if (decimalValue == decimal.MinValue)
                            {
                                newCell.SetCellValue("");
                            }
                            else
                            {
                                newCell.SetCellValue(double.Parse(decimalValue.ToString()));
                            }
                            newCell.CellStyle = doubleStyle;//格式化显示
                            break;

                        case "date"://日期类型
                            DateTime dateValue = DateTime.MinValue;
                            DateTime.TryParse(cellValue, out dateValue);
                            if (dateValue <= DateTime.Parse("1900-01-01"))
                            {
                                newCell.SetCellValue("");
                            }
                            else
                            {
                                newCell.SetCellValue(dateValue);
                            }
                            newCell.CellStyle = dateStyle;//格式化显示
                            break;

                        case "datetime"://时间类型
                            DateTime dateTimeValue = DateTime.MinValue;
                            DateTime.TryParse(cellValue, out dateTimeValue);
                            if (dateTimeValue <= DateTime.Parse("1900-01-01"))
                            {
                                newCell.SetCellValue("");
                            }
                            else
                            {
                                newCell.SetCellValue(dateTimeValue);
                            }
                            newCell.CellStyle = dateTimeStyle;//格式化显示
                            break;
                        case "nullable`1":
                            if (!string.IsNullOrEmpty(cellValue)&& double.TryParse(cellValue,out double value))
                            {
                                newCell.SetCellValue(value);
                            }
                            else
                            {
                                newCell.SetCellValue(cellValue);
                            }
                            break;
                        default:
                            newCell.SetCellValue(cellValue);
                            break;
                    }
                }
            }
            #endregion

            #region 自动宽度
            for (var i = 0; i < cellHead.Count; i++)
            {
                sheet.AutoSizeColumn(i);
                var _width = sheet.GetColumnWidth(i) + 384;
                _width = _width > 12800 ? 12800 : _width;
                sheet.SetColumnWidth(i, _width);
            }
            #endregion
            return workbook;
        }
        #endregion
    }

    public class NpoiMemoryStream : MemoryStream
    {
        public bool AllowClose { get; set; } = true;
        public override void Close()
        {
            if (AllowClose)
                base.Close();
        }
    }
}
