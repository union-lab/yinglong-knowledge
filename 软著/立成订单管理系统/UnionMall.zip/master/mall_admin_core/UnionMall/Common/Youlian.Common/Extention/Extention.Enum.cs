﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Reflection;


namespace Youlian.Common.Extention
{
    /// <summary>
    /// 
    /// </summary>
    public class TextAttribute : Attribute
    {
        /// <summary>
        /// 
        /// </summary>
        public TextAttribute(string value)
        {
            Value = value;
        }
        /// <summary>
        /// 
        /// </summary>
        public string Value { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, AllowMultiple = false)]
    public sealed class SortAttribute : Attribute
    {
        /// <summary>
        /// 
        /// </summary>
        public SortAttribute() : base()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sort"></param>
        public SortAttribute(int sort)
        {
            Sort = sort;
        }

        /// <summary>
        /// 
        /// </summary>
        public int Sort { get; set; }
    }
    public static partial class Extention
    {
        /// <summary>
        /// 获得枚举提示文本
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string GetEnumText(this Enum obj)
        {
            Type type = obj.GetType();
            FieldInfo field = type.GetField(obj.ToString());
            TextAttribute attribute = (TextAttribute)field.GetCustomAttribute(typeof(TextAttribute));
            return attribute.Value;
        }

        /// <summary>
        /// 获得枚举提示描述
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string GetEnumDescription(this Enum obj)
        {
            if (obj == null)
            {
                return "";
            }
            Type type = obj.GetType();
            FieldInfo field = type.GetField(obj.ToString());
            DescriptionAttribute attribute = (DescriptionAttribute)field.GetCustomAttribute(typeof(DescriptionAttribute));
            return (attribute?.Description).IsNull(field.Name);
        }

        /// <summary>
        /// 获得枚举提示描述
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string GetEnumDisplay(this Enum obj)
        {
            if (obj == null)
            {
                return "";
            }
            Type type = obj.GetType();
            MemberInfo[] memInfo = type.GetMember(obj.ToString());
            if (memInfo != null && memInfo.Length > 0)
            {
                object[] attrs = memInfo[0].GetCustomAttributes(typeof(DisplayAttribute), false);
                if (attrs != null && attrs.Length > 0)
                {
                    return ((DisplayAttribute)attrs[0]).Name;
                }
            }
            return obj.ToString();
        }
    }
}