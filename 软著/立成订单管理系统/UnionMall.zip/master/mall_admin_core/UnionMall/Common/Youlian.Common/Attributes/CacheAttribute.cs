﻿using System;

namespace Youlian.Common
{
    [AttributeUsage(AttributeTargets.Method, Inherited = true)]
    public class CacheAttribute : Attribute
    {
        /// <summary>
        /// 缓存绝对过期时间（分钟）
        /// </summary>
        public int AbsoluteExpiration { get; set; } = 30;

        /// <summary>
        /// 自定义key
        /// </summary>
        public string CustomKeyValue { get; set; }
        /// <summary>
        /// 是否删除
        /// </summary>
        public bool IsDelete { get; set; } = false;
    }
}
