﻿using Microsoft.Extensions.Caching.Memory;
using System;

namespace Youlian.Common.Cache
{
    /// <summary>
    /// MemoryCache的管理工具类
    /// 该类是单例类
    /// </summary>
    public class MemoryCacheManager : ICacheManager
    {
        private readonly IMemoryCache cache;
        public MemoryCacheManager(IMemoryCache cache)
        {
            this.cache = cache;
        }

        public bool Add(string key, string value, TimeSpan? expiry = null)
        {
            throw new NotImplementedException();
        }

        public T Get<T>(string key)
        {
            throw new NotImplementedException();
        }

        public string GetString(string key)
        {
            throw new NotImplementedException();
        }

        public bool Refresh(string key)
        {
            throw new NotImplementedException();
        }

        public bool Remove(string key)
        {
            throw new NotImplementedException();
        }

        public bool Set<T>(string key, T value, TimeSpan? expiry = null)
        {
            throw new NotImplementedException();
        }

        public bool SetString(string key, string value, TimeSpan? expiry = null)
        {
            throw new NotImplementedException();
        }
    }
}