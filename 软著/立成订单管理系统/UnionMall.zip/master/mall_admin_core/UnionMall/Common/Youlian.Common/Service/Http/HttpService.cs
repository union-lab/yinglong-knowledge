﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Youlian.Common.Extention;

namespace Youlian.Common.Service.Http
{
    /// <summary>
    /// http请求服务
    /// </summary>
    public class HttpService : IHttpService
    {
        private readonly IHttpClientFactory _clientFactory;
        public HttpService(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async Task<ApiRequestResult> GetApiAsync(string url, Dictionary<string, string> param = null, Dictionary<string, string> headParam = null)
        {
            var hc = new StringContent(string.Empty, Encoding.UTF8);
            if (param!=null)
            {
                var sb = new StringBuilder();
                foreach (var item in param)
                {
                    sb.Append($"{item.Key}={item.Value}&");
                }
                url += (url.Contains('?') ?"&": "?") + sb.ToString().TrimEnd('&');
            }
            return await RequestAsync(url, HttpMethod.Get, hc, headParam);
        }
        public async Task<ApiRequestResult<TResult>> GetApiAsync<TResult>(string url, Dictionary<string, string> param = null, Dictionary<string, string> headParam = null)
        {
            var apiResult = await GetApiAsync(url, param, headParam);
            return new ApiRequestResult<TResult>()
            {
                StatusCode = apiResult.StatusCode,
                ErrorMessage = apiResult.ErrorMessage,
                Headers = apiResult.Headers,
                Message = JsonExtention.TryDeserialize<TResult>(apiResult.Message)
            };
        }

        public async Task<ApiRequestResult<TResult>> GetApiAsync<T,TResult>(string url, T param, Dictionary<string, string> headParam = null) where T : class
        {
            var hc = new StringContent(string.Empty, Encoding.UTF8);
            if (param != null)
            {
                var sb = new StringBuilder();
                foreach (var item in typeof(T).GetProperties())
                {
                    sb.Append($"{item.Name}={item.GetValue(param)}&");
                }
                url += (url.Contains('?') ? "&" : "?") + sb.ToString().TrimEnd('&');
            }
            var apiResult = await RequestAsync(url, HttpMethod.Get, hc, headParam);
            return new ApiRequestResult<TResult>()
            {
                StatusCode = apiResult.StatusCode,
                ErrorMessage = apiResult.ErrorMessage,
                Headers = apiResult.Headers,
                Message = JsonExtention.TryDeserialize<TResult>(apiResult.Message)
            };
        }



        public async Task<ApiRequestResult> PostApiAsync<T>(string url, T postParam, Dictionary<string, string> headParam = null)
            where T : class
        {
            var hc = new StringContent(postParam.ToJson(), Encoding.UTF8, "application/json");
            return await RequestAsync(url, HttpMethod.Post, hc, headParam);
        }

        public async Task<ApiRequestResult<TResult>> PostApiAsync<T, TResult>(string url, T postParam, Dictionary<string, string> headParam = null) where T : class
        {
            var apiResult = await PostApiAsync(url, postParam, headParam);
            return new ApiRequestResult<TResult>()
            {
                StatusCode = apiResult.StatusCode,
                ErrorMessage = apiResult.ErrorMessage,
                Headers = apiResult.Headers,
                Message = JsonExtention.TryDeserialize<TResult>(apiResult.Message)
            };
        }

        private async Task<ApiRequestResult> RequestAsync(string url, HttpMethod method, HttpContent httpContent, Dictionary<string, string> headParam)
        {
            var httpClient = _clientFactory.CreateClient();
            var result = new ApiRequestResult();
            try
            {
                HttpRequestMessage request = new HttpRequestMessage(method, url);
                request.Content = httpContent;
                if (headParam != null)
                {
                    foreach (string key in headParam.Keys)
                    {
                        request.Headers.Add(key, headParam[key]);
                    }
                }
                var res = await httpClient.SendAsync(request);
                result.Message = await res.Content.ReadAsStringAsync();
                result.StatusCode = res.StatusCode;
                if(result.StatusCode != HttpStatusCode.OK&& string.IsNullOrEmpty(result.ErrorMessage))
                {
                    result.ErrorMessage = result.Message;
                }
                return result;
            }
            catch (Exception ex)
            {
                result.StatusCode = (ex as TaskCanceledException)?.CancellationToken.IsCancellationRequested == true ? HttpStatusCode.GatewayTimeout : HttpStatusCode.InternalServerError;
                result.ErrorMessage = ex.InnerException?.Message ?? ex.Message;
            }
            return result;
        }
    }
}
