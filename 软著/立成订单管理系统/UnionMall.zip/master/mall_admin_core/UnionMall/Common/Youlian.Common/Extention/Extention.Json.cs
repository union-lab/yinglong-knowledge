﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;

namespace Youlian.Common.Extention
{
    /// <summary>
    /// 拓展类
    /// </summary>
    public static class JsonExtention
    {
        static JsonExtention()
        {
            JsonConvert.DefaultSettings = () => DefaultJsonSetting;
        }
        /// <summary>
        /// 默认序列化设置
        /// </summary>
        public static JsonSerializerSettings DefaultJsonSetting = new JsonSerializerSettings
        {
            ContractResolver = new DefaultContractResolver(),
            DateFormatHandling = DateFormatHandling.MicrosoftDateFormat,
            DateFormatString = "yyyy-MM-dd HH:mm:ss.fff"
        };
        /// <summary>
        /// 峰驼格式序列化
        /// </summary>
        public static JsonSerializerSettings CamelCaseJsonSetting = new JsonSerializerSettings
        {
            ContractResolver = new CamelCasePropertyNamesContractResolver(),
            DateFormatHandling = DateFormatHandling.MicrosoftDateFormat,
            DateFormatString = "yyyy-MM-dd HH:mm:ss.fff"
        };

        /// <summary>
        /// 将对象序列化成Json字符串
        /// </summary>
        /// <param name="obj">需要序列化的对象</param>
        /// <returns></returns>
        public static string ToJson(this object obj)
        {
            return JsonConvert.SerializeObject(obj);
        }

        /// <summary>
        /// 转换未峰驼格式Json字符串
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string ToCamelCaseJson(this object obj)
        {
            return JsonConvert.SerializeObject(obj, CamelCaseJsonSetting);
        }

        /// <summary>
        /// 将Json字符串反序列化为对象
        /// </summary>
        /// <typeparam name="T">对象类型</typeparam>
        /// <param name="jsonStr">Json字符串</param>
        /// <returns></returns>
        public static T ToObject<T>(this string jsonStr)
        {
            return JsonConvert.DeserializeObject<T>(jsonStr);
        }

        /// <summary>
        /// 将Json字符串反序列化为对象
        /// </summary>
        /// <param name="jsonStr">json字符串</param>
        /// <param name="type">对象类型</param>
        /// <returns></returns>
        public static object ToObject(this string jsonStr, Type type)
        {
            return JsonConvert.DeserializeObject(jsonStr, type);
        }

        /// <summary>
        /// 将JSON转为对象
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static T Deserialize<T>(this string s)
        {
            return JsonConvert.DeserializeObject<T>(s);
        }
        /// <summary>
        /// 将JSON转为对象,失败则返回null
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="s"></param>
        /// <returns></returns>
        public static T TryDeserialize<T>(this string s)
        {
            try
            {
                if (string.IsNullOrEmpty(s))
                    return default;
                return JsonConvert.DeserializeObject<T>(s);
            }
            catch(Exception ex)
            {
                return default;
            }
        }
    }
}
