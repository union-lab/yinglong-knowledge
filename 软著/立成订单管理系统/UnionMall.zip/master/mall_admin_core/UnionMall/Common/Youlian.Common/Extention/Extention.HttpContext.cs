﻿using Microsoft.AspNetCore.Http;
using NodaTime;
using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Youlian.Common.Extention
{
    public static partial class Extention
    {
        /// <summary>
        /// 获取域名，如https://www.baidu.com
        /// </summary>
        /// <param name="httpRequest"></param>
        /// <returns></returns>
        public static string GetFullHost(this HttpRequest httpRequest)
        {
            return httpRequest?.Scheme + "://" + httpRequest?.Host.Host;
        }

        /// <summary>
        /// 获取域名，含端口号，如https://www.baidu.com:8888
        /// </summary>
        /// <param name="httpRequest"></param>
        /// <returns></returns>
        public static string GetFullHostPort(this HttpRequest httpRequest)
        {
            return httpRequest?.Scheme + "://" + httpRequest?.Host.ToString();
        }

        /// <summary>
        /// 获取当前域名
        /// </summary>
        /// <param name="httpRequest"></param>
        /// <returns></returns>
        public static string GetCurrentHost(this HttpRequest httpRequest)
        {
            if (httpRequest?.Host.Port == 80 || httpRequest?.Host.Port == 443)
                return GetFullHost(httpRequest);
            return GetFullHostPort(httpRequest);
        }

        /// <summary>
        /// 是否是微信
        /// </summary>
        /// <param name="httpRequest"></param>
        /// <returns></returns>
        public static bool IsWeixinBrowser(this HttpRequest httpRequest)
        {
            var userAgent = httpRequest.Headers["user-agent"].ToString();

            return Regex.IsMatch(userAgent, "MicroMessenger", RegexOptions.IgnoreCase);
        }

        /// <summary>
        /// 是否是企业微信
        /// </summary>
        /// <param name="httpRequest"></param>
        /// <returns></returns>
        public static bool IsWorkWeixinBrowser(this HttpRequest httpRequest)
        {
            var userAgent = httpRequest.Headers["user-agent"].ToString();

            return Regex.IsMatch(userAgent, "MicroMessenger", RegexOptions.IgnoreCase) && Regex.IsMatch(userAgent, "WxWork", RegexOptions.IgnoreCase);
        }

        /// <summary>
        /// 是否Android浏览器
        /// </summary>
        /// <param name="httpRequest"></param>
        /// <returns></returns>
        public static bool IsAndroid(this HttpRequest httpRequest)
        {
            var userAgent = httpRequest.Headers["user-agent"].ToString();

            return Regex.IsMatch(userAgent, "Android", RegexOptions.IgnoreCase);
        }
        /// <summary>
        /// 是否IOS浏览器
        /// </summary>
        /// <param name="httpRequest"></param>
        /// <returns></returns>
        public static bool IsIos(this HttpRequest httpRequest)
        {
            var userAgent = httpRequest.Headers["user-agent"].ToString();

            return Regex.IsMatch(userAgent, @"(iPhone|iPad|iPod|iOS)", RegexOptions.IgnoreCase) || Regex.IsMatch(userAgent, "Adr", RegexOptions.IgnoreCase);
        }
    }
}
