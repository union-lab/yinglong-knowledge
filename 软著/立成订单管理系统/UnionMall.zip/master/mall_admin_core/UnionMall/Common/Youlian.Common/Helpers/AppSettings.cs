﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Youlian.Common.Helpers
{
    /// <summary>
    /// appsettings.json操作类
    /// </summary>
    public class AppSettings
    {
        public const string CookieAuthenticationScheme = "Cookies";
        /// <summary>
        /// 获得配置文件的对象值
        /// </summary>
        /// <param name="jsonPath"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string GetJson(string jsonPath, string key)
        {
            IConfiguration config = new ConfigurationBuilder().AddJsonFile(jsonPath).Build(); //json文件地址
            string s = config.GetSection(key).Value; //json某个对象
            return s;
        }
        public static IConfiguration Configuration
        {
            get
            {
                return Services.GetService<IConfiguration>();
            }
        }
        /// <summary>
        /// 请注意，不要获取AddScoped作用域的服务，获取到的是AddSingleton服务
        /// </summary>
        public static IServiceProvider Services = null;
        /// <summary>
        /// 用于获取AddScoped 作用域的服务
        /// </summary>
        /// <returns></returns>
        public static IServiceProvider GetScopeServices()
        {
            return Services.CreateScope().ServiceProvider;
        }
        public static string WebRootPath;
        /// <summary>
        /// 开发环境
        /// </summary>
        public static bool IsDevelopment;

    }
}
