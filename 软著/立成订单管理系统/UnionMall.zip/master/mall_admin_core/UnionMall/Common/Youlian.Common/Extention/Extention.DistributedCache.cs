﻿using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Common.Extention
{
    public static class DistributedCacheExtensions
    {
        public static void Set(this IDistributedCache cache, string key, string value, TimeSpan? timeSpan = null)
        {
            var options = new DistributedCacheEntryOptions();
            if (timeSpan.HasValue)
            {
                options.SetAbsoluteExpiration(timeSpan.Value);
            }
            cache.SetString(key, value, options);
        }
        public static void Set<T>(this IDistributedCache cache, string key, T value, TimeSpan? timeSpan = null)
        {
            if (key == null)
            {
                throw new ArgumentNullException(nameof(key));
            }
            if (value == null)
            {
                throw new ArgumentNullException(nameof(value));
            }
            byte[] bytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(value));
            var options = new DistributedCacheEntryOptions();
            if (timeSpan.HasValue)
            {
                options.SetAbsoluteExpiration(timeSpan.Value);
            }
            cache.Set(key, bytes, options);
        }

        public static T Get<T>(this IDistributedCache cache, string key)
        {
            byte[] data = cache.Get(key);
            if (data == null)
            {
                return default;
            }
            var str = Encoding.UTF8.GetString(data, 0, data.Length);
            return JsonConvert.DeserializeObject<T>(str);
        }
    }
}
