﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using System;
using Microsoft.Extensions.Configuration;
using Youlian.Common.Cache;

namespace Youlian.Common.Cache
{

    /// <summary>
    /// 
    /// </summary>
    public static class CacheSetup
    {

        /// <summary>
        /// 
        /// </summary>
        public static void AddCacheSetup(this IServiceCollection services, IConfiguration configuration)
        {
            if (services == null) throw new ArgumentNullException(nameof(services));

            //services.AddScoped<ICacheManager, MemoryCacheManager>();
            //services.AddSingleton<IMemoryCache>(factory =>
            //{
            //    var cache = new MemoryCache(new MemoryCacheOptions());
            //    return cache;
            //});

            //获取redis数据连接
            var redisConnectionString = configuration.GetSection("Redis:Connection").Value;
            var redisInstanceName = configuration.GetSection("Redis:InstanceName").Value;
            services.AddSingleton<ICacheManager>(factory =>
            {
                var cache = new RedisCacheManager(redisConnectionString, redisInstanceName);
                return cache;
            });

            //services.AddStackExchangeRedisCache(options =>
            //{
            //    options.Configuration = redisConnectionString;
            //    options.InstanceName = redisInstanceName;
            //});
        }
    }
}
