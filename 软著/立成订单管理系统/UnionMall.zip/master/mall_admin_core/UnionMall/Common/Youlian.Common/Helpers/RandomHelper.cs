﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Youlian.Common.Helpers
{
    /// <summary>
    /// Random随机数帮助类
    /// </summary>
    public static class RandomHelper
    {
        private static Random _random { get; } = new Random();

        /// <summary>
        /// 下一个随机数
        /// </summary>
        /// <param name="minValue">最小值</param>
        /// <param name="maxValue">最大值</param>
        /// <returns></returns>
        public static int Next(int minValue, int maxValue)
        {
            return _random.Next(minValue, maxValue);
        }

        /// <summary>
        /// 下一个随机值
        /// </summary>
        /// <typeparam name="T">值类型</typeparam>
        /// <param name="source">值的集合</param>
        /// <returns></returns>
        public static T Next<T>(IEnumerable<T> source)
        {
            return source.ToList()[Next(0, source.Count())];
        }


        /// <summary>
        /// 取得随机的种子，提高随机数不重复概率的种子生成方法
        /// </summary>
        /// <returns></returns>
        public static int GetRandomSeed()
        {
            var bytes = new byte[4];
            var rng = new System.Security.Cryptography.RNGCryptoServiceProvider();
            rng.GetBytes(bytes);
            return BitConverter.ToInt32(bytes, 0);
        }


        /// <summary>
        /// 生成随机数
        /// </summary>
        /// <param name="seed">随机种子</param>
        /// <param name="length">长度</param>
        /// <param name="source">字符来源</param>
        /// <returns></returns>
        public static string GetRandomString(int seed, int length, string source)
        {
            //声明要返回的字符串
            var tmpstr = "";
            //密码中包含的字符数组
            var pwdchars = source;
            //数组索引随机数
            //随机数生成器
            var rnd = new Random(seed * unchecked((int)DateTime.Now.Ticks));
            for (var i = 0; i < length; i++)
            {
                //Random类的Next方法生成一个指定范围的随机数
                var iRandNum = rnd.Next(pwdchars.Length);
                //tmpstr随机添加一个字符
                tmpstr += pwdchars[iRandNum];
            }
            return tmpstr;
        }

        /// <summary>
        /// 生成随机数
        /// </summary>
        public const string SOURCE = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        public static string GetRandomString(int length)
        {
            return GetRandomString(GetRandomSeed(), length, SOURCE);
        }
    }
}
