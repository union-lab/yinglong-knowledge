﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Common.Service.Http
{
    /// <summary>
    /// http请求结果
    /// </summary>
    public class ApiRequestResult : ApiRequestResult<string>
    {

    }

    /// <summary>
    /// http请求结果
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ApiRequestResult<T>
    {
        /// <summary>
        /// 
        /// </summary>
        public HttpStatusCode StatusCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool Success { get { return StatusCode.GetHashCode() == 200; } }
        /// <summary>
        /// 
        /// </summary>
        public T Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ErrorMessage { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public HttpResponseMessage Headers { get; set; }
    }
}
