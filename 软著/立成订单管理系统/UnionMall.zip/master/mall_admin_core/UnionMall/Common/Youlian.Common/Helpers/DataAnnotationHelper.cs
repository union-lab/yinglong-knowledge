﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Common.Helpers
{
    public class ModelValidationError
    {
        public string FieldName { get; set; }
        public string Message { get; set; }
    }
    /// <summary>
    /// 参数模型验证帮助类
    /// </summary>
    public static class DataAnnotationHelper
    {
        public static Result<TResult> IsValid<T, TResult>(this T o)
        {
            var result = o.IsValid();
            if (result.Any())
            {
                return ResultHelper.Bad<TResult>(result.First().Message);
            }
            return ResultHelper.Ok<TResult>();
        }
        public static IEnumerable<ModelValidationError> IsValid<T>(this T o)
        {
            var descriptor = GetTypeDescriptor(typeof(T));

            foreach (PropertyDescriptor propertyDescriptor in descriptor.GetProperties())
            {
                foreach (var validationAttribute in propertyDescriptor.Attributes.OfType<ValidationAttribute>())
                {
                    if (!validationAttribute.IsValid(propertyDescriptor.GetValue(o)))
                    {
                        yield return new ModelValidationError() { FieldName = propertyDescriptor.Name, Message = validationAttribute.FormatErrorMessage(propertyDescriptor.Name) };
                    }
                }
            }
        }
        private static ICustomTypeDescriptor GetTypeDescriptor(Type type)
        {
            return new AssociatedMetadataTypeTypeDescriptionProvider(type).GetTypeDescriptor(type);
        }
    }
}
