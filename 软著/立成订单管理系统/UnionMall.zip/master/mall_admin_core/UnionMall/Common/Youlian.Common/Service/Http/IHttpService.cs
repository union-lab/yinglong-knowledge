﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Common.Service.Http
{
    /// <summary>
    /// http请求服务
    /// </summary>
    public interface IHttpService
    {
        Task<ApiRequestResult> GetApiAsync(string url, Dictionary<string, string> param = null, Dictionary<string, string> headParam = null);
        Task<ApiRequestResult<TResult>> GetApiAsync<TResult>(string url, Dictionary<string, string> param = null, Dictionary<string, string> headParam = null);
        Task<ApiRequestResult<TResult>> GetApiAsync<T, TResult>(string url, T param, Dictionary<string, string> headParam = null) where T : class;

        Task<ApiRequestResult> PostApiAsync<T>(string url, T postParam, Dictionary<string, string> headParam) where T : class;
        Task<ApiRequestResult<TResult>> PostApiAsync<T, TResult>(string url, T postParam, Dictionary<string, string> headParam = null) where T : class;
    }
}
