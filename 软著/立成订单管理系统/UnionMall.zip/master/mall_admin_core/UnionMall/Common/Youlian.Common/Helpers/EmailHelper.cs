﻿using MailKit.Net.Smtp;
using Microsoft.Extensions.Configuration;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Common.Helpers
{
    public class NotificationMetadata
    {
        public string Sender { get; set; }
        public string SenderName { get; set; }
        public string SmtpServer { get; set; }
        public int Port { get; set; } = 465;
        public string UserName { get; set; }
        public string Password { get; set; }
    }
    public class EmailMessage
    {
        public MailboxAddress Sender { get; set; }
        public MailboxAddress Reciever { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
    }

    public class EmailHelper
    {
        private static MimeMessage CreateEmailMessage(EmailMessage message)
        {
            var mimeMessage = new MimeMessage();
            mimeMessage.From.Add(message.Sender);
            mimeMessage.To.Add(message.Reciever);
            mimeMessage.Subject = message.Subject;
            mimeMessage.Body = new TextPart(MimeKit.Text.TextFormat.Html)
            {
                Text = message.Content
            };
            return mimeMessage;
        }
        public static async Task<bool> SendAsync(string reciever, string title, string content)
        {
            var _notificationMetadata = AppSettings.Configuration.GetSection("EmailSettings").Get<NotificationMetadata>();
            EmailMessage message = new EmailMessage();
            message.Sender = new MailboxAddress(_notificationMetadata.SenderName, _notificationMetadata.Sender);
            message.Reciever = new MailboxAddress(reciever, reciever);
            message.Subject = title;
            message.Content = content;
            var mimeMessage = CreateEmailMessage(message);
            try
            {
                using (var smtpClient = new SmtpClient())
                {
                    await smtpClient.ConnectAsync(_notificationMetadata.SmtpServer, _notificationMetadata.Port, true);
                    await smtpClient.AuthenticateAsync(_notificationMetadata.UserName, _notificationMetadata.Password);
                    await smtpClient.SendAsync(mimeMessage);
                    await smtpClient.DisconnectAsync(true);
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
