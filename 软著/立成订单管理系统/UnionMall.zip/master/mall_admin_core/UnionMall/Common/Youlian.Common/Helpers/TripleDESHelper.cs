﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Common.Helpers
{
    public class TripleDESHelper
    {
        private const string KEY = "Youlian.Encryption";

        /// <summary>
        /// 加密字符串
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string Encrypt(string plainText, string key = KEY)
        {
            SymmetricAlgorithm algorithm = new TripleDESCryptoServiceProvider();
            algorithm.Key = new ASCIIEncoding().GetBytes(key.Substring(0, 16));
            algorithm.IV = new ASCIIEncoding().GetBytes(key.Substring(8, 8));
            algorithm.Mode = CipherMode.CBC;
            algorithm.Padding = PaddingMode.PKCS7;

            ICryptoTransform transform = algorithm.CreateEncryptor();

            byte[] data = new ASCIIEncoding().GetBytes(plainText);
            using (var memoryStream = new MemoryStream())
            {
                using (var cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write))
                {
                    cryptoStream.Write(data, 0, data.Length);
                    cryptoStream.FlushFinalBlock();
                    var result = Convert.ToBase64String(memoryStream.ToArray());
                    return result;
                }
            }
        }

        /// <summary>
        /// 解密字符串
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string Decrypt(string password, string key = KEY)
        {
            try
            {
                SymmetricAlgorithm algorithm = new TripleDESCryptoServiceProvider();
                algorithm.Key = new ASCIIEncoding().GetBytes(key.Substring(0, 16));
                algorithm.IV = new ASCIIEncoding().GetBytes(key.Substring(8, 8));
                algorithm.Mode = CipherMode.CBC;
                algorithm.Padding = PaddingMode.PKCS7;

                ICryptoTransform transform = algorithm.CreateDecryptor(algorithm.Key, algorithm.IV);

                byte[] buffer = Convert.FromBase64String(password);
                using (var memoryStream = new MemoryStream(buffer))
                {
                    using (var cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Read))
                    {
                        using (var reader = new StreamReader(cryptoStream, Encoding.ASCII))
                        {
                            var result = reader.ReadToEnd();
                            return result;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return "";
            }
        }
    }
}
