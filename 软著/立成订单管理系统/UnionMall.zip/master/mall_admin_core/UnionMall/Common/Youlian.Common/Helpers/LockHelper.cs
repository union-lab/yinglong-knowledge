﻿using Youlian.Common.Extention;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using log4net;
using Youlian.Common.Cache;

namespace Youlian.Common.Helpers
{
    public static class CacheKeys
    {
        #region Lock
        public const string UserLock = "UserLock:{0}";
        public const string UserOperationLock = "UserOperationLock:{0}:{1}";
        public const string KeyOperationLock = "KeyOperationLock:{0}:{1}";
        #endregion

        #region 系统
        public const string LoginToken = "Login:Token:{0}";
        public const string LoginFailTimes = "Login:FailTimes:{0}:{1}";

        public const string UserInfo = "User:Info:{0}";
        public const string EmployeeInfo = "Employee:Info:{0}";
        public const string HREmployeeInfo = "HREmployee:Info:{0}";
        public const string HREmployeeInfoWx = "HREmployee:Info:{0}";
        public const string DepartmentInfo = "Department:Info:{0}";
        public const string DepartmentIds = "Department:Ids";
        #region 注册
        public const string RegisterValidCode = "Register:ValidCode:{0}";
        #endregion

        #region 角色权限
        /// <summary>
        /// 用户角色key
        /// </summary>
        public const string SysUserRoles = "Sys:UserRoles:{0}";
        /// <summary>
        /// 用户角色名称key
        /// </summary>
        public const string SysUserRoleNames = "Sys:UserRoleNames:{0}";
        /// <summary>
        /// 权限菜单Key
        /// </summary>
        public const string SysPermissionMenu = "Sys:PermissionMenu:{0}";
        /// <summary>
        /// 角色菜单操作权限缓存Key
        /// </summary>
        public const string SysRoleMenuAction = "Sys:RoleMenuAction";
        #endregion
        #endregion

        #region 业务
        /// <summary>
        /// 微信AccessToken
        /// </summary>
        public const string WeixinAccessToken = "Weixin:AccessToken:{0}";
        public const string WeixinAuthAccessToken = "Weixin:AuthAccessToken:{0}";
        public const string WeixinAuthCode = "Weixin:AuthCode:{0}";
        /// <summary>
        /// 自建企业应用AccessToken
        /// </summary>
        public const string WorkWeixinAppAccessToken = "WorkWeixin:AccessToken:{0}";
        /// <summary>
        /// JS SDK Ticket
        /// </summary>
        public const string WorkWeixinAppJsApiTicket = "WorkWeixin:JsApiTicket:{0}";

        public const string CSRFtoken = "CSRFtoken:{0}";
        public const string KeyValue = "KeyValue:{0}";

        public const string WorkWeixinDepartment = "WorkWeixin:Department";
        public const string WorkWeixinUserList = "WorkWeixin:UserList";
        public const string WorkWeixinUserInfo = "WorkWeixin:UserInfo:{0}";

        /// <summary>
        /// 问卷投票
        /// </summary>
        public const string SurveyInfo = "SurveyInfo:{0}";

        /// <summary>
        /// 行政区划
        /// </summary>
        public const string AreaInfo = "AreaInfo:{0}";

        /// <summary>
        /// 地区组件
        /// </summary>
        public const string AreaComponentInfo = "AreaComponentInfo:{0}";

        /// <summary>
        /// 问卷投票
        /// </summary>
        public const string XundianInfo = "XundianInfo:{0}";

        /// <summary>
        /// 报表统计
        /// </summary>
        public const string Report = "Report:{0}:{1}";

        /// <summary>
        /// 绩效考核消息通知
        /// </summary>
        public const string PerformanceMessage = "Performance:Message:{0}";

        /// <summary>
        /// 每月需打卡日期
        /// </summary>
        public const string MonthAttendanceDateList = "Report:MonthAttendanceDateList:{0}";
        #endregion
    }
    /// <summary>
    /// 用户操作锁
    /// </summary>
    public enum UserOperationLockEnum
    {
        短信锁 = 0,
        注册锁 = 1,
        商品类别锁 = 10,
        商品锁 = 11,
        店铺锁= 12,
        巡店打卡 = 13,
        假期增加任务 = 100,
        假期减少任务 = 101,

        员工消息提醒=102,
        绩效考核提醒 = 103,

        年假增加任务 = 105,
        提醒假期过期 = 106,
        离职待办事项 = 107,

        金蝶订单更新部门成本 = 901,

        发送工资条消息 = 1010,
        物品锁=2000,
        物品出入库锁=2001,

        员工入职消息提示=108,

        问卷提交锁=200,

        奖品锁=3000,
        抽奖提交锁=3001,

    }
    public class LockHelper
    {
        private readonly ICacheManager _cache;
        private readonly ILog _log;
        public LockHelper(ICacheManager cache)
        {
            _cache = cache;
            _log = LogManager.GetLogger(typeof(LockHelper));

        }

        #region 用户账户锁
        public bool LockUser(int userId)
        {
            try
            {
                string key = string.Format(CacheKeys.UserLock, userId);
                return _cache.Add(key, "1", TimeSpan.FromMinutes(3));
            }
            catch (Exception ex)
            {
                _log.Error("LockHelper", ex);
                return false;
            }
        }

        /// <summary>
        /// 批量
        /// </summary>

        public bool LockUserList(List<int> userIds)
        {

            if (userIds == null || userIds.Count == 0) return false;
            if (userIds.Count == 1) return LockUser(userIds[0]);
            foreach (var userId in userIds)
            {
                string key = string.Format(CacheKeys.UserLock, userId);
                if (!string.IsNullOrEmpty(_cache.GetString(key)))
                {
                    return false;
                }
            }
            foreach (var userId in userIds)
            {
                if (!LockUser(userId))
                {
                    return false;
                }

            }

            return true;
        }

        public bool UnLockUser(int userId)
        {
            try
            {
                string key = string.Format(CacheKeys.UserLock, userId);
                return _cache.Remove(key);
            }
            catch (Exception ex)
            {
                _log.Error("LockHelper", ex);
                return false;
            }
        }

        public bool UnLockUserList(List<int> userIds)
        {
            try
            {
                foreach (var userId in userIds)
                {
                    UnLockUser(userId);
                }

                return true;
            }
            catch (Exception ex)
            {
                _log.Error("LockHelper", ex);
                return false;
            }
        }
        #endregion

        #region 操作锁
        /// <summary>
        /// 操作锁
        /// </summary>
        /// <param name="operation"></param>
        /// <returns></returns>
        public bool LockOperation(UserOperationLockEnum operation, string operaKey = "")
        {
            try
            {
                string key = string.Format(CacheKeys.KeyOperationLock, (int)operation, operaKey);
                return _cache.Add(key, "1", TimeSpan.FromMinutes(3));
            }
            catch (Exception ex)
            {
                _log.Error("LockHelper", ex);
                return false;
            }
        }
        /// <summary>
        /// 移除操作锁
        /// </summary>
        /// <param name="operation"></param>
        /// <returns></returns>
        public bool UnLockOperation(UserOperationLockEnum operation, string operaKey = "")
        {
            try
            {
                string key = string.Format(CacheKeys.KeyOperationLock, (int)operation, operaKey);
                return _cache.Remove(key);
            }
            catch (Exception ex)
            {
                _log.Error("LockHelper", ex);
                return false;
            }
        }

        #endregion

        #region 用户操作锁
        /// <summary>
        /// 用户操作锁
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="operation"></param>
        /// <returns></returns>
        public bool LockUserOperation(int userId, UserOperationLockEnum operation)
        {
            try
            {
                string key = string.Format(CacheKeys.UserOperationLock, userId, (int)operation);
                return _cache.Add(key, "1", TimeSpan.FromMinutes(3));
            }
            catch (Exception ex)
            {
                _log.Error("LockHelper", ex);
                return false;
            }
        }
        /// <summary>
        /// 移除用户操作锁
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="operation"></param>
        /// <returns></returns>
        public bool UnLockUserOperation(int userId, UserOperationLockEnum operation)
        {
            try
            {
                string key = string.Format(CacheKeys.UserOperationLock, userId, (int)operation);
                return _cache.Remove(key);
            }
            catch (Exception ex)
            {
                _log.Error("LockHelper", ex);
                return false;
            }
        }
        #endregion
    }
}
