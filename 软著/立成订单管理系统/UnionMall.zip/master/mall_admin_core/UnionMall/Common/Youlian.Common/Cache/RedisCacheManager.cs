﻿using Newtonsoft.Json;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Common.Cache
{
    /// <summary>
    /// Redis缓存管理类
    /// </summary>
    public class RedisCacheManager : ICacheManager
    {
        #region 配置
        private readonly string _instanceName;
        private readonly ConfigurationOptions options;
        private Lazy<IConnectionMultiplexer> _Connection;

        public RedisCacheManager(string connection, string instanceName)
        {
            options = ConfigurationOptions.Parse(connection);
            _instanceName = instanceName;
            _Connection = new Lazy<IConnectionMultiplexer>(() =>
            {
                ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(connection);
                return redis;
            });
        }
        public RedisCacheManager(string host = "localhost", int port = 6379, string ClientName = "RedisClient", bool allowAdmin = false)
        {
            options = new ConfigurationOptions()
            {
                EndPoints = { { host, port }, },
                AllowAdmin = allowAdmin,
                //Password = "",
                ClientName = ClientName,
                ReconnectRetryPolicy = new LinearRetry(5000),
                AbortOnConnectFail = false,
            };
            _Connection = new Lazy<IConnectionMultiplexer>(() =>
            {
                ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(options);
                return redis;
            });
        }

        //for the 'GetSubscriber()' and another Databases
        public IConnectionMultiplexer Connection { get { return _Connection.Value; } }

        //for the default database
        public IDatabase Database => Connection.GetDatabase();
        private string GetInstanceKey(string key)
        {
            return _instanceName + ":" + key;
        }
        #endregion

        public bool Add(string key, string value, TimeSpan? expiry = null)
        {
            if (value == null) return false;
            return Database.StringSet(GetInstanceKey(key), value, expiry, When.NotExists, CommandFlags.None);
        }

        public bool Set<T>(string key, T value, TimeSpan? expiry = null)
        {
            if (value == null) return false;
            return Database.StringSet(GetInstanceKey(key), JsonConvert.SerializeObject(value), expiry, When.Always, CommandFlags.None);
        }

        public bool SetString(string key, string value, TimeSpan? expiry = null)
        {
            if (value == null) return false;
            return Database.StringSet(GetInstanceKey(key), value, expiry, When.Always, CommandFlags.None);
        }

        public T Get<T>(string key)
        {
            var rv = Database.StringGet(GetInstanceKey(key), CommandFlags.None);
            if (!rv.HasValue)
                return default;
            return JsonConvert.DeserializeObject<T>(rv);
        }

        public string GetString(string key)
        {
            return Database.StringGet(GetInstanceKey(key), CommandFlags.None);
        }

        public bool Remove(string key)
        {
            return Database.KeyDelete(GetInstanceKey(key));
        }

        public bool Refresh(string key)
        {
            throw new NotImplementedException();
        }
    }
}
