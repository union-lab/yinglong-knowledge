﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Youlian.Common.Cache
{
    public static class CacheExtention
    {
        public static T GetOrAdd<T>(this ICacheManager cache, string key, Func<T> func, TimeSpan? expiry = null) where T : class
        {
            var result = cache.Get<T>(key);
            if (result != null)
            {
                return result;
            }
            result = func();
            cache.Set(key, result, expiry);
            return result;
        }
        public static async Task<T> GetOrAddAsync<T>(this ICacheManager cache, string key, Func<Task<T>> func, TimeSpan? expiry = null) where T : class
        {
            var result = cache.Get<T>(key);
            if (result != null)
            {
                return result;
            }
            result = await func();
            cache.Set(key, result, expiry);
            return result;
        }

        public static string GetOrAdd(this ICacheManager cache, string key, Func<string> func, TimeSpan? expiry = null)
        {
            var result = cache.GetString(key);
            if (result != null)
            {
                return result;
            }
            result = func();
            cache.SetString(key, result, expiry);
            return result;
        }

        public static async Task<string> GetOrAddAsync(this ICacheManager cache, string key, Func<Task<string>> func, TimeSpan? expiry = null)
        {
            var result = cache.GetString(key);
            if (result != null)
            {
                return result;
            }
            result = await func();
            cache.SetString(key, result, expiry);
            return result;
        }
    }
}
