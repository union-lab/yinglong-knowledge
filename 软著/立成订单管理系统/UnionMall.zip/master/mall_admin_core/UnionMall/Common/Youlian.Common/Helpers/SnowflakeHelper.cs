﻿using Snowflake.Core;
using System;

namespace Youlian.Common.Helpers
{
    /// <summary>
    /// 主键雪花id
    /// </summary>
    public static class SnowflakeHelper
    {
        private static IdWorker worker = new IdWorker(Convert.ToInt64(AppSettings.Configuration["WorkerId"]), 0);

        /// <summary>
        /// 生成唯一主键Id
        /// </summary>
        /// <returns></returns>
        public static long CreateUniqueId
        {
            get
            {
                return worker.NextId();
            }
        }
    }
}
