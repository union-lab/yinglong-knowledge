const envList = [{"envId":"cloud1-4gsf17k7256694e5","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}